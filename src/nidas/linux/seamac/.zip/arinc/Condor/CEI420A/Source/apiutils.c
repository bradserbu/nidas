/*===========================================================================*
 * FILE:                      A P I U T I L S . C
 *===========================================================================*
 *
 * COPYRIGHT (C) 1998 - 2004 BY
 *      CONDOR ENGINEERING, INC., SANTA BARBARA, CALIFORNIA
 *      ALL RIGHTS RESERVED.
 *
 *      THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY BE USED AND
 *      COPIED ONLY IN ACCORDANCE WITH THE TERMS OF SUCH LICENSE AND WITH
 *      THE INCLUSION OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY
 *      OTHER COPIES THEREOF MAY NOT BE PROVIDED OR OTHERWISE MADE
 *      AVAILABLE TO ANY OTHER PERSON.  NO TITLE TO AND OWNERSHIP OF THE
 *      SOFTWARE IS HEREBY TRANSFERRED.
 *
 *      THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT
 *      NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY CONDOR
 *      ENGINEERING.
 *
 *===========================================================================*
 *
 * FUNCTION:
 *  
 *      Common utility routines for use with CEI-x20 ARINC-429 boards.
 *
 * DESCRIPTION: 
 *  
 *      This file contains routines that are not specific to a particular 
 *      board type.
 *
 * USER ENTRY POINTS:
 *
 *      ar_execute_bit          - execute a particular built-in-test
 *      ar_force_version        - override the hardware version
 *      ar_formatarinclabel     - format data as an ARINC transmission value
 *      ar_formatbinarylabel    - format ARINC transmission data as a binary 
 *                                value
 *      ar_get_boardname        - return ASCII string name of board
 *      ar_get_boardnameLV      - return ASCII string name of board (LabView)
 *      ar_get_error            - return an error string for a status code
 *      ar_get_harris           - same as ar_get_config() (backwards compat)
 *      ar_get_timercnt         - get the current timer tick count (16-bit)
 *      ar_int_slave            - interrupt the slave
 *      ar_putword2x16          - put 2 16-bit words into the burst xmit queue
 *      ar_recreate_parity      - recreate the parity bit for a received word
 *      ar_reformat             - reformat an ARINC word for transmission
 *      ar_set_arinc_config     - alternate interface to ar_set_config()
 *      ar_set_harris           - same as ar_set_config() (backwards compat)
 *      ar_unformat             - unformat a received ARINC word
 *      ar_version              - return the software version identification 
 *                                string
 *
 * INTERNAL ROUTINES:
 *
 *      ar_elapsed_ticks        - calculate difference between two tick counts
 *      check_dev_arg           - validate the board number argument
 *      check_dev_and_chan_args - validate the board number and channel
 *                                arguments
 *      run_loopback_test       - execute and internal/external loopback test
 *      is_config_item          - determine a config item class
 *
 * HISTORY:
 *
 *   Date     By   Vers                        Comments
 * --------  ----  ----  -----------------------------------------------------
 * 04/13/00  ajh   3.02  Split from the standard x20 API.
 * 09/29/00  ajh   3.13  Added ar_get_boardname().
 * 09/28/01  skb   3.40  Added support for CEI-820.
 * 04/23/04  skb   3.90  Added AR_EXECUTE_BIT and supporting routines.
 *
 *===========================================================================*/

#include <linux/types.h>
#include <asm/string.h>        // memset
#include <linux/kernel.h>      // min
#include <linux/fs.h>          // sprintf
#include <nidas/linux/klog.h>  // KLOG_DEBUG
#include <linux/sched.h>       // schedule

//---------------------------------------------------------------------------*
// Even/odd parity conversion table
//---------------------------------------------------------------------------*
#define ODD     0x80                   // indicates odd parity
#define EVN     0x00                   // indicates even parity
static unsigned char byte_parity[] =   // indicates parity for byte vals 0-255
{
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN, EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD,
   EVN, ODD, ODD, EVN, ODD, EVN, EVN, ODD, ODD, EVN, EVN, ODD, EVN, ODD, ODD, EVN
};


//---------------------------------------------------------------------------*
// ARINC 573/717 baud rate and subframe size configurations
//---------------------------------------------------------------------------*
static int baud_cfg_bits_717[] =       
{
   A717_SPEED_384,                     // 32 words per subframe
   A717_SPEED_768,                     // 64 words per subframe
   A717_SPEED_1536,                    // 128 words per subframe
   A717_SPEED_3072,                    // 256 words per subframe
   A717_SPEED_6144,                    // 512 words per subframe
   A717_SPEED_12288,                   // 1024 words per subframe
   A717_SPEED_24576,                   // 2048 words per subframe
   A717_SPEED_49152                    // 4096 words per subframe
}; 


/*===========================================================================*
 * INTERNAL ROUTINE:        A R _ E L A P S E D _ T I C K S
 *===========================================================================*
 *
 * FUNCTION:    Compute the elapsed timer tick count.
 *
 * RETURN VAL:  the number of timer ticks elapsed from t1 to t2
 *
 * DESCRIPTION: Accounting for 32-bit rollover, calculate the number of timer
 *              ticks that elapsed from t1 to t2.
 *
 *===========================================================================*/
unsigned long ar_elapsed_ticks(unsigned long t1,unsigned long t2)
{
   // return the elapsed ticks from t1 to t2 (accounting for rollover)
   return ((t2 >= t1) ? (t2 - t1) : ((~t1) + t2 + 1));
}


/*===========================================================================*
 * INTERNAL ROUTINE:    C H E C K _ D E V _ A R G
 *===========================================================================*
 *
 * FUNCTION:    Validate the given user-supplied board number.
 *
 * RETURN VAL:  ARS_NORMAL        the board is valid and has been initialized
 *              ARS_INVBOARD      invalid board number
 *              ARS_BRDNOTLOAD    board not initialized
 *
 * DESCRIPTION: Verify that the given board number is valid and that the 
 *              associated board has already been initialized.
 *
 *===========================================================================*/
static short check_dev_arg
(
   unsigned int cardnum      // (i) the board number of interest
)
{
   // make sure the board number is valid
   if (cardnum >= MAX_BOARDS)
      return ARS_INVBOARD;

   // make sure the board has been initialized
   if (ar_board[cardnum].ar_inited == 0)
      return ARS_BRDNOTLOAD;

   // the board is valid and has been initialized
   return ARS_NORMAL;
}


/*===========================================================================*
 * INTERNAL ROUTINE:    C H E C K _ D E V _ A N D _ C H A N _ A R G S
 *===========================================================================*
 *
 * FUNCTION:    Validate the given user-supplied board number and channel
 *              arguments.
 *
 * RETURN VAL:  ARS_NORMAL        the board is valid and has been initialized
 *                                and the channel index is valid
 *              ARS_INVBOARD      invalid board number
 *              ARS_BRDNOTLOAD    board not initialized
 *              ARS_INVARG        invalid channel index
 *
 * DESCRIPTION: Verify that the given board number is valid and that the 
 *              associated board has already been initialized.
 *
 *===========================================================================*/
static short check_dev_and_chan_args
(
   unsigned int cardnum,     // (i) the board number of interest
   unsigned int channel      // (i) channel index
)
{
   // make sure the board is valid and has been initialized
   short status = check_dev_arg(cardnum);
   if (status != ARS_NORMAL)
      return status;

   // make sure the channel is within range
   if (channel >= MAX_CHAN)
      return ARS_INVARG;

   // the board and channel arguments are valid
   return ARS_NORMAL;
}

/*===========================================================================*
 * INTERNAL ROUTINE:       R U N _ L O O P B A C K _ T E S T 
 *===========================================================================*
 *
 * FUNCTION:    Execute a basic internal or external loopback test.
 *
 * RETURN VAL:  ARS_NORMAL           operation completed successfully
 *              ARS_INVBOARD         invalid board number
 *              ARS_WRAP_DATA_FAIL   wrap test data failure occurred
 *              ARS_WRAP_DROP_FAIL   wrap test missing data failure occurred
 *              ARS_FAILURE          wrap test general failure
 *
 * DESCRIPTION: Execute an internal loopback test of all ARINC 429 channel 
 *              pairs (that is, TX1->RX1, TX2->RX2, ...) on the given board.
 *              Note that partnerless rx/tx channels in unbalanced 
 *              configurations (for example, the last 4 transmitters on a 
 *              4RX/8TX board) are not included in the test.  The board is
 *              re-initialized (with a call to AR_LOADSLV) and launched (with
 *              a call to AR_GO) by this loopback operation.  Therefore, this
 *              operation should only be executed at startup.
 *
 *===========================================================================*/
static short run_loopback_test
(
   short cardnum,            // (i) the board number of interest
   short is_internal         // (i) non-zero if internal, 0 if external
)
{
   short status;             // function status value
   short restore_status;     // config restoration status value
   short i;                  // loop counter
   short chan_pairs;         // channel pair count
   short type;               // current board type
   int word;                 // wrap word counter
   long recv_word;           // the received word

   // channel pair parameter structure
   struct
   {
      unsigned long include_pair;
      unsigned long init_rx_rate;
      unsigned long init_tx_rate;
      unsigned long init_rx_par;
      unsigned long init_tx_par;
   } chan_info[MAX_CHAN];

   // initialize the channel pair parameter structure
   memset(chan_info,0,sizeof(chan_info));

   // check if the board is currently open
   if (ar_board[cardnum].board_mapped != 0)
   {
      // close the open board before continuing
      status = ar_close(cardnum);
      if (status != ARS_NORMAL)
         return ARS_FAILURE;
   }

   // initialize the device
   status = ar_loadslv(cardnum,0,0,0);
   if (status != ARS_NORMAL)
      return ARS_FAILURE;

   // launch the board
   if (ar_go(cardnum) != ARS_NORMAL)
      return ARS_FAILURE;

   // determine the channel pair count
   chan_pairs = min(ar_num_rchans(cardnum),ar_num_xchans(cardnum));

   // save the board type
   type = ar_get_boardtype(cardnum);

   // search for valid 429 pairs
   for (i=0;i < chan_pairs;i++)
   {
      // skip the second channel on 520/520A/620 -J configs (reserved for 573 HBP)
      if ((i == 1) && ((type == (CEI_520 | IS_717)) || (type == (CEI_520A | IS_717) || (type == (CEI_620 | IS_717)))))
         continue;

      // only include partnered 429 tx/rx pairs in the test
      if ((ar_get_chantype(cardnum,TRUE,i) == CHAN_ARINC429) && (ar_get_chantype(cardnum,FALSE,i) == CHAN_ARINC429))
      {
         // include this pair and save initial tx/rx baud rate and parity
         chan_info[i].include_pair = TRUE;
         chan_info[i].init_rx_rate = ar_get_config(cardnum,(short)(ARU_RX_CH01_BIT_RATE + i));
         chan_info[i].init_tx_rate = ar_get_config(cardnum,(short)(ARU_TX_CH01_BIT_RATE + i));
         chan_info[i].init_rx_par = ar_get_config(cardnum,(short)(ARU_RX_CH01_PARITY + i));
         chan_info[i].init_tx_par = ar_get_config(cardnum,(short)(ARU_TX_CH01_PARITY + i));

         KLOG_DEBUG("chan_info[%d].include_pair = %d\n", i, chan_info[i].include_pair);
         KLOG_DEBUG("chan_info[%d].init_rx_rate = %d\n", i, chan_info[i].init_rx_rate);
         KLOG_DEBUG("chan_info[%d].init_tx_rate = %d\n", i, chan_info[i].init_tx_rate);
         KLOG_DEBUG("chan_info[%d].init_rx_par  = %d\n", i, chan_info[i].init_rx_par);
         KLOG_DEBUG("chan_info[%d].init_tx_par  = %d\n", i, chan_info[i].init_tx_par);
      }
   }

   // update the internal wrap setting
   status = ar_set_config(cardnum,ARU_INTERNAL_WRAP,((is_internal) ? (AR_WRAP_ON) : (AR_WRAP_OFF)));
   if (status != ARS_NORMAL)
      return ARS_FAILURE;

   // execute the wrap test
   for (i=0;(i < chan_pairs) && (status == ARS_NORMAL);i++)
   {
      // nothing to do if this channel pair has been excluded
      if (chan_info[i].include_pair == FALSE)
         continue;

      // select low speed and disable parity
      status |= ar_set_config(cardnum,(short)(ARU_RX_CH01_BIT_RATE + i),AR_LOW);
      status |= ar_set_config(cardnum,(short)(ARU_TX_CH01_BIT_RATE + i),AR_LOW);
      status |= ar_set_config(cardnum,(short)(ARU_RX_CH01_PARITY + i),AR_OFF);
      status |= ar_set_config(cardnum,(short)(ARU_TX_CH01_PARITY + i),AR_OFF);

      // write some incrementing data words into the transmit buffer
      for (word = 0;(word < 10) && (status == ARS_NORMAL);word++) {
         status = ar_putword(cardnum,i,(((long)i << 28) | ((long)word << 16) | word));
         KLOG_DEBUG("chn: %d   wrote: %04lX", i, (((long)i << 28) | ((long)word << 16) | word));
      }
      // attempt to read back the data we just sent
      for (word = 0;(word < 10) && (status == ARS_NORMAL);word++) 
      {
         // attempt to receive the next word
/*          status = ar_getwords(BOARD_NUM, chn, LPB, &(sample.length), sample.data); */
         status = ar_getnext(cardnum,i,&recv_word);
         KLOG_DEBUG("chn: %d   read:  %04lX", i, recv_word);
         if (status == ARS_GOTDATA)
            status = (short)((recv_word == (((long)i << 28) | ((long)word << 16) | word)) ? (ARS_NORMAL) : (ARS_WRAP_DATA_FAIL));
         else
            status = ARS_WRAP_DROP_FAIL;
      }
   }

   // restore the previous internal wrap setting
   restore_status = ar_set_config(cardnum,ARU_INTERNAL_WRAP,AR_WRAP_OFF);

   // restore tx/rx baud rate and parity
   for (i=0;i < chan_pairs;i++)
   {
      // check if this channel pair was included
      if (chan_info[i].include_pair)
      {
         // restore the previous settings
         restore_status |= ar_set_config(cardnum,(short)(ARU_RX_CH01_BIT_RATE + i),chan_info[i].init_rx_rate);
         restore_status |= ar_set_config(cardnum,(short)(ARU_TX_CH01_BIT_RATE + i),chan_info[i].init_tx_rate);
         restore_status |= ar_set_config(cardnum,(short)(ARU_RX_CH01_PARITY + i),chan_info[i].init_rx_par);
         restore_status |= ar_set_config(cardnum,(short)(ARU_TX_CH01_PARITY + i),chan_info[i].init_tx_par);
      }
   }

   // bail out if we failed to restore any previous settings
   if ((status == ARS_NORMAL) && (restore_status != ARS_NORMAL))
      return ARS_FAILURE;

   // return the loopback test result
   return status;
}


/*===========================================================================*
 * ENTRY POINT:         A R _ F O R C E _ V E R S I O N
 *===========================================================================*
 *
 * FUNCTION:    Force the firmware to configure to a particular version of
 *              the hardware. Dummy routine.
 *
 * RETURN VAL:  ARS_NORMAL        operation completed successfully
 *
 * DESCRIPTION: This function does nothing when called for a CEI-x20 device.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_force_version
(
   short cardnum,            // (i) the board number of interest
   short number              // (i) configuration to force
)
{
   // nothing to do here
   return ARS_NORMAL;
}


/*===========================================================================*
 * ENTRY POINT:             A R _ G E T _ E R R O R
 *===========================================================================*
 *
 * FUNCTION:    Return a message string associated with an error.
 *
 * RETURN VAL:  string containing associated error
 *
 * DESCRIPTION: Many of the ARINC functions described here return status
 *              values which may indicate an error condition. This function 
 *              is passed such an error value and returns a pointer to a 
 *              message string describing the error.
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_get_errorLV(char *string,short status)
{
   // provide LabView-compatable wrapper
   strcpy(string,ar_get_error(status)); 
}
EXPORT32 char * DLL_EXPORTED ar_get_error
(
   short status              // (i) status value returned by an API utility
)
{
   // return a textual description of the status value
   switch (status)
   {
      case ARS_NODATA:          return "ARS_NODATA:          No data available now";
      case ARS_NORMAL:          return "ARS_NORMAL:          Normal successful completion";
      case ARS_GOTDATA:         return "ARS_GOTDATA:         Valid data has been returned";

      case BTD_ERR_NOWINRT:     return "BTD_ERR_NOWINRT:     WinRT driver not loaded/started";
      case BTD_ERR_BADREGISTER: return "BTD_ERR_BADREGISTER: WinRT parameters don't match registry";
      case BTD_ERR_BADOPEN:     return "BTD_ERR_BADOPEN:     WinRT device open failed";
      case BTD_NO_SUPPORT:      return "BTD_NO_SUPPORT:      Bus/Carrier/OS not supported by API";

      case ARS_FAILURE:         return "ARS_FAILURE:         Operation failed";
      case ARS_INVHARCMD:       return "ARS_INVHARCMD:       Invalid configuration command";
      case ARS_INVHARVAL:       return "ARS_INVHARVAL:       Invalid configuration value";
      case ARS_XMITOVRFLO:      return "ARS_XMITOVRFLO:      Transmit buffer overflow";
      case ARS_INVBOARD:        return "ARS_INVBOARD:        Invalid board number";
      case ARS_NOSYNC:          return "ARS_NOSYNC:          Timeout synchronizing with the ARINC";
      case ARS_BADLOAD:         return "ARS_BADLOAD:         Could not successfully load firmware";
      case ARS_BRDNOTLOAD:      return "ARS_BRDNOTLOAD:      Board not loaded via call to ar_loadslv()";
      case ARS_SYNCTIMEOUT:     return "ARS_SYNCTIMEOUT:     Error initializing timer";
      case ARS_SYNCOVERRUN:     return "ARS_SYNCOVERRUN:     Host CPU can't keep up with data rate";
      case ARS_BADINIT:         return "ARS_BADINIT:         Can't initialize timer on slave";
      case ARS_MEMADERR:        return "ARS_MEMADERR:        Memory address mapping error";
      case ARS_MEMWRERR:        return "ARS_MEMWRERR:        Dual-Port memory write/read-back error";
      case ARS_INVSTRING:       return "ARS_INVSTRING:       Invalid string";
      case ARS_INVEQID:         return "ARS_INVEQID:         Invalid equipment ID";
      case ARS_CHECKSUM:        return "ARS_CHECKSUM:        Checksum error loading slave";
      case ARS_NORESPONSE:      return "ARS_NORESPONSE:      No response on receiver";
      case ARS_UNSUPTYPE:       return "ARS_UNSUPTYPE:       Translation not available";
      case ARS_INVARG:          return "ARS_INVARG:          Invalid argument value";
      case ARS_INVLABEL:        return "ARS_INVLABEL:        Invalid label";
      case ARS_DRIVERFAIL:      return "ARS_DRIVERFAIL:      Driver load failed";
      case ARS_WINRTFAIL:       return "ARS_WINRTFAIL:       WinRT Device Driver Error";
      case ARS_CHAN_TIMEOUT:    return "ARS_CHAN_TIMEOUT:    Time out detected commanding CEI-x20 board";
      case ARS_NO_HW_SUPRT:     return "ARS_NO_HW_SUPRT:     Function not supported by current hardware";
      case ARS_BAD_DAC_VAL:     return "ARS_BAD_DAC_VAL:     Specified DAC value <0 or >255";
      case ARS_BAD_FPGA:        return "ARS_BAD_FPGA:        Unsupported number of transmitters or receivers";
      case ARS_BAD_STATIC:      return "ARS_BAD_STATIC:      Internal memory read/write failure";
      case ARS_LAST_ERROR:      return last_error;
      case ARS_HW_CONSISTENCY:  return "ARS_HW_CONSISTENCY:  Hardware config is not consistent";
      case ARS_HW_DETECT:       return "ARS_HW_DETECT:       Failed to detect CEI-xxx hardware";
      case ARS_WRAP_DATA_FAIL:  return "ARS_WRAP_DATA_FAIL:  Wrap test data failure occurred";
      case ARS_WRAP_DROP_FAIL:  return "ARS_WRAP_DROP_FAIL:  Wrap test missing data failure occurred";
      case ARS_WRAP_FLUSH_FAIL: return "ARS_WRAP_FLUSH_FAIL: Wrap test flush failure occurred";                          
      default:                  return "default:             Unknown/undefined status or error code";
   }
}


/*===========================================================================*
 * ENTRY POINT:             A R _ E X E C U T E _ B I T
 *===========================================================================*
 *
 * FUNCTION:    Executes the specified built-in-test. 
 *
 * RETURN VAL:  ARS_NORMAL           operation completed successfully
 *              ARS_INVBOARD         invalid board number
 *              ARS_BRDNOTLOAD       board must be launched before executing 
 *                                   the requested test
 *              ARS_INVARG           invalid test type parameter
 *              ARS_WRAP_DATA_FAIL   wrap test invalid data failure occurred
 *              ARS_WRAP_DROP_FAIL   wrap test missing data failure occurred
 *              ARS_FAILURE          the requested built-in-test failed
 *
 * DESCRIPTION: Performs the desired built-in-test operation.  The following
 *              built-in-test types are currently supported:
 *
 *                 AR_BIT_BASIC_STARTUP  performs all start-up testing 
 *                                       executed by the AR_LOADSLV routine
 *                                       (dual-port memory, the on-board 
 *                                       processor, and the on-board FPGA are
 *                                       tested) - the board is reinitialized
 *                                       during this test
 *                 AR_BIT_PERIODIC       verifies that the board is running 
 *                                       by confirming that the on-board tick 
 *                                       timer is being properly incremented 
 *                 AR_BIT_INT_LOOPBACK   performs all start-up testing
 *                                       executed by the AR_BIT_BASIC_STARTUP
 *                                       operation, then executes an internal 
 *                                       loopback test of all ARINC 429 
 *                                       channel pairs (that is, TX1->RX1,
 *                                       TX2->RX2,...) - note that partnerless 
 *                                       rx/tx channels in unbalanced 
 *                                       configurations (for example, the last
 *                                       4 transmitters on a 4RX/8TX board) 
 *                                       are not included in the test - the 
 *                                       board is reinitialized during this 
 *                                       test
 *                 AR_BIT_EXT_LOOPBACK   same as AR_BIT_INT_LOOPBACK, but an
 *                                       external loopback is executed instead
 *                                       (a properly-connected loopback 
 *                                       adapter must be externally attached)
 *
 *              Note that all built-in-test operations (with the exception of
 *              AR_BIT_PERIODIC) re-initialize the board, and should therefore
 *              only be used at startup.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_execute_bit 
(
   short cardnum,            // (i) the board number of interest
   short test_type           // (i) desired built-in-test type
)
{
   short status;             // function status value
   unsigned long tick;       // receives current timer tick
   unsigned long jwait;

   // execute the specified test
   switch (test_type)
   {
      case AR_BIT_BASIC_STARTUP:
        KLOG_DEBUG("Running AR_BIT_BASIC_STARTUP...");
         // execute standard testing associated with board initialization
         return (short)((ar_loadslv(cardnum,0,0,0) == ARS_NORMAL) ? (ARS_NORMAL) : (ARS_FAILURE));

      case AR_BIT_PERIODIC:
        KLOG_DEBUG("Running AR_BIT_PERIODIC...");
         // make sure the board is running
         status = check_dev_arg(cardnum);
         if (status != ARS_NORMAL)
            return status;

         // make sure the board has been launched
         if (ar_board[cardnum].board_ar_go == 0)
            return ARS_BRDNOTLOAD;

         // save the current timer tick
         tick = ar_get_timercntl(cardnum);

         // take a nap for 50 ms
         jwait = jiffies + 1;
         while (jiffies < jwait) schedule();

         // make sure the timer tick incremented
         return (short)((ar_elapsed_ticks(tick,ar_get_timercntl(cardnum))) ? (ARS_NORMAL) : (ARS_FAILURE));

      case AR_BIT_INT_LOOPBACK:
        KLOG_DEBUG("Running AR_BIT_INT_LOOPBACK...");
        // execute the loopback test
        return run_loopback_test(cardnum,(short)(test_type == AR_BIT_INT_LOOPBACK));

      case AR_BIT_EXT_LOOPBACK:
        KLOG_DEBUG("Running AR_BIT_EXT_LOOPBACK...");
        // execute the loopback test
        return run_loopback_test(cardnum,(short)(test_type == AR_BIT_INT_LOOPBACK));

      default:
         // invalid test type parameter
        KLOG_DEBUG("invalid test type parameter???");
        return ARS_INVARG;
   }
}


/*===========================================================================*
 * ENTRY POINT:          A R _ G E T _ T I M E R C N T
 *===========================================================================*
 *
 * FUNCTION:    This routine returns the number of timer ticks that have
 *              occurred on the slave. This is a 16-bit integer that will wrap
 *              around periodically.
 * 
 * RETURN VAL:  the number of timer ticks
 *
 * DESCRIPTION: This is a 16-bit wrapper function for ar_get_timercntl().
 *
 *===========================================================================*/                                  
EXPORT32 unsigned short DLL_EXPORTED ar_get_timercnt
(
   short cardnum             // (i) the board number of interest
)
{
   // return the current timer tick counter (lower 16-bits only)
   return (unsigned short)ar_get_timercntl(cardnum);
}


/*===========================================================================*
 * ENTRY POINT:           A R _ P U T W O R D 2 x 1 6
 *===========================================================================*
 *
 * FUNCTION:    Put two 16 bit words in the burst mode transmit buffer.
 *
 * RETURN VAL:  ARS_NORMAL        success
 *              ARS_XMITOVRFLO    failure - transmit buffer overflow
 *
 *                                If ARS_XMITOVRFLO is returned, the interface
 *                                is not transmitting data as fast as data is 
 *                                being put into the buffer. The interface may
 *                                be in a reset state or the data rate may be 
 *                                too high. In either case, the data was not
 *                                put into the transmit buffer. If the 
 *                                interface is running, the user can retry the
 *                                call until success is achieved.
 *
 * DESCRIPTION: Put an ARINC word given (in the form of two 16 bit words,
 *              lsw and msw) in the transmit buffer queue.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_putword2x16
(
   short cardnum,            // (i) the board number of interest
   short channel,            // (i) the channel to transmit on
   short lsw,                // (i) least significant 16 bits of xmit word
   short msw                 // (i) most significant 16 bits of xmit word
)
{
   long  ARINC_data;         // the 32-bit transmit word

   // build the 32-bit transmit word
   ARINC_data = msw;
   ARINC_data = (ARINC_data << 16) | lsw;

   // attempt to transmit the 32-bit word
   return ar_putword(cardnum,channel,ARINC_data);
}


/*===========================================================================*
 * ENTRY POINT:              A R _ R E F O R M A T
 *===========================================================================*
 *
 * FUNCTION:    Reformat a transmit word from engineering format in
 *              preparation for transmission. This is a no-operation function
 *              for all CEI-x20 boards.
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: Converts an output ARINC word to CEI-x20 transmission format.
 *              It takes data in the standard ARINC format and does nothing.
 *              This is provided for compatibility with other Condor ARINC 
 *              devices. 
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_reformat
(
   void *lswrd,              // (i/o) ignored
   void *mswrd               // (i/o) ignored
)
{
   // nothing to do - hardware converts word to transmission format
   return;
}


/*===========================================================================*
 * ENTRY POINT:      A R _ F O R M A T A R I N C L A B E L
 *===========================================================================*
 *
 * FUNCTION:    Format ARINC data as an ARINC value in ASCII. This function
 *              is here to support LabView.
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: Format ARINC data as an ARINC value in ASCII (parity - bit 31,
 *              SSM - bits 30-29, DATA - bits 28-10, SDI 9-8). The label is
 *              truncated (bottom 8 bits, 7-0). The resulting ASCII text is
 *              stored in 'label_str' (a caller-allocated character buffer).
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_formatarinclabel
(
   unsigned long label_data, // (i) label to format
   char *label_str           // (o) ASCII-formatted label text
)
{
   unsigned long int val;    // temporarily stores value of each section
   unsigned long int mask;   // used to mask off regions of the data word
   char p[2];                // textual representation of the parity bit
   char ssm[3];              // textual representation of the SSM
   char data[6];             // textual representation of the data
   char sdi[4];              // textual representation of the SDI
   
   // determine parity value
   mask = 0x80000000L;
   val = mask & label_data;
   val = val >> 31;
   sprintf(p,"%01lX",val);

   // determine SSM - mask of B'0110' top nibble
   mask = 0x60000000L;
   val = mask & label_data;
   val = val >> 29;
   sprintf(ssm,"%01lX",val);

   // determine DATA - mask of B'0001 1111 1111 1111 1111 1100 0000 0000'
   mask = 0x1FFFFC00L;
   val = mask & label_data;
   val = val >> 10;
   sprintf(data,"%05lX",val);

   // determine SDI - mask of B'0000 0000 0000 0000 0000 0011 0000 0000'
   mask = 0x00000300L;
   val = mask & label_data;
   val = val >> 8;
   sprintf(sdi,"%01lX",val);

   // store representation of full word in provided buffer
   sprintf(label_str,"%s %s      %s         %s",p,ssm,data,sdi);
}


/*===========================================================================*
 * ENTRY POINT:      A R _ F O R M A T B I N A R Y L A B E L
 *===========================================================================*
 *
 * FUNCTION:    Format ARINC data as a binary value. This function is here to
 *              support LabView.
 * 
 * RETURN VAL:  none
 *
 * DESCRIPTION: Format ARINC data as a binary value. The label can be
 *              optionally truncated (bottom 8 bits) using the 'trunc_label'
 *              argument. This routine is coded to handle 32 bits for non-
 *              truncated values, 24 bits truncated. The resulting ASCII text
 *              is stored in 'label_str' (a caller-allocated buffer). Spaces
 *              are placed in the string every 4 bits for readability - don't
 *              forget allocate space for them and a null terminator 
 *              (truncated -> 24+5+1 = 30, non-truncated -> 32+7+1 = 40).
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_formatbinarylabel
(
   unsigned long label_data, // (i) data to format
   int trunc_label,          // (i) true if label should be truncated
   char *label_str           // (o) ASCII-formatted binary label text
)
{
   int cnt_bits;             // number of bit-characters in the string
   int cnt_spaces;           // number of space-characters in the string
   int index;                // index counter in the data word
   int space_fudge;          // current number of spaces added
   int bit_fudge;            // used to dump bottom 8 bits of label 
   unsigned long int mask;   // masks off all but current bit

   // determine the number of bit and space characters
   cnt_bits = ((trunc_label == FALSE) ? (32) : (24));
   cnt_spaces = ((trunc_label == FALSE) ? (7) : (5));
   bit_fudge = ((trunc_label == FALSE) ? (0) : (8));

   // set all bits to blank
   memset(label_str,' ',cnt_bits + cnt_spaces);

   // null-terminate the string
   label_str[cnt_bits + cnt_spaces] = '\0';

   // loop through the bits
   for (index = 0;index < cnt_bits;index++)
   {
      // add a space every 4th bit
      space_fudge = index / 4;

      // calculate the mask to check this bit
      mask = (1L << (cnt_bits - index - 1 + bit_fudge));

      // append the value of this bit to the string
      label_str[index + space_fudge] = (char)((label_data & mask) ? ('1') : ('0'));
   }
}


/*===========================================================================*
 * ENTRY POINT:            A R _ I N T _ S L A V E
 *===========================================================================*
 *
 * FUNCTION:    Interrupt the slave processor.
 *
 * RETURN VAL:  ARS_INVARG        this function is not supported
 *
 * DESCRIPTION: This function is intended to signal a hardware interrupt to 
 *              the slave. This is simply here as a placeholder, since the 
 *              slave must be programmed to handle an interrupt if this is to
 *              be of any use.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_int_slave
(
   short cardnum             // (i) the board number of interest
)
{
   // this function is not currently supported
   return ARS_INVARG;
}


/*===========================================================================*
 * ENTRY POINT:       A R _ R E C R E A T E _ P A R I T Y
 *===========================================================================*
 *
 * FUNCTION:    Recreate the parity bit for the given word.
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: This function determines the parity bit (e.g. the MSB of the
 *              32-bit ARINC word) based on the even/odd parity of each of
 *              the 4 bytes which make up the ARINC word. The appropriate
 *              parity bit value is written to the parity bit in the supplied
 *              word. 
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_recreate_parity
(
   unsigned char *word       // (i) pointer to 32-bit ARINC word
)
{
   int i;                    // loop index
   unsigned char parity;     // stores the word parity

   // calculate parity for the word
   for (i = 0,parity = 0x80;i < 4;i++)
      parity += byte_parity[word[i]];

   // set/clear the parity bit
   if ( parity != 0 )
      word[3] |= 0x80;
   else
      word[3] &= 0x7F;
}


/*===========================================================================*
 * ENTRY POINT:             A R _ U N F O R M A T
 *===========================================================================*
 *
 * FUNCTION:    Reformat a transmit word from ARINC engineering format after
 *              a transmission. 
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: This is not normally required, since the interface board 
 *              provides this function. This is included for possible future 
 *              use.
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_unformat
(
   short *lsword,            // (i/o) address of the least significant 16 bits
                             //       of the word to unformat or entire 32-bit 
                             //       word if the 2nd param is NULL
   short *msword             // (i/o) address of the most significant 16 bits 
                             //       of the word to unformat or NULL if the 
                             //       entire 32-bit word was passed in as the
                             //       first parameter.
)
{
   unsigned char *lsw,*msw;  // byte pointers to high and low 16-bits
   unsigned char tmp_lsw[2]; // stores new 2 low bytes
   unsigned char tmp_msw[2]; // stores new 2 high bytes

   // store byte pointers to the lsw and msw
   lsw = (unsigned char *)lsword;
   msw = (unsigned char *)msword;

   // if second param is null, the first param points to 32-bits
   if (msw == 0)
      msw = lsw + 2;

   // convert the given words from transmission format to engineering format
   tmp_lsw[1]  = (unsigned char)(lsw[1] >> 3);
   tmp_lsw[1] += (unsigned char)(msw[0] << 5);
   tmp_msw[0]  = (unsigned char)(msw[0] >> 3);
   tmp_msw[0] += (unsigned char)(msw[1] << 5);
   tmp_msw[1]  = (unsigned char)(msw[1] >> 3);
   tmp_msw[1] += (unsigned char)((lsw[1] & 6) << 4);
   if ((lsw[1] & 1) != 0)
      tmp_msw[1] &= 0x80;

   // write back the word value in engineering format
   lsw[1] = tmp_lsw[1];
   msw[0] = tmp_msw[0];
   msw[1] = tmp_msw[1];
}


/*===========================================================================*
 * ENTRY POINT:               A R _ V E R S I O N
 *===========================================================================*
 *
 * FUNCTION:    Return the software version string.
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: The software version string is copied to the string parameter 
 *              'verstr'.
 *
 *===========================================================================*/
EXPORT32 void DLL_EXPORTED ar_version
(
   char *verstr              // (o) receives software version string 
)
{
   // store version string if non-null
   if (verstr)
      strcpy(verstr,API_VER " for " API_PRODUCTS);
}


/*============================================================================*
 * ENTRY POINT:         A R _ G E T _ B O A R D N A M E
 *============================================================================*
 *
 * FUNCTION:    Decode the board type and return its name in ASCII.
 *              
 * RETURN VAL:  board type description string
 *
 *              If there is an error, an error message string is returned.
 *              
 * DESCRIPTION: Decode the board type and return a textual description of the
 *              board in ASCII. The version string is also copied into the 
 *              buffer pointed to by the 'board_name' parameter (if it is non-
 *              null).
 *
 *============================================================================*/
EXPORT32 char * DLL_EXPORTED ar_get_boardname
(
   unsigned int cardnum,     // (i) the board number of interest
   char *board_name          // (o) pointer to string that receives board 
                             //     description (if non-null)
)
{
   int board_type;           // contains the current board type identifier
   char *p;                  // receives pointer to the type id string
   int i;                    // loop index
   
   static struct             // contains board types and associated id strings
   {
      int type;              // board type identifier
      char *desc;            // associated board type string
   } type_descs[] = 
   {
      { CEI_220,            "CEI-220"          }, // 0x0
      { CEI_420,            "CEI-420"          }, // 0x1
      { CEI_220 | IS_6WIRE, "CEI-220 (6-wire)" }, // 0x2
      { CEI_420_70J,        "CEI-420-70J"      }, // 0x3
      { CEI_420 | IS_717,   "CEI-420-xxJ"      }, // 0x4
      { CEI_420A_12,        "CEI-420A@12"      }, // 0x5
      { CEI_420A,           "CEI-420A"         }, // 0x6
      { CEI_420A | IS_717,  "CEI-420A-xxJ"     }, // 0x7
      { CEI_520,            "CEI-520"          }, // 0x8
      { CEI_520 | IS_717,   "CEI-520-717"      }, // 0x9
      { CEI_620,            "CEI-620"          }, // 0xA
      { CEI_620 | IS_717,   "CEI-620-J"        }, // 0xB
      { CEI_520 | IS_CSDB,  "CEI-520-C"        }, // 0xC
      { CEI_820,            "CEI-820"          }, // 0xD
      { CEI_820 | IS_717,   "CEI-820-J"        }, // 0xE
      { CEI_820 | IS_6WIRE, "CEI-820 (6-wire)" }, // 0xF01
      { CEI_820TX,          "CEI-820TX"        }, // 0xF02 / 0xF03
      { CEI_520A,           "CEI-520A"         }, // 0xF04
      { CEI_520A | IS_717,  "CEI-520A-717"     }, // 0xF05
      { CEI_520A | IS_CSDB, "CEI-520A-C"       }, // 0xF06
   };

   // save the number of board types
   static int num_board_types = sizeof(type_descs) / sizeof(type_descs[0]);

   // get the current board type
   board_type = ar_get_boardtype((short)cardnum);

   // if board number out of range return error
   if (cardnum >= MAX_BOARDS)
      p = ar_get_error(ARS_INVBOARD);

   // if board is not initialized return error
   else if (ar_board[cardnum].ar_inited == 0)
      p = ar_get_error(ARS_BRDNOTLOAD);

   // attempt to find the CEI-x20 board type string
   else 
   {
      for (i=0,p=NULL;i < num_board_types;i++) 
      {
         // keep checking if this isn't the right type
         if (type_descs[i].type != board_type)
            continue;

         // save the type description string and break
         p = type_descs[i].desc;
         break;
      }
   }

   // check if the board type is unknown
   if (p == NULL)
      p = "Unknown Board Type";

   // store a copy of the string (if board_name is non-null)
   if (board_name)
      strcpy(board_name,p);

   // return the board type description string
   return p;
}


/*============================================================================*
 * ENTRY POINT:       A R _ G E T _ B O A R D N A M E L V 
 *============================================================================*
 *
 * FUNCTION:    Decode the board type and store an ASCII description of the 
 *              board type in the supplied buffer. This function is here to 
 *              support LabView.
 *              
 * RETURN VAL:  ARS_NORMAL        operation completed successfully
 *              ARS_INVBOARD      board number invalid
 *              ARS_BRDNOTLOAD    board not initialized
 *              ARS_INVARG        buffer parameter was null
 *              
 * DESCRIPTION: Decode the board type and store a textual description of the
 *              board in ASCII. 
 *
 *============================================================================*/
EXPORT32 int DLL_EXPORTED ar_get_boardnameLV
(
   unsigned int cardnum,     // (i) the board number of interest
   char *board_name          // (o) pointer to string that receives board 
                             //     description
)
{
   // validate the board number argument
   short status = check_dev_arg(cardnum);
   if (status != ARS_NORMAL)
      return status;

   // make sure the supplied buffer is non-null
   if (board_name == NULL)
      return ARS_INVARG;

   // save the board description and return
   strcpy(board_name,ar_get_boardname(cardnum,NULL));
   return ARS_NORMAL;
}


/*===========================================================================*
 * ENTRY POINT:       A R _ S E T _ A R I N C _ C O N F I G
 *===========================================================================*
 *
 * FUNCTION:    Channel-specific wrapper for AR_SET_CONFIG. See AR_SET_CONFIG
 *              for details.
 *
 * RETURN VAL:  See AR_SET_CONFIG for details.
 *
 * DESCRIPTION: See AR_SET_CONFIG for details.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_set_arinc_config
(
   short cardnum,            // (i) the board number of interest
   short channel,            // (i) the channel to modify
   short item,               // (i) the item that gets modified
   unsigned long value       // (i) the value to set the item
)
{
   // wrap the standard configuration call
   return ar_set_config(cardnum,(short)(channel + item),value);
}


/*===========================================================================*
 * ENTRY POINT:              A R _ S E T _ H A R R I S
 *===========================================================================*
 *
 * FUNCTION:    Alternative for AR_SET_CONFIG. See AR_SET_CONFIG for details.
 *
 * RETURN VAL:  See AR_SET_CONFIG for details.
 *
 * DESCRIPTION: See AR_SET_CONFIG for details.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_set_harris
(
   short cardnum,            // (i) the board number of interest
   short item,               // (i) the item to modify
   unsigned long value       // (i) the value to set the item
)
{
   // wrap the standard configuration call
   return ar_set_config(cardnum,item,value);
}


/*===========================================================================*
 * ENTRY POINT:              A R _ G E T _ H A R R I S
 *===========================================================================*
 *
 * FUNCTION:    Alternative for AR_GET_CONFIG. See AR_GET_CONFIG for details.
 *
 * RETURN VAL:  See AR_GET_CONFIG for details.
 *
 * DESCRIPTION: See AR_GET_CONFIG for details.
 *
 *===========================================================================*/
EXPORT32 long int DLL_EXPORTED ar_get_harris
(
   short cardnum,            // (i) the board number of interest
   short item                // (i) the item of interest
)
{
   // wrap the standard configuration call
   return ar_get_config(cardnum,item);
}


/*===========================================================================*
 * INTERNAL ROUTINE:       I S _ C O N F I G _ I T E M
 *===========================================================================*
 *
 * FUNCTION:    Determine if the given configuration item code belongs to the
 *              specified item class.
 *
 * RETURN VAL:  True if the given item falls within the specified item class, 
 *              false otherwise.
 *
 * DESCRIPTION: If the given item falls within the specified item class, 
 *              return true and store the extracted number. Otherwise, return 
 *              false.
 *
 *===========================================================================*/
static int is_config_item
(
   int item_class,           // (i) item classification
   int item,                 // (i) item code to check
   int *chan                 // (o) receives channel (if applicable)
)
{
   static struct             // contains item classes and associated base indices
   {
      int item_class;        // item classification constant
      int old_base;          // old base index for this item class
      int new_base;          // new base index for this item class
   } class_list[] = 
   {
      { ARU_ITEM_RX_CHxx_BIT_RATE,     ARU_OLD_RX_CH01_BIT_RATE,     ARU_RX_CH01_BIT_RATE     },
      { ARU_ITEM_TX_CHxx_BIT_RATE,     ARU_OLD_TX_CH01_BIT_RATE,     ARU_TX_CH01_BIT_RATE     },
      { ARU_ITEM_RX_CHxx_PARITY,       ARU_OLD_RX_CH01_PARITY,       ARU_RX_CH01_PARITY       },
      { ARU_ITEM_TX_CHxx_PARITY,       ARU_OLD_TX_CH01_PARITY,       ARU_TX_CH01_PARITY       },
      { ARU_ITEM_RX_CHxx_SDI_FILTER,   ARU_OLD_RX_CH01_SDI_FILTER,   ARU_RX_CH01_SDI_FILTER   },
      { ARU_ITEM_RX_CHxx_SDI_VALUE,    ARU_OLD_RX_CH01_SDI_VALUE,    ARU_RX_CH01_SDI_VALUE    },
      { ARU_ITEM_TX_CHxx_SHUT_OFF,     ARU_OLD_TX_CH01_SHUT_OFF,     ARU_TX_CH01_SHUT_OFF     },
      { ARU_ITEM_CHxx_SCHEDULED_MODE,  ARU_OLD_CH01_SCHEDULED_MODE,  ARU_CH01_SCHEDULED_MODE  },
      { ARU_ITEM_CHxx_BURST_MODE,      ARU_OLD_CH01_BURST_MODE,      ARU_CH01_BURST_MODE      },
      { ARU_ITEM_CHxx_ENABLE_TIMETAG,  ARU_OLD_CH01_ENABLE_TIMETAG,  ARU_CH01_ENABLE_TIMETAG  },
      { ARU_ITEM_CHxx_DISABLE_TIMETAG, ARU_OLD_CH01_DISABLE_TIMETAG, ARU_CH01_DISABLE_TIMETAG },
      { ARU_ITEM_CHxx_BUFFERED,        ARU_OLD_CH01_BUFFERED,        ARU_CH01_BUFFERED        },
      { ARU_ITEM_CHxx_DEDICATED,       ARU_OLD_CH01_DEDICATED,       ARU_CH01_DEDICATED       },
      { ARU_ITEM_CHxx_MERGED,          ARU_OLD_CH01_MERGED,          ARU_CH01_MERGED          },
      { ARU_ITEM_TX_CHxx_HB_INJ,       ARU_OLD_TX_CH01_HB_INJ,       ARU_TX_CH01_HB_INJ       },
      { ARU_ITEM_TX_CHxx_LB_INJ,       ARU_OLD_TX_CH01_LB_INJ,       ARU_TX_CH01_LB_INJ       },
      { ARU_ITEM_TX_CHxx_GAP_INJ,      ARU_OLD_TX_CH01_GAP_INJ,      ARU_TX_CH01_GAP_INJ      },
      { ARU_ITEM_DAC_VALUE_xx,         ARU_OLD_DAC_VALUE_01,         ARU_DAC_VALUE_01         },
      { ARU_ITEM_OUTPUT_LEVEL_ADJ_xx,  ARU_OLD_OUTPUT_LEVEL_ADJ_01,  ARU_OUTPUT_LEVEL_ADJ_01  }
   };

   // check for invalid item class
   if ((unsigned int)item_class >= (sizeof(class_list) / sizeof(class_list[0])))
      return FALSE;

   // make sure the item class matches
   if (class_list[item_class].item_class != item_class)
      return FALSE;

   // initialize the channel value
   *chan = -1;

   // check if the item is within the old or new min and max
   if ((item >= class_list[item_class].old_base) && (item < (class_list[item_class].old_base + 16))) 
      *chan = item - class_list[item_class].old_base;
   else if ((item >= class_list[item_class].new_base) && (item < (class_list[item_class].new_base + 32))) 
      *chan = item - class_list[item_class].new_base;

   // return success if the channel is valid and within the class
   return (((*chan != -1) && (*chan < MAX_CHAN)) ? (TRUE) : (FALSE));
}
