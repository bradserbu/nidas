/*===========================================================================*
 * FILE:                        A P I 2 2 0 . C
 *===========================================================================*
 *
 * COPYRIGHT (C) 1998 - 2003 BY
 *          CONDOR ENGINEERING, INC., SANTA BARBARA, CALIFORNIA
 *          ALL RIGHTS RESERVED.
 *
 *          THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY BE USED AND
 *          COPIED ONLY IN ACCORDANCE WITH THE TERMS OF SUCH LICENSE AND WITH
 *          THE INCLUSION OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY
 *          OTHER COPIES THEREOF MAY NOT BE PROVIDED OR OTHERWISE MADE
 *          AVAILABLE TO ANY OTHER PERSON.  NO TITLE TO AND OWNERSHIP OF THE
 *          SOFTWARE IS HEREBY TRANSFERRED.
 *
 *          THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT
 *          NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY CONDOR
 *          ENGINEERING.
 *
 *===========================================================================*
 *
 * FUNCTION: Utility routines for use with CEI-220/420/420A ARINC-429 boards
 *
 * DESCRIPTION: This file contains function definitions for all routines
 *      outlined in the CEI-x20 users manual as well as related
 *      functions and debug utilities.
 *
 * ENTRY POINTS: The following routines are contained herein:
 *
 * USER ENTRY POINTS:
 *      ar_close()            - Close the memory mapping and shut down the board
 *      ar_clr_rx_count()     - Zero out count of received data words
 *      ar_define_msg()       - Define a scheduled transmission message
 *      ar_get_boardtype()    - Return the board type.
 *      ar_get_config()       - Return information on the current ARINC config
 *      ar_get_error()        - Return an error string for a status code
 *      ar_get_harris()       - Same as ar_get_config()(historical compatibility)
 *      ar_get_label_filter() - Determine the label filter
 *      ar_get_latest()       - Get the latest data & sequence number for label
 *      ar_get_raw_mode()     - Get raw mode (no parity) status
 *      ar_get_rx_count()     - Get count of received data words for a channel
 *      ar_get_timercnt       - Get the current number of timer ticks (16-bit)
 *      ar_get_timercntl()    - Get the current number of timer ticks (32-bit)
 *      ar_getblock()         - Get a block of data from a receiver
 *      ar_getnext()          - Get next ARINC word, waiting for .25 seconds
 *      ar_getnextt()         - Get next word (with time tag). Try a few times.
 *      ar_getword()          - Get the next ARINC word if available
 *      ar_getwords()         - Get the next block of data from a receiver's buffer.
 *      ar_getwordst()        - Like ar_getwords() with time tags.
 *      ar_getwordt()         - Get next word if available with time tag
 *      ar_go()               - Start the slave processor.
 *      ar_init_dual_port()   - Initialize all of dual-port memory
 *      ar_init_slave()       - Initialize the receive & transmit buffers
 *      ar_int_control()      - Enable/disable hardware interrupts on the slave.
 *      ar_int_set()          - Set the ISA-bus interrupt number.
 *      ar_int_slave()        - Interrupt the slave.
 *      ar_label_filter()     - Enable/disable label filter function on slave.
 *      ar_loadslv()          - Load the firmware into the i960 and start it
 *      ar_modify_msg()       - Modify the data in a scheduled message
 *      ar_msg_control()      - Select scheduled or burst transmission mode
 *      ar_num_rchans()       - get the number of receive channels
 *      ar_num_xchans()       - get the number of transmit channels
 *      ar_putblock()         - Put multiple labels into the sequential buffer
 *      ar_putword()          - Put a 32 bit ARINC word into the burst transmit queue
 *      ar_putword2x16()      - Put 2-16 bit words into the burst transmit queue
 *      ar_recreate_parity()  - Recreate the parity bit for a received word
 *      ar_reformat()         - Reformat an ARINC word for transmission
 *      ar_reset()            - Reset the i960 slave processor
 *      ar_reset_int()        - Reset the interrupts from the i960 slave
 *      ar_reset_timercnt()   - Reset the number of timer ticks on the slave
 *      ar_setchparms()       - New style channel setup function (429, 717, etc.)
 *      ar_set_arinc_config() - Alternate interface to ar_set_config()
 *      ar_set_config()       - Set a ARINC control bit in the control word
 *      ar_set_harris()       - Same as ar_set_config()(historical compatibility)
 *      ar_set_raw_mode()     - Disable parity
 *      ar_set_storage_mode() - Select receive data storage mode (ARU_BUFFERED
 *                                                                ARU_DEDICATED
 *                                                                ARU_MERGED   )
 *      ar_set_timercnt()     - Set the number of timer ticks on the slave
 *      ar_set_timerrate()    - Set the timer tick interval
 *      ar_timetag_control()  - Enable/disable time tags
 *      ar_unformat()         - Unformat a received ARINC word
 *      ar_version()          - Gets the software version identification string
 *      ar_xmit_sync()        - Wait for all transmit queue words to be sent
 *
 * INTERNAL NON-USER ENTRY POINTS:
 *      ar_channel_cmd()      - Sends Channel Command.  Used by the ATP.
 *      ar_set_dac_value()    - Sets the DAC value to the i960
 *
 * INTERNAL ROUTINES:
 *      ar_set_cpage()    - Set page register to control page
 *      ar_set_rpage()    - Set page register to receiver page
 *      ar_set_xpage()    - Set page register to transmitter page
 *      ar_get_chantype() - Get the channel type flag
 *      ar_get_filterm()  - Get the filter mask
 *      ar_get_rparity()  - Get receive parity setting
 *      ar_get_rrate()    - Get the receive rate
 *      ar_get_sdival()   - Get the SDI filter value
 *      ar_get_xparity()  - Get the xmtr parity of the ARINC control word
 *      ar_get_xrate()    - Get the transmission rate
 *      ar_set_filterm()  - Set the filter mask
 *      ar_set_rparity()  - Set the receiver parity of the ARINC control word
 *      ar_set_rrate()    - Set the receiver rate
 *      ar_set_sdival()   - Set the SDI filter value 
 *      ar_set_xparity()  - Set the xmtr parity of the ARINC control word
 *      ar_set_xrate()    - Set the transmission rate
 *      ar_write_ARINC()  - Write the value of the ARINC control word
 *
 *===========================================================================*/

/* $Revision: 3648 $
   Date        Revision
  ----------   ---------------------------------------------------------------
  03/20/1998   Release version 1.00 with 12 channel support for the CEI-220.ajh
  03/13/2000   Modified ar_getnext() and ar_getnextt() to poll the board one
               additional time just before timing out.V3.01.ajh
  04/13/2000   Changed -420 code to support the CEI-420A.V3.02.ajh
  04/25/2000   Added ar_close() function.V3.02.ajh
  05/05/2000   Changed board reporting and added support for CEI-620J.V3.03.ajh
  05/16/2000   Split common x20/520 functions out into APIutils.c, changed
               ARS_BOARDNOTLOAD to ARS_BRDNOTLOAD.  Added missing release to
               ar_set_storage_mode().ajh
  07/16/2000   Added support for -717 and CSDB channels.V3.06.ajh
  09/22/2000   Added support for the CEI-420A 16 MHz processor.V3.12.ajh
  09/28/2000   Removed support for the CEI-520/620, completed support for the
               CEI-420A 16 MHz.  Removed ar_get_boardoptions() &
               ar_get_boardconfig().V3.13.ajh
  10/17/2000   Changed FPGA load for CEI-420A-xxJ (0x7).V3.21.ajh
  10/17/2000   CSDB Baud Rates updated for CEI-x20.V3.21.ajh
  01/18/2001   Fixed ar_timetag_control(), single channel cases.V3.24.ajh
  03/18/2001   Modify AR_CLOSE to unmap and close the WinRT interface.V3.24.ajh
  06/08/2001   Modified utildefs.h to correct the definition of the labels
               ARU_CH13_DISABLE_TIMETAG, ARU_CH14_DISABLE_TIMETAG,
               ARU_CH15_DISABLE_TIMETAG, and ARU_CH16_DISABLE_TIMETAG.V3.26.ajh
  10/02/2001   Added ar_loadslv_init_discrete().V3.40.skb
  06/06/2002   Updated to support 32 transmitters and 32 receivers.V3.60.skb
  04/23/2004   Added routines to support AR_EXECUTE_BIT.V3.90.skb
  11/28/2004   Fixed load_i960() to error earlier if memory tast fails.V3.90.jdw
  11/28/2004   Fixed load_fpga() to detect if it is loading nothing.V3.90.jdw
  11/28/2004   Modified for kernel usage support.V3.90.jdw (John Wasinger)
  01/12/2005   Added ar_getwords() V3.90.jdw (John Wasinger)
  01/12/2005   Added ar_getwordst() V3.90.jdw (John Wasinger)
  01/12/2005   Added ar_set_timercnt() V3.90.jdw (John Wasinger)
  01/13/2005   Fixed ar_set_timerrate() to return errors V3.90.jdw (John Wasinger)
 */

#define _UNIX_

#include <linux/delay.h>

//---------------------------------------------------------------------------*
//          INCLUDES, DEFINES and GLOBALS
//---------------------------------------------------------------------------*
#include "../Include/utildefs.h"
#include "api220.h"       /* ARINC CEI-220/420 API-specific include file      */
#include "arincx20.h"     /* ARINC CEI-x20 firmware-specific include file     */
#include "lowlevel.h"     // WinRT mapping functions.

extern void* phys_membase;

#define DLL_EXPORTED
#define EXPORT32
#define FFAR

//---------------------------------------------------------------------------*
//   PROGRAMMER NOTES
//---------------------------------------------------------------------------*
//
//  ---> DOS programmers, and memory-limited applications:
//
//  This software supports all of the variants of the CEI-220, CEI-420
//  and CEI-420A ARINC interface board family.  As such, it contains all
//  of the various initialization arrays, one for each board type.
//
//  This amounts to over 300 KB of memory!
//  If you need a smaller memory footprint for a custom application, you can
//   remove unused fpga configurations as follows:
//
//  1. Determine the configurations to be removed.  For example, if you are
//     using the CEI-420 board only, you have no need for the CEI-220 fpga loads.
//
//  2. Comment out the "#include" line, and substitute "0" for the line.  For
//     example, to remove the CEI-220 561 6-wire configuration, locate the line:
/*
    #include "220_6wir.h"  // Ch 1-4 ARINC-429 R/T channels, Ch 5 561-6 wire, Ch 8-9 429.
*/
//     and replace it with:
/*
    0 // #include "220_6wir.h"  // Ch 1-4 ARINC-429 R/T channels, Ch 5 561-6 wire, Ch 8-9 429.
*/
//     Recompile and link with the new library and your executable now needs
//     29718 fewer bytes to run in!
//
//  If you have any questions, please contact
//       Condor Engineering Technical Support
//---------------------------------------------------------------------------*

//---------------------------------------------------------------------------*
// These are the fpga loads for the CEI-220 (12 MHz):
//---------------------------------------------------------------------------*
static unsigned char FFAR fpga_220_AA[29719] = {        // 0x0 CEI-220.
  0 //#include "fpgaAA.h"    // Number of Receive/Transmit channels
};
static unsigned char FFAR fpga_220_8C[29719] = {        // 0x0 CEI-220.
  0 //#include "fpga8C.h"    // Number of Receive/Transmit channels
};
static unsigned char FFAR fpga_220_C6[29719] = {        // 0x0 CEI-220.
  0 //#include "fpgaC6.h"    // Number of Receive/Transmit channels
};
static unsigned char FFAR fpga_220_CC[29719] = {        // 0x0 CEI-220.  Test FPGA load only.
  0 //#include "fpgaCC.h"    // Number of Receive/Transmit channels
};
static unsigned char FFAR fpga_220_6wir[29719] = {     // 0x2 CEI-220 with 6-wire.
  0 //#include "220_6wir.h"  // Ch 1-4 ARINC-429 R/T channels, Ch 5 561-6 wire, Ch 8-9 429.
};
//                          config      0          1          2          3
//                         channels  rec xmt    rec xmt    rec xmt    rec xmt
static char rec_xmt_config[4][2] = {{ 10, 10}, {  8, 12}, { 12,  6}, { 12, 12}};

//---------------------------------------------------------------------------*
// These are the fpga loads for the CEI-420/420A (12 MHz):
//---------------------------------------------------------------------------*
static unsigned char FFAR fpga_420[41165L] = {  // 0x1 CEI-420 at 12 MHz
                                                // 0x5 CEI-420A_12 at 12 MHz
  0 //#include "fpga420a.h"                       // CEI-420/420A@12, up to 8/8 channels.
};
                                                   // 0x3 CEI-420-70J
static unsigned char FFAR fpga_420_717[41165L] = { // 0x4 CEI-420-xxJ
  0 //#include "cei420_xxj_fpga_rev2.h"  // CEI-420 12 MHz fpga with 717 interface support.
};

//---------------------------------------------------------------------------*
// These are the fpga loads for the CEI-420A (16 MHz):
//---------------------------------------------------------------------------*

static unsigned char FFAR fpga_420A[41165L] = { // 0x6 CEI-420A 16 MHz
#include "fpga420a_16mhz_v100.h"                // CEI-420A, with 8/8 channels.
};

static unsigned char FFAR fpga_420A_717[41165L] = { // 0x7 CEI-420A-xxJ 16 MHz
  0 //#include "fpga420a_xxj_16mhz_v100.h"           // CEI-420A with 717 interface support.
};

//---------------------------------------------------------------------------*
// Removed support for the CEI-520/620 (Support for these products is in
//   the Enhanced API; see the source code file API520.C).V3.13.ajh
//---------------------------------------------------------------------------*

//---------------------------------------------------------------------------*
//  Include the i960 microcode array.  This array is 64Kbytes long, and is
//   loaded at hard-coded offset 0x0000 in dual-port memory.
//---------------------------------------------------------------------------*
unsigned short FFAR i960_data[] = {       // Make far to free up DGROUP.
#include "i960_220.h"                     // CEI-220/420/420A i960 code.
};

char last_error[200] = {"No additional information available"};


// Added to support ar_loadslv_init_discrete() V3.40.skb
int use_init_discrete_override = 0;       // FALSE = don't set initial
                                          //  discrete output value to 
                                          //  'init_discrete_override'
                                          // TRUE = set initial discrete
                                          //  output value to 
                                          //  'init_discrete_override'
unsigned long init_discrete_override = 0; // If 'use_init_discrete_override'
                                          //  is TRUE, then this contains the 
                                          //  desired initial value of the 
                                          //  discrete outputs


//---------------------------------------------------------------------------*
//       DEFINES
//---------------------------------------------------------------------------*

#define RPR        (0x800/2)  /* Word offset CEI-220/420 RAM Page Register  */
#define CEI_ICR    (0x802/2)  /* Word offset CEI-220/420 Interrupt register */
#define RESET_REG  (0x804/2)  /* Word offset CEI-220/420 Reset Control Reg  */
#define CONFIG_REG (0x806/2)  /* Word offset CEI-220/420 FPGA Config Reg    */

#define CEI_PAGE_MASK 0x1FF /* Size of CEI-220/420 access page minus 1 in dwords */

//---------------------------------------------------------------------------*
//  GLOBAL VARIABLES
//---------------------------------------------------------------------------*

struct ARINC_BOARD {
   DEVMAP_T pMap;            /* Board device driver mapping structure  */
   int  board_mapped;        /* Memory mapping status of this board    */
   int  board_ar_go;         /* ar_go() has been called for this board */
   int  ar_inited;           /* Set if board has been initialized      */
   int  board_type;          /* CEI_220/420/420A + options             */
   };                        /* Lower 8 bits are the board type, the   */
                             /*  upper bits indicate the board option. */
                             /* Mask with "API_BOARD_TYPE_MASK" to     */
                             /*  extract the base board type(CEI_xxx). */

//---------------------------------------------------------------------------*
//  ar_static_base[] points to the base of the card.
//---------------------------------------------------------------------------*
static struct CONTROL_DPRAM volatile *ar_static_base[MAX_BOARDS];
// Pointer to CEI-220/420/420A dual port memory, config PROM, etc.
static struct ARINC_BOARD ar_board[MAX_BOARDS]; // 8 boards!

static struct CONTROL_DPRAM volatile *ar_set_cpage(BT_UINT cardnum);
static struct BUFFER_DPRAM volatile *ar_set_rpage(BT_UINT cardnum, int channel, int word);
static struct BUFFER_DPRAM volatile *ar_set_xpage(BT_UINT cardnum, int channel, int word);

//---------------------------------------------------------------------------*
//  Local non-user and non-exported helper definitions.
//---------------------------------------------------------------------------*

static int loader(
   unsigned int  cardnum,         // (i) The board number of interest
   unsigned long EnableTestMode0, // (i) Enable special factory test mode flag
   unsigned long EnableTestMode1);// (i) Enable special factory test mode flag

static short ar_get_filterm(BT_UINT cardnum, int channel);
static short ar_get_rparity(long arinc_cmd);
static short ar_get_rrate  (long arinc_cmd);
static short ar_get_sdival (BT_UINT cardnum, int channel);
static short ar_get_xparity(long arinc_cmd);
static short ar_get_xrate  (long arinc_cmd);
static short ar_get_chantype(short,int,int);
static void  ar_set_filterm(BT_UINT cardnum, long, short *, int);
static void  ar_set_rparity(long *, long, short *);
static void  ar_set_rrate  (long *, long, short *);
static void  ar_set_sdival (BT_UINT cardnum, unsigned long, short *, int);
static void  ar_set_xparity(long *, long, short *);
static void  ar_set_xrate  (long *, long, short *);
static short ar_write_ARINC(BT_UINT cardnum, long rcv, long xmt, int channel);

static int   load_i960(BT_UINT cardnum);
static int   load_fpga(volatile unsigned short *board_ptr, unsigned char FFAR *fpga_data,
                       unsigned long fpga_length);

static unsigned short read_from_board_short(unsigned short volatile *board_ptr,
                                            int offset);
static unsigned long read_from_board_long(unsigned long volatile *board_ptr,
                                          int offset);

//---------------------------------------------------------------------------*
//  Include the source code to the functions that are not specific to a
//   particular board type.
//---------------------------------------------------------------------------*
#include "apiutils.c"

/*===========================================================================*
 * LOCAL ENTRY POINT:        v b t A c q u i r e F r a m e
 *===========================================================================*
 *
 * FUNCTION:    This function acquires control of the frame register.
 *
 * DESCRIPTION: The frame register of the CEI-220 and the CEI-420 is used to
 *              select the page within dual-port memory to be read or written
 *              by the host.
 *              Since there is only one frame register, access to it must be
 *              interlocked so that a thread or interrupt cannot modify the
 *              register while another thread or interrupt function is still
 *              accessing the board.
 *
 *              Note that this function is very time critical.
 *
 *      It will return:
 *              nothing
 *===========================================================================*/
#define vbtAcquireFrame(a)


/*===========================================================================*
 * LOCAL ENTRY POINT:       v b t R e l e a s e F r a m e
 *===========================================================================*
 *
 * FUNCTION:    This function releases control of the frame register.  This
 *              function should be called in pairs with vbtAcquireFrame()
 *              to first acquire then release the ownership of the frame register...
 *
 * DESCRIPTION: The frame register of the CEI-220 and the CEI-420 is used to
 *              select the page within dual-port memory to be read or written
 *              by the host.
 *              Since there is only one frame register, access to it must be
 *              interlocked so that a thread or interrupt cannot modify the
 *              register while another thread or interrupt function is still
 *              accessing the board.
 *
 *              Note that this function is very time critical.
 *
 *      It will return:
 *              nothing
 *===========================================================================*/
#define vbtReleaseFrame(a)


/*===========================================================================*
 * NON-USER ENTRY POINT:        L o c a l P e e k M s g
 *===========================================================================*
 *
 * FUNCTION:    Microsoft Windows PeekMessage() interface.
 *
 * DESCRIPTION: This function is used to cause multi-tasking in 16-bit
 *              Windows, and to allow PostMessage()s to be processed in
 *              32-bit Windows.  It is called by the API during waits.
 *
 *      It will return:
 *              nothing
 *===========================================================================*/
#define LocalPeekMsg()


/*===========================================================================*
 * EXTERNAL NON-USER ENTRY POINT:       A R _ G E T _ B A S E
 *===========================================================================*
 *
 * FUNCTION:    Return the base address of the board.
 *
 * PARAMETERS:  BT_U16BIT board -- (input) board number of interest.
 *              int       page  -- (input) page number
 *
 * RETURN VAL:  struct CONTROL_DPRAM volatile * -- pointer to page
 *
 * DESCRIPTION: This function returns a pointer to the CEI-220/420/420A
 *              dual port RAM beginning at the specified page.  This debug
 *              function is only used by the dump function.
 *===========================================================================*/

static struct CONTROL_DPRAM volatile * ar_get_base(BT_U16BIT cardnum,
                                                   int  page)
{
   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return NULL;

   // Board is a CEI-220/420/420A which has a page register
   ar_static_base[cardnum]->regs.m1[RAM_PAGE_REG] = (short)page;
   return ar_static_base[cardnum];
}

/*===========================================================================*
 * NON-USER ENTRY POINT:       A R _ S E T _ C P A G E
 *===========================================================================*
 *
 * FUNCTION:    Set the page register to map the control page.
 *
 * PARAMETERS:  BT_UINT cardnum -- (input) board number of interest.
 *
 * RETURN VAL:  struct CONTROL_DPRAM volatile * -- pointer to page
 *
 * DESCRIPTION: This function sets the CEI-220/420/420A page register to
 *              map the control page and buffer header values.
 *===========================================================================*/

static struct CONTROL_DPRAM volatile *ar_set_cpage(BT_UINT cardnum)
{
   // Board is a CEI-220/420/420A which has a page register
   ar_static_base[cardnum]->regs.m1[RAM_PAGE_REG] = 2;   // Control page is page two.
   return ar_static_base[cardnum];
}

/*===========================================================================*
 * NON-USER ENTRY POINT:       A R _ S E T _ X P A G E
 *===========================================================================*
 *
 * FUNCTION:    Set the page register to a specified transmitter page.
 *
 * PARAMETERS:  BT_UINT cardnum -- (input) board number of interest.
 *              int    channel -- (input) transmitter channel number.
 *              int    index   -- (input) index of desired label in buffer
 *
 * RETURN VAL:  struct CONTROL_DPRAM volatile * -- pointer to page
 *
 * DESCRIPTION: This function sets the CEI-220/420 page register to a computed
 *              value, making it possible to access the memory mapped by
 *              the specified channel's transmitter buffer, and the index
 *              within that buffer.
 *===========================================================================*/

static struct BUFFER_DPRAM volatile *ar_set_xpage(BT_UINT cardnum, int channel, int index)
{
   int   page;          // Computed target page number

   // Compute the page number for this transmitter, skipping the code pages,
   //  the control page, and take into account the fact that the index could
   //  extend past this channel's buffer into the next channel's buffer.
   page = 3 + channel + (index/512);

   // Board is a CEI-220/420/420A which has a page register
   ar_static_base[cardnum]->regs.m1[RAM_PAGE_REG] = (short)page;
   return (struct BUFFER_DPRAM volatile *)ar_static_base[cardnum];
}

/*===========================================================================*
 * NON-USER ENTRY POINT:       A R _ S E T _ R P A G E
 *===========================================================================*
 *
 * FUNCTION:    Set the page register to a specified receiver buffer page.
 *
 * PARAMETERS:  BT_UINT cardnum -- (input) board number of interest.
 *              int    channel  -- (input) receiver channel number.
 *              int    index    -- (input) index of desired label in buffer
 *
 * RETURN VAL:  struct CONTROL_DPRAM volatile * -- pointer to page
 *
 * DESCRIPTION: This function sets the CEI-220/420/420A page register to
 *              a computed value, making it possible to access the memory
 *              mapped by the specified channel's receiver buffer, and the
 *              index within that buffer.
 *===========================================================================*/

static struct BUFFER_DPRAM volatile *ar_set_rpage(BT_UINT cardnum,
                                                   int channel, int index)
{
   int   page;          // Computed target page number

   // Compute the page number for this receiver, skipping the code pages, the
   //  control page, the transmitter pages, and take into account the fact
   //  that the index could extend past this channel's buffer into the next
   //  channel's buffer.
   page = 3 + MAX_XMTRS + channel + (index/512);

   // Board is a CEI-220/420/420A which has a page register
   ar_static_base[cardnum]->regs.m1[RAM_PAGE_REG] = (short)page;
   return (struct BUFFER_DPRAM volatile *)ar_static_base[cardnum];
}

/*===========================================================================*
 * NON-USER ENTRY POINT:       A R _ C H A N N E L _ C M D
 *===========================================================================*
 *
 * FUNCTION:    Pass a channel command to the CEI-220/420/420A
 *
 * PARAMETERS:  BT_UINT cardnum    -- (input) board number of interest.
 *              long   command     -- (input) command the board should execute.
 *              long   parameter1  -- (input) parameter to board channel cmd.
 *              int    chan_enable -- (input) mask indicating channels to cmd.
 *
 * RETURN VAL:  short -- ARS_INVBOARD      Board number out of range
 *                       ARS_BRDNOTLOAD    ar loadslv() not called
 *                       ARS_CHAN_TIMEOUT  timeout waiting for response from 960
 *                       ARS_NORMAL        command completed without error
 *
 * DESCRIPTION: This sends a command to the ARINC interface causing it to
 *      begin processing ARINC data.  Once the interface is started it goes
 *      into an endless loop processing ARINC data until the routine AR_RESET
 *      is executed.  No ARINC data will be received or sent until the board
 *      is in the "GO" state achieved by this routine.
 *      This function is called by the ATP, and therefor must be public.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_channel_cmd(BT_UINT cardnum, long command,
                                 long parameter1, unsigned int chan_enable_mask)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int      channel;      // We need to start ALL of the channels independently
   int      goal;         // Timeout waiting for board to execute command

   // If board number out of range return nothing.
   if ( cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // Now command all of the channels as specified.
   for ( channel = 0; channel < MAX_CHAN; channel++ )
   {
      // Omit any channels not enabled by the caller.
      if ( chan_enable_mask & (1 << channel) )
      {
         vbtAcquireFrame(cardnum);            // The page register is ours...
         ar_base = ar_set_cpage(cardnum);     // Go to control page zero.
         ar_base->channel    = channel;
         ar_base->parameter1 = parameter1;
         ar_base->command = command;     // Must write command last.

         // Each read of DP takes around 1-2 microseconds.  Delay up to 4 ms.
         // Board should be finished in less than 360 us.  This test is independent
         //  of processor speed, it mainly depends on the ISA/PCI bus access times.
         // DO NOT REMOVE DOUBLE READS!
         for ( goal = 0; goal < 4000; goal++ )
         {
            // Must read twice in case the i960 is writing...
            if ( read_from_board_long(&ar_base->command, 0) == 0 )
               if ( read_from_board_long(&ar_base->command, 0) == 0 )
                  break;
         }
//       KLOG_DEBUG("goal: %d", goal);
         vbtReleaseFrame(cardnum);            // Let someone else get in...
         if ( ar_base->command )
            return ARS_CHAN_TIMEOUT;
      }
   }
   return ARS_NORMAL;
}

/* // DEBUG trace wrapper... */
/* EXPORT32 short DLL_EXPORTED jdw_channel_cmd(BT_UINT cardnum, long command, */
/*                                  long parameter1, unsigned int chan_enable_mask, */
/*                                  char *file, char *func) */
/* { */
/*   KLOG_DEBUG("%s: %s: is calling ar_channel_cmd()\n",file, func); */
/*   return ar_channel_cmd(cardnum, command, parameter1, chan_enable_mask); */
/* } */

/* #define ra_channel_cmd(cn, cm, pa, ch) \ */
/*                 jdw_channel_cmd (cn, cm, pa, ch, __FILE__, __FUNCTION__) */


/*===========================================================================*
 * ENTRY POINT:         A R _ C L R _ R X _ C O U N T
 *===========================================================================*
 *
 * FUNCTION:    Reset the number of received words to zero.
 *
 * PARAMETERS:  short cardnum -- (input) The board number of interest
 *              short channel -- (input) The receive channel number
 *
 * RETURN VAL:  none
 *
 * DESCRIPTION: The firmware maintains a count of ARINC data words received
 *      over the interface for each channel since the interface was
 *      initialized or since the count was reset.  This routine resets the
 *      count for a particular channel to zero.  To read the current value of
 *      the count, see the routine AR_GET_RX_COUNT.
 *
 *===========================================================================*/

EXPORT32 void DLL_EXPORTED ar_clr_rx_count(short cardnum, short channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return;

   // If channel number out of range return nothing.
   if ( (unsigned)channel > MAX_CHAN )
      return;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.

   // DO NOT REMOVE DOUBLE WRITES!
   ar_base->rcvr_rx_count[channel] = 0; // Clear number of labels rcvd,
   ar_base->rcvr_rx_count[channel] = 0; //  twice in case i960 is writing.
   vbtReleaseFrame(cardnum);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ D E F I N E _ M S G
 *===========================================================================*
 *
 * FUNCTION:    Define a message to the slave for automatic scheduling.
 *
 * PARAMETERS:  short cardnum        -- (input) The board number of interest
 *              short channel        -- (input) Transmit channel of interest
 *              short rate           -- (input) The retransmission rate of the
 *                                      message in board clk ticks.
 *              unsigned short start -- (input) The initial delay (in ticks)
 *                                      from the current time until the
 *                                      message will be transmitted for the
 *                                      first time.  Subsequent transmissions
 *                                      of this data will be at the rate
 *                                      defined in the previous argument.
 *              long ARINC_word      -- (input) The ARINC data to transmit.
 *
 * RETURN VAL:  short -- ARS_INVBOARD     Board number out of range.
 *                    -- ARS_BRDNOTLOAD Board not loaded and initialized.
 *                    -- ARS_INVARG   Scheduled transmission mode has net been
 *                                    previously selected or an invalid channel
 *                                    was specified or the maximum number of
 *                                    messages has already been defined.
 *                    -- message_num  A return value in the range of o-47
 *                                    indicates success and is the unique
 *                                    message number assigned to this message.
 *                                    Each cahnnel assigns message numbers in
 *                                    this range.
 *
 *     dword offset 0 - Label to be transmitted
 *     dword offset 1 - Next transmission time
 *     dword offset 2 - Transmission interval.  Never zero!
 *     dword offset 3 - Non-zero if transmission enabled, zero to disable label
 *
 * DESCRIPTION: This routine defines a message to the ARINC interface for
 *      periodic retransmission.  It is only applicable to scheduled
 *      transmission mode (see AR_MSG_CONTROL).  It defines a specific data
 *      word to go out at a specific rate.  Up to 48 individual, one-word
 *      messages can be scheduled for retransmission on each channel.  Once a
 *      message has been defined, it can be modified by calling AR_MODIFY_MSG.
 *      Messages can be defined after the board has been started with AR_GO.
 *
 *      The message rate is defined as a number of clk ticks.  The time
 *      represented by a clk tick is specified with the routine
 *      AR_SET_TIMERRATE.  It is recommended that the nominal value for this
 *      be set to 1 MS.  Due to performance considerations, it is recommended
 *      that messages with the faster rates be defined before the slower ones.
 *      If rate is zero, than the message is created but it will not be
 *      scheduled for transmission.
 *
 *      NOTE: Type of 4th param has changed from INT to UNSIGNED SHORT.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_define_msg(short cardnum, short channel,
                                          short rate, unsigned short start,
                                          long ARINC_word)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;
   unsigned n_msgs;              // Number of scheduled messages
   long     timer_count1;        // Current time
   long     timer_count2;        // Current time
   int      i;                   // Loop Counter

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel number out of range return error.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                 // Go to control page zero.

   // Check if too many messages are being defined.
   n_msgs = ar_base->xmtr[channel].num_scheduled;
   if ( n_msgs >= MAX_PERIODIC_MSGS )
   {
      vbtReleaseFrame(cardnum);
      return ARS_INVARG;
   }
   // Keep reading the current time until it is stable to prevent reading the
   //  time while the i960 was updating it.
   while (1) {
      timer_count1 = read_from_board_long(&ar_base->TickTimer, 0);
      timer_count2 = read_from_board_long(&ar_base->TickTimer, 0);
      if ( timer_count1 == timer_count2 ) break;
      msleep(1);
   }
   // Adjust start time to beginning of "frame".
   if ( rate )
      timer_count1 = (timer_count1/rate) * rate;

   // Go to the transmit buffer for the specified channel.
   ar_buf = ar_set_xpage(cardnum, channel, 4*n_msgs);

   // Write an "end of list" label into the next 2 message slots.
   for ( i = 4; i < 12; i++ )
      ar_buf->buf[4*n_msgs+i] = 0xFFFFFFFFL;  // End of list.

   // Load the new message into DP, all messages fit into one 2Kbyte page...
   ar_buf->buf[4*n_msgs+0] = ARINC_word;        // ARINC data word.
   ar_buf->buf[4*n_msgs+1] = timer_count1+start;// First xmit time.
   if ( rate )
   {
      ar_buf->buf[4*n_msgs+2] = rate;      // Save time interval.
      ar_buf->buf[4*n_msgs+3] = 1;         // Enable this label.
   }
   else
   {
      ar_buf->buf[4*n_msgs+2] = 1;         // Set interval to one tick.
      ar_buf->buf[4*n_msgs+3] = 0;         // Disable this label.
   }

   ar_base = ar_set_cpage(cardnum);               // Go to control page zero.

   // Increment the number of messages defined.  The i960 does not use this
   //  number for anything, it uses the end of list marker.
   ar_base->xmtr[channel].num_scheduled = (short)(n_msgs+1);
   vbtReleaseFrame(cardnum);
   return (short)n_msgs;        // Return the message number of the new message.
}

/*===========================================================================*
 * ENTRY POINT:         A R _ M O D I F Y _ M S G
 *===========================================================================*
 *
 * FUNCTION:    Modify the current status of a message.  To disable a message,
 *              setup a rate of zero.
 *
 * PARAMETERS:  short cardnum -- (input) The board number of interest
 *              short channel -- (input) The transmit channel to use
 *              short msg_num -- (input) The message number to update.  This
 *                               value was returned by a previous call to
 *                               AR_DEFINE_MSG
 *              short rate    -- (input) Update rate of the message in clk
 *                               ticks.
 *              long data     -- (input) New ARINC data.
 *
 *
 * RETURN VAL:  short -- ARS_INVBOARD The specified board is a CEI-100.
 *                    -- ARS_INVARG   Scheduled transmission mode has net been
 *                                    previously selected, an invalid channel
 *                                    was specified or an invalid message
 *                                    number has been specified.
 *
 *     dword offset 0 - Label to be transmitted
 *     dword offset 1 - Next transmission time
 *     dword offset 2 - Transmission interval.  Never zero!
 *     dword offset 3 - Non-zero if transmission enabled, zero to disable label
 *
 * DESCRIPTION: This routine modifies the data and/or update rate of a message
 *      being scheduled by the ARINC interface.  It is only applicable to
 *      Scheduled transmission mode (see AR_MSG_CONTROL).  It can only be
 *      called to modify data for a message that has been defined with a
 *      previous call to AR_DEFINE_MSG.  Once a call to this subroutine is
 *      completed, all subsequent scheduled transmissions will use the rate
 *      and data defined here.
 *
 *      To disable a previously scheduled message, call this routine with a
 *      value of 0 for the rate argument.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_modify_msg(short cardnum, short channel,
                                   short msg_num, short rate, long data)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel number out of range return error.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Check if message is not defined.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                 // Go to control page zero.
   if ( msg_num >= (short)(ar_base->xmtr[channel].num_scheduled) )
   {
      vbtReleaseFrame(cardnum);
      return ARS_INVARG;
   }
   // Load the new message data into DP.  All msgs fit into a CEI-220/420 page...
   // Go to transmit buffer for this channel.
   ar_buf = ar_set_xpage(cardnum, channel, 4*msg_num);

   // Note that updating the ARINC word might cause the i960 to fetch
   //  junk from dual-port, but only for one message time...
   ar_buf->buf[4*msg_num+0] = data;   // New ARINC data word.
   if ( rate )
   {
      ar_buf->buf[4*msg_num+2] = rate;   // New delay time to DP, and
      ar_buf->buf[4*msg_num+3] = 1;      //   enable label.
   }
   else
   {
      ar_buf->buf[4*msg_num+3] = rate;   // Disable label, leave rate alone
   }

   vbtReleaseFrame(cardnum);
   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ M S G _ C O N T R O L
 *===========================================================================*
 *
 * FUNCTION:    Enable/disable automatic message scheduling on the slave.
 *              If enabled, then normal circular buffering is not available.
 *
 * PARAMETERS:  short cardnum  -- (input) The board number of interest
 *              short control  -- (input) Flag to control transmission mode.
 *                                  Valid values are:
 *                                  AR_ON  enable Scheduled Transmission mode
 *                                         (disable Burst Transmission mode)
 *                                  AR_OFF disable Scheduled Transmission mode
 *                                         (enable Burst Transmission mode)
 *
 * RETURN VAL:  short -- ARS_INVBOARD  The selected board is a CEI-100
 *                    -- ARS_IVARG     An invalid argument was used
 *                    -- ARS_NORMAL    Normal successful return
 *
 * DESCRIPTION: See manual.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_msg_control(short cardnum, short control)
{
   int chan;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return 0;

   if ( control == AR_ON )
   {  // Command the board to transmit mode "control", all channels.
      return ar_channel_cmd(cardnum, CHAN_CMD_X_MODE, control, 0xFFFF);
   }
   else if ( control == AR_OFF )
   {  // Command the board to transmit mode "control", all channels.
      return ar_channel_cmd(cardnum, CHAN_CMD_X_MODE, control, 0xFFFF);
   }
   else if (is_config_item(ARU_ITEM_CHxx_SCHEDULED_MODE,control,&chan))
   {  // Command the board to Scheduled transmit mode, specified channel.
      // The firmware will clear the number of scheduled messages.V2.64.ajh
      return ar_channel_cmd(cardnum, CHAN_CMD_X_MODE, AR_ON, 1 << chan);
   }
   else if (is_config_item(ARU_ITEM_CHxx_BURST_MODE,control,&chan))
   {  // Command the board to Burst transmit mode, specified channel.
      return ar_channel_cmd(cardnum, CHAN_CMD_X_MODE, AR_OFF, 1 << chan);
   }
   return ARS_INVARG;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ L A T E S T
 *===========================================================================*
 *
 * FUNCTION:    Function to return the latest value for a label/channel.
 *              This is used only in "DEDICATED" storage mode.
 * 
 * PARAMETERS:  short cardnum        -- (input) The board number of interest
 *              short channel        -- (input) The receive channel number
 *              unsigned short label -- (input) The label number
 *              void * userdata      -- (output) The address of the location to
 *                                      receive the 32 bit ARINC word.
 *              char * seq_num       -- (output) The address of the location to
 *                                      receive the 8-bit sequence number
 * 
 * RETURN VAL:  void 
 *
 * DESCRIPTION: This routine retrieves ARINC data when "Dedicated: data storage
 *      mode is in effect (see AR_SET_STORAGE_MODE).  It will return the most 
 *      recently received data for a selected label and channel.  It also 
 *      returns an eight bit sequence number that indicates the number of 32
 *      bit ARINC words received for that combination of label and channel.
 *
 *      NOTE: If no data has been received, this routine will return a word
 *      with zero in all bits except for the label field which will have the 
 *      requested label value.  This is because the sequence number is stored 
 *      in the label field on the hardware and the label is re-inserted by this
 *      routine after the sequence number has been extracted from the hardware 
 *      data.
 *            
 *      NOTE: Type of 3rd param has changed from INT to UNSIGNED CHAR.
 *
 *===========================================================================*/
                                                                             
EXPORT32 void DLL_EXPORTED ar_get_latest(short cardnum, short channel,
                                  unsigned short label, void *userdata,
                                  char *seq_num)
{
   struct BUFFER_DPRAM volatile *ar_buf; // Current board pointer.
   volatile long ARINC_word1,  ARINC_word2;
   volatile long label_count1, label_count2;

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return;

   vbtAcquireFrame(cardnum);
   ar_buf = ar_set_rpage(cardnum, channel, label*2);  // Go to receiver page for this channel.

   // Keep reading the data until it is stable to prevent reading the data
   //  while the i960 was updating it.  This is necessary since the i960 can
   //  update any label at any time.
   while (1) {
      ARINC_word1  = read_from_board_long(ar_buf->buf, CEI_PAGE_MASK & (label*2+0));
      ARINC_word2  = read_from_board_long(ar_buf->buf, CEI_PAGE_MASK & (label*2+0));
      label_count1 = read_from_board_long(ar_buf->buf, CEI_PAGE_MASK & (label*2+1));
      label_count2 = read_from_board_long(ar_buf->buf, CEI_PAGE_MASK & (label*2+1));
      if ( (ARINC_word1 == ARINC_word2) && (label_count1 == label_count2) ) break;
      msleep(1);
   }
   vbtReleaseFrame(cardnum);

   // Return the sequence number to the caller.
   seq_num[0] = (char)label_count1;

   // If this label has not been received the label value will be zero...
   //  This is a deviation from the performance of the CEI-100/200 product.
   *(long *)userdata = ARINC_word1;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ R X _ C O U N T
 *===========================================================================*
 *
 * FUNCTION:    Get number of received words.
 * 
 * PARAMETERS:  short cardnum  -- (input) The board number of interest
 *              short channel  -- (input) The receive channel number
 * 
 * RETURN VAL:  unsigned long -- Count of ARINC data words
 *
 * DESCRIPTION: The software maintains a count of the number of ARINC data 
 *      words received over the interface for each channel since the interface
 *      was initialoized or since the count was reset (AR_CL_RX_COUNT).  This 
 *      routine returns that number.
 *                                        
 *===========================================================================*/   
 
EXPORT32 unsigned long DLL_EXPORTED ar_get_rx_count(short cardnum, short channel)
{
   struct CONTROL_DPRAM volatile *ar_base;      // Current board pointer.
   volatile long label_count1, label_count2;

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);               // Go to control page zero.

   // Keep reading the data until it is stable to prevent reading the data
   //  while the i960 was updating it.
   while (1) {
     label_count1 = read_from_board_long(ar_base->rcvr_rx_count, channel);
     label_count2 = read_from_board_long(ar_base->rcvr_rx_count, channel);
     if ( label_count1 == label_count2 ) break;
     msleep(1);
   }
   // Return the number of ARINC data words received by this channel.
   vbtReleaseFrame(cardnum);
   return label_count1;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ T I M E R C N T L
 *===========================================================================*
 *
 * FUNCTION:    This routine returns the number of timer ticks that have
 *      occurred on the slave.  This is a 32-bit integer that will wrap
 *      around periodically.
 *
 * PARAMETERS:  short cardnum     -- (input) The board number of interest
 *
 * RETURN VAL:  unsigned long   -- the number of timer ticks
 *
 * DESCRIPTION: The ARINC interface is programmed to maintain an elapsed time
 *      count in "ticks".  This routine returns the number of ticks that have
 *      occured since the timer was initialized (AR_LOADSLV) or since the
 *      counter was reset to zero (AR_RESET_TIMERCNT).  This value determines
 *      if a specific time interval has passed to help in the timed
 *      retransmission of ARINC data.  The resolution of a tick is programmable
 *      through the routine AR_SET_TIMERRATE.
 *
 *===========================================================================*/

EXPORT32 unsigned long DLL_EXPORTED ar_get_timercntl(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base;      // Current board pointer.
   volatile long timer_count1, timer_count2;

   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.

   // Keep reading the data until it is stable to prevent reading the data
   // while the i960 was updating it.
   while (1) {
      timer_count1 = read_from_board_long(&ar_base->TickTimer, 0);
      timer_count2 = read_from_board_long(&ar_base->TickTimer, 0);
      if ( timer_count1 == timer_count2 ) break;
      msleep(1);
   }
   // Return the current timer tick counter.
   return timer_count1;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T B L O C K
 *===========================================================================*
 *
 * FUNCTION:    Get multiple words from a specified channel's receive buffer
 *
 * RETURN VAL:  short -- ARS_NO_HW_SUPRT no support for this function.
 *
 * DESCRIPTION: This routine gets all of the available ARINC words from the
 *      requested channel's buffer and puts them in the desired destination.
 *
 *      If time tagging is enabled for this channel then the time tags are
 *      copied to the "TimeTag" destination.  If time tagging is not enabled
 *      then this pointer is not used.  If this pointer is NULL and time tags
 *      are enabled then the time tags are fetched and discarded.
 *
 *      ARINC-573/717 data contains the time tag in the upper bits of the data
 *      word.  This time tag is returned as part of the ARINCdata array, NOT
 *      in the TimeTag array.
 *
 *      If the buffer is empty this routine returns ARS_NODATA.
 *
 *      If ( ActualCount == MaxWords ) when this function returns, there may
 *      or may not be more data in the buffer.
 *      Subsequent calls are required to determine if more words are available
 *      in the buffer.
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_getblock(
   unsigned int cardnum,    // (i) The board number of interest
   unsigned int channel,    // (i) The channel from which to get the data (0-based)
   int          MaxWords,   // (i) The maximum number of 32-bit ARINC words to return.
                            //     If time tags are enabled this is the number of
                            //     labels to return; an equal number of time tags
                            //     will be returned if TimeTag is not a NULL pointer.
   int          Offset717,  // (i) Beginning offset in frame if this is a 573/717
                            //     receiver.  "MaxWords" will be copied from the
                            //     rcv buffer to the users buffer, and the "TimeTag"
                            //     pointer is ignored.  Ignored otherwise.
   int         *ActualCount,// (o) The number of words actually returned
   long        *ARINCdata,  // (o) Address that is to receive the data words
   long        *TimeTag)    // (o) Address that is to receive the time tags
{
   return ARS_NO_HW_SUPRT;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T F I L T E R
 *===========================================================================*
 *
 * FUNCTION:    Read the label interrupt and filter buffer from the board
 *
 * RETURN VAL:  -- ARS_INVBOARD     board number invalid
 *              -- ARS_BRDNOTLOAD board not initialized
 *              -- ARS_INVARG       non-implemented channel, -717 channel or invalid mode
 *              -- ARS_NO_HW_SUPRT  board does not support this function
 *
 * DESCRIPTION: This routine copies the specified label interrupt and filter
 *              buffer from the caller's space to the dual port memory on the
 *              board.  Each element of the filter buffer consists of a bit
 *              field defined as follows:
 *
 *  FILTER_SEQUENTIAL  0x10   If CLEAR add label to Sequential rcv buf
 *  FILTER_SNAPSHOT    0x20   If CLEAR add label to Snapshot rcv buf
 *  FILTER_INTERRUPT   0x40   If SET add entry to int queue & set IRQ
 *  FILTER_SIGNAL      0x80   If SET signal channel to xmit label
 *  FILTER_CHANNEL     0x0F   Transmit channel number (mask) to signal
 *
 *  The filter buffer for a single channel is defined as follows:
 *
 *    FilterCtrl[MAX_ESSM][MAX_SDI][MAX_LABEL]
 *
 *  where the bits of the ARINC word are split up as follows:
 *        --eSSM---    -SDI-     -----label------------
 *  bits 30, 29, 28    9, 8      7, 6, 5, 4, 3, 2, 1, 0
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_getfilter(
   unsigned int cardnum,    // (i) The board number of interest
   unsigned int channel,    // (i) The channel from which to get the data (0-based)
   char        *Filter)     // (i) Pointer to the new filter buffer.
{
   return ARS_NO_HW_SUPRT;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T N E X T
 *===========================================================================*
 *
 * FUNCTION:    Get the next word in the receive channel.  If there isn't one,
 *              then keep trying for a while.
 *
 * RETURN VAL:  short         -- ARS_NODATA  no word available
 *                            -- ARS_GOTDATA one ARINC word (4 bytes) read
 *
 * DESCRIPTION: This utility tries to get data from an input channel.  If none
 *      is there, it continues trying for up to 1/4 of a second before giving
 *      up.  It merely calls AR_GETWORD repeatedly, returning when it either
 *      receives something or times out.
 *
 * NOTE: Change of return type to enforce consistent status code typing.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_getnext(
   short cardnum,           // (i) The board number of interest
   short channel,           // (i) The channel from which to get data (0-based)
   void *dest)              // (o) Address of the location that gets the data
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short         status;                   // Return status from functions
   unsigned long goal = 0;                 // Number of ticks to wait
   unsigned long initial = 0;              // Initial value of tick timer

/*    // DEBUG generate fake data... */
/*    goal = ((1234567890 << 8) | 0314); */
/*    *(unsigned long *)dest = goal; */
/*    return ARS_GOTDATA; */

   do {
      //  If we got something, then just return.
      if ((status = ar_getword(cardnum, channel, (long *)dest)) != ARS_NODATA)
         return status;

      // If board has been commanded to not "GO" the timeout will hang forever.
      if ( ar_board[cardnum].board_ar_go == 0 )
         return ARS_NODATA;

      //  Initialize the max time we will wait.
      if ( goal == 0 )
      {
         vbtAcquireFrame(cardnum);
         ar_base = ar_set_cpage(cardnum);  // Go to control page zero.
         // Get the current Timer Tick resolution, 0.25 us LSB.
         goal = ar_base->TickResolution/4; // Convert to 1.0 us LSB
         vbtReleaseFrame(cardnum);
         // Compute the number of Ticks needed to get to 250000 microseconds.
         goal = 250000L/goal + 2;  // Some for Granddad
         // Get the starting time.
         initial = ar_get_timercntl(cardnum);
      }
      // Multi task for 500 us
#ifdef __WIN32__
      Sleep(2);     // Multi task a bit
#else
      msleep(500);
#endif
      //  If more than 1/4 of a sec has passed, exit.
      } while ( goal >= (ar_get_timercntl(cardnum) - initial) );
   return ar_getword(cardnum, channel, (long *)dest);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T N E X T T
 *===========================================================================*
 *
 * FUNCTION:    Get the next word in the receive channel.  If there isn't one,
 *              then keep trying for a while.
 *
 * RETURN VAL:  short -- ARS_NODATA    no word available
 *                    -- ARS_GOTDATA   one ARINC word with timetag read
 *                    -- ARS_INVARG    invalid channel number
 *                    -- ARS_INVBOARD  invalid cardnum
 *
 * DESCRIPTION: This utility tries to get data with timetag from an input
 *      channel.  If none is there, it continues trying for up to 1/4 of a
 *      second before giving up.  It merely calls AR_GETWORDT repeatedly,
 *      returning when it either receives something or times out.  This routine
 *      should only be used when time tags have been enabled by a previous call
 *      to AR_TIMETAG_CONTROL.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_getnextt(
   short cardnum,           // (i) The board number of interest
   short channel,           // (i) The channel from which to get the data (0-based)
   void *destination,       // (o) Address that is to receive the data.
   void *timetag)           // (o) Address that is to receive the time tag
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short         status;                   // Return status from functions
   unsigned long goal = 0;                 // Number of ticks to wait
   unsigned long initial = 0;              // Initial value of tick timer

   do {
      // If we got something, then just return.
      if ( (status = ar_getwordt(cardnum, channel, (long *)destination,
                                                (long *)timetag)) != ARS_NODATA)
         return status;

      // If board has been commanded to not "GO" the timeout will hang forever.
      if ( ar_board[cardnum].board_ar_go == 0 )
         return ARS_NODATA;

      //  Initialize the max time we will wait.
      if ( goal == 0 )
      {
         vbtAcquireFrame(cardnum);
         ar_base = ar_set_cpage(cardnum);    // Go to control page zero.
         // Get the current Timer Tick resolution, 0.25 us LSB.
         goal = ar_base->TickResolution/4;   // Convert to 1.0 us LSB
         vbtReleaseFrame(cardnum);
         // Compute the number of Ticks needed to get to 250000 microseconds.
         goal = 250000L/goal + 2;  // Some for Granddad
         // Get the starting time.
         initial = ar_get_timercntl(cardnum);
      }
      // Multi task for 500 us
#ifdef __WIN32__
      Sleep(2);     // Multi task a bit
#else
      msleep(500);
#endif
      //  If more than 1/4 of a sec has passed, exit.
      } while ( goal >= (ar_get_timercntl(cardnum) - initial) );
   return ar_getwordt(cardnum, channel, (long *)destination, (long *)timetag);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T W O R D
 *===========================================================================*
 *
 * FUNCTION:    Get a word from either channel's receive buffer
 *
 * RETURN VAL:  short -- ARS_NODATA  no word available
 *                    -- ARS_GOTDATA one ARINC word (4 bytes) read
 *                    -- ARS_INVARG  board not initialized
 *
 * DESCRIPTION: This routine gets the next available 32-bit ARINC word from the
 *      requested channel's buffer and puts it in the desired destination.  If
 *      this routine succesfully returns a word (status is ARS_GOTDATA), then
 *      there may or may not be more words in the buffer.  In this case,
 *      AR_GETWORD removes the data from the buffer and writes it in the
 *      specified destination and subsequent calls are required to determine if
 *      more words are in the buffer.  When it returns ARS_NODTA, the circular
 *      ARINC receiver buffer is empty.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_getword(
   short cardnum,           // (i) The board number of interest
   short channel,           // (i) The channel from which to get the data (0-based)
   long *dest)              // (o) The address that is to receive the data.
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;
   unsigned short tail_ptr, index;
   unsigned short head_ptr1, head_ptr2;
   static unsigned short last[4];

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Fetch the current tail pointer.  Only the host writes to the tail pointer.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                // Go to control page zero.

   // Read the head pointer until it is stable, just in case the i960 is
   //  currently updating it.
   while (1) {
     head_ptr1 = ar_base->rcvr[channel].head_ptr;
     head_ptr2 = ar_base->rcvr[channel].head_ptr;
     if ( head_ptr1 == head_ptr2 ) break;
     msleep(1);
   }
   // Read the tail pointer
   index = tail_ptr = ar_base->rcvr[channel].tail_ptr;

   // DEBUG
   if (last[channel] != tail_ptr)
       KLOG_DEBUG("(%d) tail pointer skipped last: 0x%04hx tail_ptr: 0x%04hx",
           channel, last[channel], tail_ptr);

   // If the current tail pointer equals the head pointer, the buffer is empty.
   if ( tail_ptr == head_ptr1 )
   {
      vbtReleaseFrame(cardnum);
      return ARS_NODATA;
   }
   // Update the tail pointer indicating we read the data.
   tail_ptr++;                                   // Increment the tail pointer.
   tail_ptr &= ar_base->rcvr[channel].mask_ptr;  // Wrap tail pointer.
   ar_base->rcvr[channel].tail_ptr = tail_ptr;   // Save tail pointer.
   last[channel] = tail_ptr; // DEBUG

   // Fetch the ARINC word from the receiver buffer at the tail pointer.
   ar_buf = ar_set_rpage(cardnum, channel, index);  // Go to receiver page for channel.
   dest[0] = ar_buf->buf[CEI_PAGE_MASK & index];

   KLOG_DEBUG("(%hd) final   tail_ptr: 0x%04hx head_ptr1: 0x%04hx",
	channel, tail_ptr, head_ptr1);

   vbtReleaseFrame(cardnum);
   return ARS_GOTDATA;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T W O R D S
 *===========================================================================*
 *
 * FUNCTION:    Get the next block of data from a receiver's buffer.
 *
 * RETURN VAL:  short -- ARS_NODATA  no word available
 *                    -- ARS_GOTDATA one ARINC word (4 bytes) read
 *                    -- ARS_INVARG  board not initialized
 *
 * DESCRIPTION: This routine gets all of the available ARINC words from the
 *      requested channel's buffer and puts them in the desired destination.
 *      If this routine succesfully returns a word, then there may or may not
 *      be more words in the buffer.  In this case, AR_GETWORD removes the data
 *      from the buffer and writes it in the specified destination and subsequent
 *      calls are required to determine if more words are in the buffer.  When
 *      it returns ARS_NODATA, the circular ARINC receiver buffer is empty.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_getwords(
   short cardnum,           // (i) The board number of interest
   short channel,           // (i) The channel from which to get the data (0-based)
   int   size,              // (i) The allocated size of the ARINCdata array
   int   *ActualCount,      // (o) The number of words actually returned
   long  *ARINCdata)        // (o) Address that is to receive the data words
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;
   unsigned short tail_ptr;
   unsigned short head_ptr1, head_ptr2;
   unsigned short mask;
   static unsigned short last[4];

   *ActualCount = 0;

   // DEBUG generate fake data...
/*    unsigned long iii; */
/*    for (iii=0; iii<0400; iii++) */
/*      ARINCdata[(*ActualCount)++] = (3141 << 8) | iii; */

/* /\*    for (*ActualCount=0; (*ActualCount)<10; (*ActualCount)++) *\/ */
/* /\*      KLOG_DEBUG("%3d %04o 0x%x", *ActualCount, *\/ */
/* /\*          ARINCdata[*ActualCount]&0xff, (ARINCdata[*ActualCount]&0xffffff00)>>8); *\/ */
/*    return ARS_GOTDATA; */

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Fetch the current tail pointer.  Only the host writes to the tail pointer.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                        // Go to control page zero.
   mask = ar_base->rcvr[channel].mask_ptr;

   // Read the head pointer until it is stable, just in case the i960 is
   //  currently updating it.
   while (1) {
     head_ptr1 = ar_base->rcvr[channel].head_ptr;
     head_ptr2 = ar_base->rcvr[channel].head_ptr;
     if ( head_ptr1 == head_ptr2 ) break;
     msleep(1);
   }
   // Read the tail pointer
   tail_ptr = ar_base->rcvr[channel].tail_ptr;

   // DEBUG
   if (last[channel] != tail_ptr)
       KLOG_DEBUG("(%hd) tail pointer skipped last: 0x%04hx tail_ptr: 0x%04hx",
           channel, last[channel], tail_ptr);

/*    KLOG_DEBUG("(%hd) initial ActualCount: %3d tail_ptr: 0x%04hx head_ptr1: 0x%04hx", */
/*        channel, *ActualCount, tail_ptr, head_ptr1); */

   // If the current tail pointer equals the head pointer, the buffer is empty.
   if ( tail_ptr == head_ptr1 )
   {
      vbtReleaseFrame(cardnum);
      return ARS_NODATA;
   }

   while ( tail_ptr != head_ptr1 )
   {
     // Stop reading when ARINCdata array is full
     if (*ActualCount >= size) break;

     // Fetch the ARINC word from the receiver buffer at the tail pointer.
     ar_buf = ar_set_rpage(cardnum, channel, tail_ptr);  // Go to receiver page for channel.
     ARINCdata[(*ActualCount)++] = ar_buf->buf[CEI_PAGE_MASK & tail_ptr];

     // Update the tail pointer indicating we read the data.
     tail_ptr++;        // Increment the tail pointer.
     tail_ptr &= mask;  // Wrap tail pointer.
   }
/*    KLOG_DEBUG("(%d) final   ActualCount: %3d tail_ptr: 0x%04x head_ptr1: 0x%04x", */
/*        channel, *ActualCount, tail_ptr, head_ptr1); */

   // Update the tail pointer indicating we read the data.
   ar_base = ar_set_cpage(cardnum);            // Go to control page zero.
   ar_base->rcvr[channel].tail_ptr = tail_ptr; // Save tail pointer.
   last[channel] = tail_ptr; // DEBUG

   vbtReleaseFrame(cardnum);
   return ARS_GOTDATA;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T W O R D S T
 *===========================================================================*
 *
 * FUNCTION:    Get the next block of data from a receiver's buffer with time tags.
 *
 * RETURN VAL:  short -- ARS_NODATA  no word available
 *                    -- ARS_GOTDATA one ARINC word (4 bytes) read
 *                    -- ARS_INVARG  board not initialized
 *                    -- ARS_NOSYNC  cannot read good headptr from board
 *
 * DESCRIPTION: This routine gets all of the available ARINC words from the
 *      requested channel's buffer and puts them in the desired destination along
 *      with their timetags.  It is only used if time tags have been selected via
 *      a previous call to AR_TIMETAG_CONTROL.  If this routine succesfully
 *      returns a word, then there may or may not be more words in the buffer.
 *      In this case, AR_GETWORD removes the data from the buffer and writes it
 *      in the specified destination and subsequent calls are required to
 *      determine if more words are in the buffer.  When it returns ARS_NODATA,
 *      the circular ARINC receiver buffer is empty.
 *
 *===========================================================================*/


EXPORT32 short DLL_EXPORTED ar_getwordst(
   short     cardnum,       // (i) The board number of interest
   short     channel,       // (i) The channel from which to get the data (0-based)
   int       size,          // (i) The allocated size of the ARINCdata array
   int       *ActualCount,  // (o) The number of words actually returned
   struct tt_data *ARINCdata)    // (o) Address that is to receive the data and time
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf; // Current board pointer.
   unsigned short tail_ptr;
   unsigned short head_ptr1, head_ptr2;
   unsigned short mask;
#ifdef DEBUG_LAST_PTR
   static unsigned short last[4];
#endif
   int i;
   int count = 0;

   *ActualCount = 0;

   // DEBUG generate fake data...
/*    unsigned long iii; */
/*    for (iii=1; iii<011; iii++) { */
/*      ARINCdata[*ActualCount].data = (3141 << 8) | iii; */
/*      ARINCdata[*ActualCount].time = GET_MSEC_CLOCK; */
/*      (*ActualCount)++; */
/*    } */
/*    for (*ActualCount=0; (*ActualCount)<10; (*ActualCount)++) */
/*      KLOG_DEBUG("%3d %04o 0x%x", *ActualCount, */
/*          ARINCdata[*ActualCount].data&0xff, (ARINCdata[*ActualCount].data&0xffffff00)>>8); */
/*    return ARS_GOTDATA; */

   // Fetch the current tail pointer.  Only the host writes to the tail pointer.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                        // Go to control page zero.
   mask = ar_base->rcvr[channel].mask_ptr;

   // Read the head pointer until it is stable, just in case the i960 is
   //  currently updating it.

   // Note: in the linux version of nidas, this function is being called
   // from a tasklet, i.e. from software interrupt context.  Hence
   // one can't call msleep or usleep.  One could call udelay but that
   // is a busy wait, and so one might as well just loop here without
   // a udelay until the head pointer is behaving.
#define NTRY_HEAD_PTR 5
   for(i=0; i< NTRY_HEAD_PTR; i++) {
      head_ptr1 = ar_base->rcvr[channel].head_ptr;
	// also check that head_ptr is in range of mask
      head_ptr2 = ar_base->rcvr[channel].head_ptr & mask;
      if ( head_ptr1 == head_ptr2 ) break;
   }
   if (i== NTRY_HEAD_PTR) {
      KLOG_WARNING("card %hd, channel %hd: CEI420's head pointer is not stable! (0x%04hx != 0x%04hx)\n",
	cardnum,channel,head_ptr1, head_ptr2); 
      vbtReleaseFrame(cardnum);
      return ARS_NOSYNC;
   }

   // Read the tail pointer
   tail_ptr = ar_base->rcvr[channel].tail_ptr;

#ifdef DEBUG_LAST_PTR
   if (last[channel] != tail_ptr)
       KLOG_DEBUG("card %hd, channel %hd: tail pointer skipped last: 0x%04hx tail_ptr: 0x%04hx\n",
           cardnum,channel, last[channel], tail_ptr);
#endif

   KLOG_DEBUG("card %hd, channel %hd: initial count: %3d tail_ptr: 0x%04hx head_ptr1: 0x%04hx\n",
              cardnum, channel, count, tail_ptr, head_ptr1);

   // If the current tail pointer equals the head pointer, the buffer is empty.
   if ( tail_ptr == head_ptr1 )
   {
      vbtReleaseFrame(cardnum);
      return ARS_NODATA;
   }
   while ( tail_ptr != head_ptr1 )
   {
     // Stop reading when ARINCdata array is full
     if (count >= size) break;

     // Fetch the ARINC word from the receiver buffer at the tail pointer,
     //  and fetch the time tag.  The i960 writes both to DP before updating
     //  the head pointer, and always starts on an quad word boundry.
     ar_buf = ar_set_rpage(cardnum, channel, tail_ptr);  // Go to receiver page for channel.
     ARINCdata[count].data = ar_buf->buf[CEI_PAGE_MASK & tail_ptr++];
     ARINCdata[count].time = ar_buf->buf[CEI_PAGE_MASK & tail_ptr++];
     count++;
     tail_ptr &= mask;  // Wrap tail pointer.
   }
   KLOG_DEBUG("card %hd, channel %hd: final count: %3d tail_ptr: 0x%04hx head_ptr1: 0x%04hx",
              cardnum, channel, count, tail_ptr, head_ptr1);

   // Update the tail pointer indicating we read the data.
   ar_base = ar_set_cpage(cardnum);            // Go to control page zero.
   ar_base->rcvr[channel].tail_ptr = tail_ptr; // Save tail pointer.
#ifdef DEBUG_LAST_PTR
   last[channel] = tail_ptr; // DEBUG
#endif
   *ActualCount = count;

   vbtReleaseFrame(cardnum);
   return ARS_GOTDATA;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T W O R D T
 *===========================================================================*
 *
 * FUNCTION:    Get the next word with time tag.
 *
 * RETURN VAL:  short -- ARS_NODATA    no word available
 *                    -- ARS_GOTDATA   one ARINC word with timetag read
 *                    -- ARS_INVARG    invalid channel number
 *                    -- ARS_INVBOARD  invalid board number
 *
 * DESCRIPTION: This routine gets the next available 32-bit ARINC word from the
 *      requested channel's buffer and puts it in the desired destination along
 *      with its timetag.  It is only used if time tags have been selected via
 *      a previous call to AR_TIMETAG_CONTROL.  If it successfully returns
 *      data, there may or may not be more data in the buffer.  It only means
 *      there was at least one word in the buffer.  This routine removes it
 *      from the buffer and returns it to you.  Subsequent calls would be
 *      required to determine if more words aare in the buffer.  If it returns
 *      ARS_NODATA, the buffer is empty.  This is a circulasr FIFO buffer that
 *      is constantly being maintained by the interface board.
 *
 * NOTE: Change of return type to enforce consistent status code typing.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_getwordt(
   short cardnum,           // (i) The board number of interest
   short channel,           // (i) The channel from which to get the data (0-based)
   void *dest,              // (o) Address that is to receive the data
   void *timetag)           // (o) Address that is to receive the time tag
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;
   unsigned short tail_ptr;
   unsigned short head_ptr1, head_ptr2;

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Fetch the current tail pointer.  Only the host writes to the tail pointer.
   vbtAcquireFrame(cardnum);
   ar_base  = ar_set_cpage(cardnum);             // Go to control page zero.

   // Read the head pointer until it is stable, just in case the i960 is
   //  currently updating it.  This is only for the 220.
   while (1) {
     head_ptr1 = ar_base->rcvr[channel].head_ptr;
     head_ptr2 = ar_base->rcvr[channel].head_ptr;
     if ( head_ptr1 == head_ptr2 ) break;
     msleep(1);
   }
   // Read the tail pointer
   tail_ptr = ar_base->rcvr[channel].tail_ptr;

   // If the current tail pointer equals the head pointer, the buffer is empty.
   if ( tail_ptr == head_ptr1 )
   {
      vbtReleaseFrame(cardnum);
      return ARS_NODATA;
   }

   // Fetch the ARINC word from the receiver buffer at the tail pointer,
   //  and fetch the time tag.  The i960 writes both to DP before updating
   //  the head pointer, and always starts on an quad word boundry.
   ar_buf = ar_set_rpage(cardnum, channel, tail_ptr);   // Go to receiver page for channel.
   *(long *)dest    = ar_buf->buf[CEI_PAGE_MASK & (tail_ptr+0)];
   *(long *)timetag = ar_buf->buf[CEI_PAGE_MASK & (tail_ptr+1)];

   // Update the tail pointer indicating we read the data.
   ar_base = ar_set_cpage(cardnum);              // Go to control page zero.
   tail_ptr += (short)2;                         // Increment the tail pointer.
   tail_ptr &= ar_base->rcvr[channel].mask_ptr;  // Wrap tail pointer.
   ar_base->rcvr[channel].tail_ptr = tail_ptr;   // Save tail pointer.

   vbtReleaseFrame(cardnum);
   return ARS_GOTDATA;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G O
 *===========================================================================*
 *
 * FUNCTION:    Start the slave processor
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest.
 *
 * RETURN VAL:  short       -- ARS_NORMAL if no error, else error code
 *
 * DESCRIPTION: This sends a command to the ARINC interface causing it to
 *      begin processing ARINC data.  Once the interface is started it goes
 *      into an endless loop processing ARINC data until the routine AR_RESET
 *      is executed.  No ARINC data will be received or sent until the board
 *      is in the "GO" state achieved by this routine.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_go(short cardnum)
{
   // Board has been commanded to "GO"
   ar_board[cardnum].board_ar_go = 1;

   // Command the board to "GO", any channel.
   return ar_channel_cmd(cardnum, CHAN_CMD_GO, 1, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ I N I T _ D U A L _ P O R T
 *===========================================================================*
 *
 * FUNCTION:    This routine initializes all of dual-port memory.  It or the
 *              ar_init_slave() function must be called after ar loadslv() is
 *              called and before any of the other API routines cam be called.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest.
 *
 * RETURN VAL:  short -- ARS_NORMAL       The interface was properly initialized
 *                    -- ARS_INVBOARD     A board number out of the maximum
 *                                        range was specified
 *                    -- ARS_BRDNOTLOAD The requested board was not first
 *                                        loaded with a call to AR LOADSLV
 *
 * DESCRIPTION: This routine initializes all ARINC related queue structures,
 *      buffers and word counts.  It resets the interface (with AR_RESET).
 *      All data structures are then initialized.  It has the side effect
 *      of flushing out the data buffers.  If you are using scheduled
 *      transmission mode, this routine clears your message setup.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_init_dual_port(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf;
   unsigned int         nchan;

   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // First stop the i960 from polling the xmit head/tail pointers and
   //  updating the tick counter.
   ar_reset(cardnum);

   //------------------------------------------------------------------------*
   //  Clear each of the MAX_CHAN Scheduled Retransmission counters.
   //  Initialize all of the channel wrap masks.
   //------------------------------------------------------------------------*
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page one.
   for ( nchan = 0; nchan < MAX_CHAN; nchan++ )
   {
      ar_base->xmtr[nchan].num_scheduled = 0;
      ar_base->rcvr[nchan].head_ptr = 0;
      ar_base->rcvr[nchan].tail_ptr = 0;
      ar_base->xmtr[nchan].head_ptr = 0;
      ar_base->xmtr[nchan].tail_ptr = 0;
      ar_base->rcvr_rx_count[nchan] = 0;
      ar_base->xmtr_tx_count[nchan] = 0;
      ar_base->rcvr[nchan].mask_ptr = ARINC_RX_BUFFER_MASK;
      ar_base->xmtr[nchan].mask_ptr = ARINC_TX_BUFFER_MASK;
   }

   // Clear the timer tick counter twice just in case the i960 was updating
   //  it just as we cleared it.  DO NOT REMOVE DOUBLE WRITES!
   ar_base->TickTimer = 0;   /* User timer tick counter              */
   ar_base->TickTimer = 0;   /* User timer tick counter              */
   vbtReleaseFrame(cardnum);
   // Now tell the i960 to sync with the new timer tick value.
   ar_channel_cmd(cardnum, 162, 1, 0x0001);

   //------------------------------------------------------------------------*
   //  For each channel clear both the receive and the transmit buffers
   //   in dual-port memory to zero.  The receive and transmit buffers are
   //   each 1024 16-bit words long (2048 decimal or 0x800 hex bytes).
   // Note that the CEI-220/420/420A maps Dual Port into 2048 byte pages...
   //------------------------------------------------------------------------*
   vbtAcquireFrame(cardnum);
   for ( nchan = 0; nchan < MAX_XMTRS; nchan++ )
   {
      // Go to transmitter page for channel "nchan".
      ar_buf = ar_set_xpage(cardnum, nchan, 0);
      memset((void *)ar_buf, 0x00, 2048);
   }
   for ( nchan = 0; nchan < MAX_RCVRS; nchan++ )
   {
      // Go to receiver page for channel "nchan".
      ar_buf = ar_set_rpage(cardnum, nchan, 0);
      memset((void *)ar_buf, 0x00, 2048);
   }
   vbtReleaseFrame(cardnum);
   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ I N I T _ S L A V E
 *===========================================================================*
 *
 * FUNCTION:    This routine initializes the data structures that the other
 *              routines use.  It must be called after ar loadslv() is called
 *              and before any of the other API routines cam be called.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest.
 *
 * RETURN VAL:  short       -- ARS_NORMAL        The interface was properly
 *                                               initialized
 *                          -- ARS_INVBOARD      A board number out of the
 *                                               maximum range was specified
 *                          -- ARS_BRDNOTLOAD  The requested board was not
 *                                               first loaded with a call to
 *                                               AR_LOADSLV
 *
 * DESCRIPTION: This routine initializes all ARINC related queue structures,
 *      buffers and word counts.  It resets the interface.  If the interface
 *      has been started (with a call to AR_GO) this routine reset it (with
 *      AR_RESET).  All data structures are then initialized.  It has the side
 *      effect of fluishing out the data buffers.  If you are using shceduled
 *      transmission mode, this routine DOES NOT modify your message setup.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_init_slave(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int    channel;                         /* loop counter */

   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // First stop the i960 from polling the xmit head/tail pointers and
   //  updating the tick counter.
   ar_reset(cardnum);

   //------------------------------------------------------------------------*
   //  Initialize slave receive and transmit buffer head and tail pointers.
   //------------------------------------------------------------------------*
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page.
   for ( channel = 0; channel < MAX_CHAN; channel++ )
   {
      ar_base->rcvr[channel].head_ptr = 0;
      ar_base->rcvr[channel].tail_ptr = 0;
      ar_base->xmtr[channel].head_ptr = 0;
      ar_base->xmtr[channel].tail_ptr = 0;
   }
   vbtReleaseFrame(cardnum);
   return (ARS_NORMAL);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ I N T _ C O N T R O L
 *===========================================================================*
 *
 * FUNCTION:    Function to enable/disable interrupts from slave receivers.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest
 *              short channel -- (input) the receive channel of interest
 *                                       (0 is the first channel)
 *              short flag    -- (input) if equal to ARU_ENABLE_INT, enables
 *                               interrupts for the board/channel combination.
 *                               Otherwise the interrupts are disabled   
 * 
 * RETURN VAL:  short -- ARS_NORMAL    Success
 *                    -- ARS_INVBOARD  An uninitialized or invalid board was 
 *                                     selected 
 *                    -- ARS_INVARG    An invalid channel was selected
 *
 * DESCRIPTION: This routine enables/disables interrupts from the slave 
 *              processor.  Interrupts can enabled for any or all of the 
 *              receive channels.  If enabled, the interface interrupts the
 *              host upon receiving any ARINC data word.  The host software must
 *              then reset the interrupt from within its interrupt handler 
 *              using AR_RESET_INT.  The host them must poll the enabled 
 *              receive channels with AR_GETWORD to determine which channels
 *              contain data.  This routine may be invoked while the interface 
 *              is running.
 * 
 *===========================================================================*/
                                 
EXPORT32 short DLL_EXPORTED ar_int_control (short cardnum, short channel, short flag)
{
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return error.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Command the board to Enable/Disable Interrupts, channel 0.
   if ( flag == ARU_ENABLE_INT )
      return ar_channel_cmd(cardnum, CHAN_CMD_INT_ENABLE, 1, 0x0001);
   else
      return ar_channel_cmd(cardnum, CHAN_CMD_INT_ENABLE, 0, 0x0001);
}
                  
/*===========================================================================*
 * ENTRY POINT:                A R _ I N T _ S E T
 *===========================================================================*
 *
 * FUNCTION:    Function to set the interrupt number used by the CEI-220/420.
 * 
 * PARAMETERS:  short cardnum -- (input) the board number of interest
 *              int interrupt -- (input) interrupt to be used
 *                                       (0 is the first channel)
 *              short flag    -- (input) if equal to ARU_ENABLE_INT, enables
 *                               interrupts for the board/channel combination.
 *                               Otherwise the interrupts are disabled
 * 
 * RETURN VAL:  short -- ARS_NORMAL    Success
 *                    -- ARS_INVBOARD  An uninitialized or invalid board was 
 *                                     selected 
 *                    -- ARS_INVARG    An invalid channel was selected
 *
 * DESCRIPTION: This routine enables/disables interrupts from the slave 
 *              processor.  Interrupts can enabled for any or all of the 
 *              receive channels.  If enabled, the interface interrupts the
 *              host upon receiving any ARINC data word.  The host software must
 *              then reset the interrupt from within its interrupt handler 
 *              using AR_RESET_INT.  The host them must poll the enabled 
 *              receive channels with AR_GETWORD to determine which channels 
 *              contain data.  This routine may be invoked while the interface 
 *              is running.
 * 
 *===========================================================================*/
                                 
EXPORT32 short DLL_EXPORTED ar_int_set(short cardnum, int interrupt_num)
{
   int    int_val;           // Value to set to the board.

   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If interrupt invalid return error.
   if ( interrupt_num < 2 || interrupt_num > 15 )
      return ARS_NO_HW_SUPRT;

   // Create the parameter needed by the board to set the interrupt.
   // Value is set in the high byte...clr in the low byte.
   int_val = 0x3020 | (interrupt_num << 8) | interrupt_num;
   // Command the board to Set the specified Interrupt.
   return ar_channel_cmd(cardnum, CHAN_CND_INT_NUM, int_val, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ L A B E L _ F I L T E R
 *===========================================================================*
 *
 * FUNCTION:    Function to enable/disable label filtering on slave.
 * 
 * PARAMETERS:  short cardnum        -- (input) Board number of interest
 *              short channel        -- (input) Channel from which to get data
 *                                      (0 = first receive channel, 1 = second
 *                                      receive channel, etc.)
 *              unsigned short label -- (input) Label of interest.  Valid range
 *                                      is 0-255.  Also valid is ARU_ALL_LABELS
 *                                      which takes the action for all labels.
 *              short action         -- (input) Enable or disable filtering for
 *                                      this board/channel/label.  Valid values
 *                                      are: ARU_FILTER_ON/ARU_FILTER_OFF
 * 
 * RETURN VAL:  short -- ARS_NORMAL    success
 *                    -- ARS_INVBOARD  an uninitialized or invalid board was 
 *                                     selected
 *                    -- ARS_INVARG    invalid channel, label or action
 *                                     argument
 *
 * DESCRIPTION: The ARINC interface has the ability to filter data by label.  
 *              This routine selects those labels to be filtered out.  If
 *              filtering is enabled for a particular label, no received
 *              data on the specified channel with that label will be stored
 *              in the ARINC buffer.  Label filtering is disabled for all
 *              labels by default.  Label filtering changes will be effective
 *              immediately on completion of this routine.
 *
 *===========================================================================*/
                                          
EXPORT32 short DLL_EXPORTED ar_label_filter(short cardnum, short channel,
                                     unsigned short label, short action)
{
   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return 0;

   if ( label != ARU_ALL_LABELS )
   {
      if ( action == ARU_FILTER_ON )
      {  // Command the board to modify the filter as specified for one channel.
         return ar_channel_cmd(cardnum, CHAN_CMD_FLT_ON, label, 1<<channel);
      }
      else if ( action == ARU_FILTER_OFF )
      {  // Command the board to modify the filter as specified for one channel.
         return ar_channel_cmd(cardnum, CHAN_CMD_FLT_OFF, label, 1<<channel);
      }
   }
   else
   {
      if ( action == ARU_FILTER_ON )
      {  // Command the board to modify the filter as specified for one channel.
         return ar_channel_cmd(cardnum, CHAN_CMD_FLT_ALL_ON, label, 1<<channel);
      }
      else if ( action == ARU_FILTER_OFF )
      {  // Command the board to modify the filter as specified for one channel.
         return ar_channel_cmd(cardnum, CHAN_CMD_FLT_ALL_OFF, label, 1<<channel);
      }
   }
   return ARS_INVARG;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ P U T B L O C K
 *===========================================================================*
 *
 * FUNCTION:    Put multiple words into a specified channel's sequential
 *              transmit buffer.
 *
 * RETURN VAL:  short  -- ARS_NORMAL      Success
 *                     -- ARS_XMITOVRFLO  Failure - transmit buffer overflow.
 *
 *                     There was not enough room in the transmit buffer for all
 *                     of the ARINC words specified.  ActualCount contains the
 *                     number of words actually transfered.
 *
 * DESCRIPTION: This routine puts multiple ARINC word in the transmit queue for
 *              a particular channel.  When this routine returns, the data has
 *              not becessarily been sent, it has only been put in the buffer.
 *              If other data is in the transmit buffer ahead of it, it will
 *              be transmitted in turn.
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_putblock(
   unsigned int cardnum,     // (i) The board number of interest
   unsigned int channel,     // (i) The channel into which to put the data (0-based)
   int          AvailWords,  // (i) The number of words to put into the xmit buffer
   int          Offset717,   // (i) Beginning offset in frame if this is a 573/717
                             //     receiver.  "AvailWords" will be copied from the
                             //     callers buffer to the transmit buffer.
                             //     Ignored if not a -717 transmitter.
   long        *ARINCdata,   // (i) Address that is to supply the data words
   int         *ActualCount) // (o) The number of words actually moved
{
      return ARS_NO_HW_SUPRT; // No support
}

/*===========================================================================*
 * ENTRY POINT:         A R _ P U T F I L T E R
 *===========================================================================*
 *
 * FUNCTION:    Set the label interrupt and filter buffer used by the
 *              CEI-520/620 firmware.
 *
 * RETURN VAL:  -- ARS_NO_HW_SUPRT  This API/board is not supported
 *
 * DESCRIPTION: This routine copies the specified label interrupt and filter
 *              buffer from the caller's space to the dual port memory on the
 *              board.  Each element of the filter buffer consists of a bit
 *              field defined as follows:
 *
 *  FILTER_SEQUENTIAL  0x10   If CLEAR add label to Sequential rcv buf
 *  FILTER_SNAPSHOT    0x20   If CLEAR add label to Snapshot rcv buf
 *  FILTER_INTERRUPT   0x40   If SET add entry to int queue & set IRQ
 *  FILTER_SIGNAL      0x80   If SET signal channel to xmit label
 *  FILTER_CHANNEL     0x0F   Transmit channel number (mask) to signal
 *
 *  The filter buffer for a single channel is defined as follows:
 *
 *    FilterCtrl[MAX_ESSM][MAX_SDI][MAX_LABEL]
 *
 *  where the bits of the ARINC word are split up as follows:
 *        --eSSM---    -SDI-     -----label------------
 *  bits 30, 29, 28    9, 8      7, 6, 5, 4, 3, 2, 1, 0
 *
 *===========================================================================*/

EXPORT32 int DLL_EXPORTED ar_putfilter(
   unsigned int cardnum,    // (i) The board number of interest
   unsigned int channel,    // (i) The channel from which to get the data (0-based)
   char        *Filter)     // (i) Pointer to the new filter buffer.
{
      return ARS_NO_HW_SUPRT; // No support
}

/*===========================================================================*
 * ENTRY POINT:      A R _ P U T W O R D
 *===========================================================================*
 *
 * FUNCTION:    Put a word into the channel transmit queue.
 *
 * PARAMETERS:  short cardnum     -- (input) The board number of interest
 *              short channel     -- (input) The channel to transmit on
 *              long ARINC_data   -- (input) The 32 bit ARINC word to transmit.
 *
 * RETURN VAL:  short  -- ARS_NORMAL      Success
 *                     -- ARS_XMITOVRFLO  Failure - transmit buffer overflow.
 *      The interface is not transmitting data as fast as data is being put
 *      into the buffer,  The interface may be in a reset state or the data
 *      rate is too high.  In either case, the data was not put into the
 *      buffer.  If the interface is running, the user can retry the call
 *      until success is achieved.
 *
 * DESCRIPTION: This routine puts an ARINC word in the transmit queue for a
 *              particular channel.  When this routine returns, the data has
 *              not becessarily been sent, it has only been put in the buffer.
 *              If other data is in the transmit buffer ahead of it, it will
 *              be transmitted in turn.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_putword(short cardnum, short channel, long ARINC_data)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   struct BUFFER_DPRAM volatile *ar_buf; // Current board pointer.
   unsigned short tail_ptr, head_ptr, next_head_ptr;

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel is out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Fetch the current head and tail pointers.
   vbtAcquireFrame(cardnum);
   ar_base  = ar_set_cpage(cardnum);           // Go to control page zero.
   tail_ptr = ar_base->xmtr[channel].tail_ptr;
   head_ptr = ar_base->xmtr[channel].head_ptr;

   // If the current head pointer +1 equals the tail pointer, the buffer
   //  is full and we cannot write another ARINC word into it.
   next_head_ptr = (short)(head_ptr+1);              // Increment head ptr.
   next_head_ptr &= ar_base->xmtr[channel].mask_ptr; // Wrap new head ptr.

   if ( next_head_ptr == tail_ptr )
   {
      // Must read twice just in case the i960 is writing to the location,
      //  and the compiler must not optimize the board reads...
      // DO NOT REMOVE DOUBLE READS!
      if ( next_head_ptr == ar_base->xmtr[channel].tail_ptr )
      {
         vbtReleaseFrame(cardnum);
         return ARS_XMITOVRFLO;
      }
   }

   ar_buf = ar_set_xpage(cardnum, channel, head_ptr);   // Xmit page for channel.

   // Store the ARINC word in the transmitter buffer at the head pointer.
   ar_buf->buf[head_ptr & CEI_PAGE_MASK] = ARINC_data;

   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.

   // Update the head pointer indicating we wrote the data.
   ar_base->xmtr[channel].head_ptr = next_head_ptr;    // Save head ptr.
   vbtReleaseFrame(cardnum);
   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ R E S E T
 *===========================================================================*
 *
 * FUNCTION:    Command the i960 to stop processing ARINC data.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest.
 *
 * RETURN VAL:  short
 *
 * DESCRIPTION: This commands the i960 to stop processing ARINC data.  The
 *              processor is not halted or reset, it just stops polling the
 *              ARINC receivers and transmit buffers.  Note that on the
 *              CEI-x20 each channel (one receiver/transmitter pair)
 *              can be stopped or started individually, but for compatibility
 *              with both the CEI-100/200, we do all 16 at the same time.
 *
 *              Do not reset the interface if there is still data in the
 *              transmit buffer(s) to be sent.  See AR_XMIT_SYNC() to wait for
 *              all transmit data to be sent.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_reset (short cardnum)
{
   // Board has been commanded to not "GO"
   ar_board[cardnum].board_ar_go = 0;

   // Command the board to "un-GO", any channel.  Stop the board from polling
   //  the transmitters and receivers, and from updating the tick counter.
   return ar_channel_cmd(cardnum, CHAN_CMD_GO, 0, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _  R E S E T _ I N T
 *===========================================================================*
 *
 * FUNCTION:    Reset interrupt from slave.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest.
 *
 * RETURN VAL:  short
 *
 * DESCRIPTION: Resets an interrupt from the ARINC interface.  This routine
 *              should be called from your interrupt handler.  It is only
 *              applicable to interrupt-driven applications that have 1) set
 *              an interrupt jumper on the interface board and 2) enabled
 *              interrupts with a call to AR_INT_CONTROL.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_reset_int (short cardnum)
{
   // Command the board to clear the interrupt.  Only channel 0 need be told.
   return ar_channel_cmd(cardnum, CHAN_CMD_CLR_INT, 0, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ R E S E T _ T I M E R C N T
 *===========================================================================*
 *
 * FUNCTION:    This routine reset the number of timer ticks that have
 *              occurred on the slave.
 *
 * PARAMETERS:  short cardnum -- (input) the board number of interest
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: The timer tick dword is set to zero.
 *
 *===========================================================================*/

EXPORT32 void DLL_EXPORTED ar_reset_timercnt(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   // If board number out of range return nothing.
   if ( cardnum >= MAX_BOARDS )
      return;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);            // Go to control page zero.

   // Clear the timer tick counter twice just in case the i960 was updating
   //  it just as we cleared it.
   // DO NOT REMOVE DOUBLE WRITES!
   ar_base->TickTimer = 0;
   ar_base->TickTimer = 0;

   // Now tell the i960 to sync with the new timer tick value.
   ar_channel_cmd(cardnum, 162, 1, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T I N T E R R U P T S
 *===========================================================================*
 *
 * FUNCTION:    Set the interrupt on "N" labels received or transmitted controls,
 *              or setup the interrupt on discrete value change.
 *
 * RETURN VAL:  -- ARS_INVBOARD     board number invalid
 *              -- ARS_BRDNOTLOAD board not initialized
 *              -- ARS_NO_HW_SUPRT  board does not support this function
 *
 * DESCRIPTION: This routine copies the specified interrupt control values to
 *              the dual port memory for use by the i960 ARINC processor.
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_setinterrupts(
   unsigned int  cardnum,      // (i) The board number of interest
   unsigned int  channel,      // (i) The channel to modify (0-based)
   int           TransRcv,     // (i) Setup ARU_TRANSMITTER or ARU_RECEIVER or ARU_DISCRETES
   unsigned long Count,        // (i) For ARU_TRANSMITTER or ARU_RECEIVER -
                               //     Number of labels between interrupts.
                               //     If zero, no interrupts on "N" labels
                               //     received/transmitted or on receive/
                               //     transmit buffer over/underflow.
                               //     For ARU_DISCRETES, tick count for debouncing
                               //     the discrete inputs.
   unsigned long Mask)         // (i) For ARU_TRANSMITTER or ARU_RECEIVER -
                               //     Unused.
                               //     For ARU_DISCRETES, mask for detecting and
                               //     interrupting on discrete changes.
{
   return ARS_NO_HW_SUPRT;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ R A W _ M O D E
 *===========================================================================*
 *
 * FUNCTION:    Control raw mode for transmitters and receivers.
 *
 * PARAMETERS:  short cardnum   -- (input) The board number of interest
 *              short direction -- (input) The type of channel specified in
 *                                 the channel argument (transmit or receive).
 *                                 Valid values are:
 *                                     ARU_XMIT
 *                                     ARU_RECV
 *              short channel   -- (input) The channel number.  Valid
 *                                 arguments depend upon the number of
 *                                 channels configured on the board purchased.
 *                                 The first channel is number 0.
 *              short control   -- (input) This flag enables or disables raw
 *                                 mode.  Valid values are:
 *                                     AR_ON  enable "raw" mode on this channel
 *                                     AR_OFF disable "raw" mode on this
 *                                            channel (default mode).
 *
 * RETURN VAL:  short -- ARS_INVBOARD  Board is either not initialized or not
 *                                     supported for requested mode.
 *                       ARS_INVARG    Invalid flag argument.
 *
 * DESCRIPTION: Each transmit and receive channel can be configured to run in
 *              "raw" mode.  In this case, parity is not used and each 32 bit
 *              ARINC word will be transmitted or received with the parity
 *              (32nd) bit unchanged.  This is different from standard ARINC
 *              429 data transfers which call for the parity to always be
 *              calculated.  Raw mode is typically used for some older ARINC
 *              specifacations such as ARINC 575.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_set_raw_mode(short cardnum, short direction,
                                     short channel, short control)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   long   arinc_rcv, arinc_xmt;

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel number out of ranbe return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // Read the current ARINC fpga configuration value.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);                    // Go to control page zero.

   // Return the values from the Dual Port ARINC status shadow.
   arinc_rcv = ar_base->arinc_config_rcv[channel];
   arinc_xmt = ar_base->arinc_config_xmt[channel];
   if ( control == AR_ON )
   {
      if ( direction == ARU_XMIT )
      {  // Command the transmitter to RAW mode, specified channel.
         arinc_xmt &= ~R_T_PARITY_EN;
      }
      else
      {  // Command the receiver to RAW mode, specified channel.
         arinc_rcv &= ~R_T_PARITY_EN;
      }
   }
   else
   {
      if ( direction == ARU_XMIT )
      {  // Command the transmitter to NOT RAW mode, specified channel.
         arinc_xmt |= R_T_PARITY_EN;
      }
      else
      {  // Command the receiver to NOT RAW mode, specified channel.
         arinc_rcv |= R_T_PARITY_EN;
      }
   }
   // Write new value to DP & command i960 to load it to ARINC config reg.
   vbtReleaseFrame(cardnum);
   ar_write_ARINC (cardnum, arinc_rcv, arinc_xmt, channel);
   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:      A R _ S E T _ S T O R A G E _ M O D E
 *===========================================================================*
 *
 * FUNCTION:    Function to control buffering type on slave.  Buffered mode
 *              puts data in a circular buffer as it comes in.  Dedicated mode
 *              puts data from each label in a dedicated spot.  Merged mode
 *              puts all received data in the same buffer (receive 1).
 *
 *              Merged mode also turns on time tags.  For merged mode we are
 *              going to adjust the recv 1 buffer to be 8X its size so that
 *              it takes up the space for receivers 1-8.
 *
 *      NOTE:   This assumes each of these buffers is the same size.
 *
 * PARAMETERS:  short cardnum-- (input) The board number of interest
 *              short flag   -- (input) Flag indicating type of storage mode to
 *                                     set:
 *                                     ARU_BUFFERED
 *                                     ARU_DEDICATED
 *                                     ARU_MERGED
 *
 * RETURN VAL:  short -- ARS_INVBOARD  Board is either not initialized.
 *                    -- ARS_INVARG    Invalid flag argument
 *
 * DESCRIPTION: The i960 is placed into the specified receive mode using Channel
 *              Commands.  All channels are placed into the specified mode for
 *              compatibility with the CEI-100/200, even though the CEI-220/420
 *              supports different modes for each channel.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_set_storage_mode(short cardnum, short flag)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int     channel;
   short   status;

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // Verify the mode we are trying to set...
   if ( flag == ARU_BUFFERED )
   {
      // Command the board to specified mode, all channels.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, flag, 0xFFFF);
      if ( status != ARS_NORMAL )
         return status;

      // Return the first buffer to nominal size
      vbtAcquireFrame(cardnum);
      ar_base = ar_set_cpage(cardnum);
      ar_base->rcvr[0].mask_ptr = ARINC_RX_BUFFER_MASK;
      vbtReleaseFrame(cardnum);
   }
   else if ( flag == ARU_DEDICATED )
   {
      // Command the board to specified mode, all channels.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, flag, 0xFFFF);
      if ( status != ARS_NORMAL )
         return status;

      // Return the first buffer to nominal size
      vbtAcquireFrame(cardnum);
      ar_base = ar_set_cpage(cardnum);
      ar_base->rcvr[0].mask_ptr = ARINC_RX_BUFFER_MASK;
      vbtReleaseFrame(cardnum);
   }
   else if ( flag == ARU_MERGED )
   {
      // Command the board to specified mode, all channels.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, flag, 0xFFFF);
      if ( status != ARS_NORMAL )
         return status;

      // Now merge the first 8 buffers together into one single buffer.  This
      //  is simply done by making the first channel's mask 8 times bigger...
      // This should not be done while the i960 is receiving labels, since it
      //  might read garbage while the host updates the mask...
      vbtAcquireFrame(cardnum);              // Added 7/15/00.ajh
      ar_base = ar_set_cpage(cardnum);
      ar_base->rcvr[0].mask_ptr = (8*(ARINC_RX_BUFFER_MASK+1)) - 1;
      vbtReleaseFrame(cardnum);              // Added 5/30/00.ajh
   }
   else if (is_config_item(ARU_ITEM_CHxx_BUFFERED,flag,&channel))
   {
      // Command the board to specified mode, specified channel.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, ARU_BUFFERED, 1 << channel);
      if ( status != ARS_NORMAL )
         return status;
      // Leave the buffers alone.
   }
   else if (is_config_item(ARU_ITEM_CHxx_DEDICATED,flag,&channel))
   {
      // Command the board to specified mode, specified channel.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, ARU_DEDICATED, 1 << channel);
      if ( status != ARS_NORMAL )
         return status;
      // Leave the buffers alone.
   }
   else if (is_config_item(ARU_ITEM_CHxx_MERGED,flag,&channel))
   {
      // Command the board to specified mode, specified channel.
      status = ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, ARU_MERGED, 1 << channel);
      if ( status != ARS_NORMAL )
         return status;
      // Leave the buffers alone.
   }
   else
      return ARS_INVARG;

   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ T I M E R C N T
 *===========================================================================*
 *
 * FUNCTION:    This routine sets the number of timer ticks that have
 *              occurred on the slave.
 *
 * PARAMETERS:  short         cardnum   -- (input) the board number of interest
 *              unsigned long TickTimer -- (input) the number of ticks
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: The timer tick dword is set to TickTimer.
 *
 *===========================================================================*/

EXPORT32 void DLL_EXPORTED ar_set_timercnt(short cardnum, unsigned long TickTimer)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int goal;

   // If board number out of range return nothing.
   if ( cardnum >= MAX_BOARDS )
      return;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);            // Go to control page zero.

   // Set the timer tick counter twice just in case the i960 was updating
   //  it just as we set it.
   // DO NOT REMOVE DOUBLE WRITES!
   ar_base->TickTimer = TickTimer;
   ar_base->TickTimer = TickTimer;

   // Now tell the i960 to sync with the new timer tick value.
   // ar_channel_cmd(cardnum, 162, 1, 0x0001);
   ar_base->channel    = 0;
   ar_base->parameter1 = 1;
   ar_base->command = 162;           // Must write command last.

   // Each read of DP takes around 1-2 microseconds.  Delay up to 4 ms.
   // Board should be finished in less than 360 us.  This test is independent
   //  of processor speed, it mainly depends on the ISA/PCI bus access times.
   // DO NOT REMOVE DOUBLE READS!
   // Timeout waiting for board to execute command
   for ( goal = 0; goal < 4000; goal++ )
   {
     // Must read twice in case the i960 is writing...
     if ( read_from_board_long(&ar_base->command, 0) == 0 )
       if ( read_from_board_long(&ar_base->command, 0) == 0 )
         break;
//   msleep(1);
   }
// KLOG_DEBUG("goal: %d", goal);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ T I M E R R A T E
 *===========================================================================*
 *
 * FUNCTION:    This routine is used to set the rate that the slave timer
 *              generates timer ticks.
 *
 * PARAMETERS:  short cardnum -- (input) The board number of interest
 *              short Rate    -- (input) Timer rate
 *
 * RETURN VAL:  short         -- ARS_INVARG   invalid FLAG argument
 *
 * DESCRIPTION: The i960 timer is set to the specified value using a Channel
 *              Command.  There is currently only one i960 timer implemented.
 *              Default Sets i960 counter to 5 ms/200 Hz rate
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_set_timerrate(short cardnum, short Rate)
{
   // Return an error on odd rates...
   if (Rate % 4)
     return ARS_INVARG;

   // Command the board to specified mode, only channel zero.
   // "Rate" is saved in DP by the firmware as "TickResolution".
   return ar_channel_cmd(cardnum, CHAN_CMD_TIMER_RATE, (unsigned)Rate, 0x0001);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ T I M E T A G _ C O N T R O L
 *===========================================================================*
 *
 * FUNCTION:    Function to enable/disable timetags on slave.
 *
 * PARAMETERS:  short cardnum  -- (input) the board number of interest
 *              short flag     -- (input) action to take with time tags:
 *                                       ARU_ENABLE_TIMETAG
 *                                       ARU_DISABLE_TIMETAG
 *
 * RETURN VAL:  short         -- ARS_NORMAL   success
 *                            -- ARS_IVBOARD  board is not initialized
 *                            -- ARS_INVARG   invalid FLAG argument
 *
 * DESCRIPTION: Time tags are enabled or disabled on the i960 using a Channel
 *              Command.  All channels are enabled or disabled for compatibility
 *              with the CEI-100/200 even though the CEI-220/420 supports control
 *              of time tag recording on a per channel basis.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_timetag_control(short cardnum, short flag)
{
   int channel;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return 0;

   if ( flag == ARU_ENABLE_TIMETAG )
   {
      return ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_ENABLE_TIMETAG, 0xFFFF);
   }
   else if ( flag == ARU_DISABLE_TIMETAG )
   {
      return ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_DISABLE_TIMETAG, 0xFFFF);
   }
   else if (is_config_item(ARU_ITEM_CHxx_ENABLE_TIMETAG,flag,&channel))
   {
      return ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_ENABLE_TIMETAG, 1 << channel);
   }
   else if (is_config_item(ARU_ITEM_CHxx_DISABLE_TIMETAG,flag,&channel))
   {
      return ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_DISABLE_TIMETAG, 1 << channel);
   }
   else
      return ARS_INVARG;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ X M I T _ S Y N C
 *===========================================================================*
 *
 * FUNCTION:    This routine is used to wait for all of the data in the
 *              transmit queue to be sent.  It is useful for a program
 *              that wants to reset the slave, but needs to wait for it
 *              to complete transmission before halting it.
 *
 * PARAMETERS:  short cardnum  -- (input) The board number of interest
 *              short channel  -- (input) The transmit channel
 *
 * RETURN VAL:  short         -- ARS_NORMAL  success
 *                            -- ARS_NOSYNC  Time out before all data was sent
 *
 * DESCRIPTION: This is a utility that waits for all the data in the transmit
 *              buffer to be loaded into the ARINC transmitter.  It is useful
 *              in an application that is sending data out but doesn't want
 *              to halt the interface until everything has been sent.  It will
 *              only wait up to two seconds, however, and will error return if
 *              everything is not sent.  This is enough time to transmit a full
 *              buffer of 512 labels at the low data rate.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_xmit_sync(short cardnum, short channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   unsigned short tail_ptr, head_ptr;      // Buffer head and tail pointers.
   unsigned long goal;                     // Number of ticks to wait
   unsigned long initial;                  // Initial value of tick timer

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel number out of range return nothing.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   // If board has been commanded to not "GO" the timeout will hang forever.
   if ( ar_board[cardnum].board_ar_go == 0 )
      return ARS_NODATA;

   //  Initialize the max time we will wait.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);  // Go to control page zero.
   // Get the current Timer Tick resolution, 0.25 us LSB.
   goal = ar_base->TickResolution/4; // Convert to 1.0 us LSB
   vbtReleaseFrame(cardnum);
   // Compute the number of Ticks needed to get to 2 seconds.
   goal = 2000000L/goal + 2;         // Two seconds plus some for Granddad
   // Get the starting time.
   initial = ar_get_timercntl(cardnum);

   do
   {
      // Always read the tail pointer twice, just in case the 220 was updating
      //  it at the exact moment we read it.  Don't let the compiler optimize...
      // DO NOT REMOVE DOUBLE READS!
      vbtAcquireFrame(cardnum);
      ar_base = ar_set_cpage(cardnum);            // Go to control page zero.
      head_ptr = ar_base->xmtr[channel].head_ptr;
      tail_ptr = ar_base->xmtr[channel].tail_ptr;

      if ( head_ptr == tail_ptr )
      {
         if ( head_ptr == ar_base->xmtr[channel].tail_ptr )
         {
            vbtReleaseFrame(cardnum);
            return ARS_NORMAL;
         }
      }
      vbtReleaseFrame(cardnum);
      // Multi task for 500 us
#ifdef __WIN32__
      Sleep(2);     // Multi task a bit
#else
      msleep(500);
#endif
   } while ( goal >= (ar_get_timercntl(cardnum) - initial) );
   return ARS_NOSYNC;
}
  
/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ B O A R D T Y P E
 *===========================================================================*
 *
 * FUNCTION:    Return the board type
 *
 * RETURN VAL:  short -- The type of this board.
 *
 * DESCRIPTION: Read the options register and return either CEI-220, CEI-420,
 *              CEI-420A or zero for unknown board type.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_get_boardtype(
   short cardnum)              // (i) card number of interest
{
   short  status;
   struct CONTROL_DPRAM volatile *ar_base;      // Current board pointer.

   // If board number out of range return unknown board type.
   if ( cardnum >= MAX_BOARDS )
      return 0;

   // If board is not initialized return unknown board type.
   if ( ar_board[cardnum].ar_inited == 0 )
      return 0;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);

   // Return either what the host thinks the board is,
   //  or what the board thinks it is (if the board has been booted).
   // Returning what the board thinks it is is much better!
   if ( ar_board[cardnum].board_type == 0 )
       status = (short)(ar_base->regs.m1[OPTIONS_REG] & HW_BOARD_MASK);
   else
       status = (short)((ar_base->ConfigRegs[0]>>8) & HW_BOARD_MASK);

   // Now decode the board type.
   if      ( status == BOARD_IS_220 )
      status = CEI_220;
   else if ( status == BOARD_IS_420 )
      status = CEI_420;
   else if ( status == BOARD_IS_220_6WIR )
      status = CEI_220 | IS_6WIRE;
   else if ( status == BOARD_IS_420_717 )
      status = CEI_420_70J;
   else if ( status == BOARD_IS_420_XXJ )
      status = CEI_420 | IS_717;
   else if ( status == BOARD_IS_420A_12 )
      status = CEI_420A_12;
   else if ( status == BOARD_IS_420A )
      status = CEI_420A;
   else if ( status == BOARD_IS_420AxxJ )
      status = CEI_420A | IS_717;
   else
      status = 0;
   vbtReleaseFrame(cardnum);
   return status;
}

/*===========================================================================*
 * ENTRY POINT:      A R _ G E T _ L A B E L _ F I L T E R
 *===========================================================================*
 *
 * FUNCTION:    Determine the label filter.
 *
 * PARAMETERS:  short cardnum         -- The board number of interest
 *              unsigned short label  -- label to get ?
 *
 * RETURN VAL:  short  -- the label filter value for all channels.
 *
 * DESCRIPTION: Get the channel-wide filter
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_get_label_filter (short cardnum, unsigned short label)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   // If board number out of range return nothing.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return nothing.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // Command the i960 to read the filter value and place it in dual-port.
   ar_channel_cmd(cardnum, CHAN_CMD_FLT_GET, label, 0x0001);

   // Return the filter value to the caller.
   ar_base = ar_set_cpage(cardnum);
   return (short)ar_base->parameter1;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ R A W _ M O D E
 *===========================================================================*
 *
 * FUNCTION:    Get raw mode status.
 *
 * PARAMETERS:  short cardnum   -- (input) The board number of interest
 *              short direction -- (input) The type of channel specified in the
 *                                 channel argument (transmit or receive).
 *                                 Valid values are:
 *                                     ARU_XMIT
 *                                     ARU_RECV
 *              short channel   -- (input) The channel number.  The first channel
 *                                 (transmit or receive) is number 0.
 *
 * RETURN VAL:  short -- AR_ON
 *                    -- AR_OFF
 *                    -- ARS_INVARG
 *
 * DESCRIPTION: N/A
 *
 * NOTE: Changed 2nd param from INT to SHORT for portability.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_get_raw_mode (short cardnum, short direction,
                                             short channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // If channel number out of range return error.
   if ( (unsigned)channel >= MAX_CHAN )
      return ARS_INVARG;

   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.

   // Read the ARINC status bits from the Dual Port shadow.
   if ( direction == ARU_XMIT )
   {
      if ( ar_base->arinc_config_xmt[channel] & R_T_PARITY_EN )
         return AR_OFF;
      else
         return AR_ON;
   }
   else if ( direction == ARU_RECV )
   {
      if ( ar_base->arinc_config_rcv[channel] & R_T_PARITY_EN )
         return AR_OFF;
      else
         return AR_ON;
   }
   else
      return ARS_INVARG;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ N U M _ R C H A N S
 *===========================================================================*
 *
 * FUNCTION:    Return the number of receive channels.  This CAN be between
 *              0 - 16...
 *
 * PARAMETERS:  short cardnum -- The board number of interest
 *
 * RETURN VAL:  short -- The number of receive channels on this board.
 *
 * DESCRIPTION: Read the number of channels which are supported by this board
 *              from the configuration register and return it to the caller.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_num_rchans(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short  status;

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);               // Go to control page.
   status =  (short)(ar_base->numTxRx & 0xff);    // Read number of receivers
   vbtReleaseFrame(cardnum);
   return status;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ N U M _ X C H A N S
 *===========================================================================*
 *
 * FUNCTION:    Return the number of transmit channels
 *
 * PARAMETERS:  short cardnum -- The board number of interest
 *
 * RETURN VAL:  short -- The number of XMIT channels on this board
 *
 * DESCRIPTION: Read the number of transmit channels supported by this board
 *              from the board and return it to the caller.
 *
 *===========================================================================*/

EXPORT32 short DLL_EXPORTED ar_num_xchans(short cardnum)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short  status;

   // If board number out of range return error.
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);               // Go to control page.
   status =  (short)(ar_base->numTxRx >> 8);      // Read number of transmitters
   vbtReleaseFrame(cardnum);
   return status;
}

/*===========================================================================*
 * ENTRY:               A R _ S E T _ D A C _ V A L U E
 *===========================================================================*
 *
 * FUNCTION:    This routine sets the value of a specified DAC.
 *
 * PARAMETERS:  BT_U16BIT cardnum   -- (input) board number of interest.
 *              unsigned long value -- (input) the value to set the item
 *              short item          -- (input) This specifies the control
 *                                     function about which to set information
 *
 * RETURN VAL:  short &status -- not changed    success
 *                            -- ARS_INVHARVAL  invalid value argument for item
 *                            -- ARS_INVHARCMD  invalid item selection
 *                            -- ARS_NO_HW_SUPRT Variable DAC's not supported
 *                                               by current board.
 *
 * DESCRIPTION: This routine is used to set the values of the i960 DAC's.
 *
 *===========================================================================*/
static void ar_set_dac_value(BT_U16BIT cardnum, unsigned long value,
                             short *status, short item)
{
   int channel;
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   ar_base = ar_set_cpage(cardnum);                    // Go to control page.

   // Update the value in Dual Port
   if (is_config_item(ARU_ITEM_DAC_VALUE_xx,item,&channel))
   {
      volatile unsigned short temp = ar_base->DAC_values[channel/2];
      volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
      cptr[channel%2] = (char)value;
      ar_base->DAC_values[channel/2] = temp;
   }
   else
   {
      volatile unsigned short temp = ar_base->DAC_values[(item-ARU_RX1_4_THRESH_VALUE)/2];
      volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
      cptr[(item-ARU_RX1_4_THRESH_VALUE)%2] = (char)value;
      ar_base->DAC_values[(item-ARU_RX1_4_THRESH_VALUE)/2] = temp;
   }

   // Command the i960 to load the value from Dual Port to the DAC's.
   ar_channel_cmd(cardnum, CHAN_LOAD_DACS, 0, 0x0001);

   // If this cardnum does not support Parametrics, return error.
   // Discrete threshold adjustments are always supported.
   // Do it first, then return error for the ATP.
   if ( item == ARU_INPUT_THRESH_VALUE )
      return;

   if ( (ar_base->isParaCEI >> 8) == 0 )
   {
      status[0] = ARS_NO_HW_SUPRT;
      return;
   }
}

/*===========================================================================*
 * ENTRY:               A R _ S E T _ X M I T _ E R R O R _ I N J
 *===========================================================================*
 *
 * FUNCTION:    This routine sets the value of a specified error injection bit.
 *              Bits supported by this function are high-bit, low-bit and gap.
 *
 * PARAMETERS:  BT_U16BIT cardnum   -- (input) board number of interest.
 *              unsigned long value -- (input) the value to set the item
 *              short item          -- (input) This specifies the control
 *                                     function about which to set information
 *
 * RETURN VAL:  short &status -- not changed    success
 *                            -- ARS_INVHARVAL  invalid value argument for item
 *                            -- ARS_INVHARCMD  invalid item selection
 *                            -- ARS_NO_HW_SUPRT Variable DAC's not supported
 *                                               by current board.
 *
 * DESCRIPTION: This routine is used to set the values of the i960 DAC's.
 *
 *===========================================================================*/
static void ar_set_xmit_error_inj(BT_U16BIT cardnum, unsigned long value,
                                  short *status, short item)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int channel;

   ar_base = ar_set_cpage(cardnum);                    // Go to control page zero.

   // Control Page has already been set.  Read parameters from Dual Port
   //  ARINC control shadow.
   if (is_config_item(ARU_ITEM_TX_CHxx_LB_INJ,item,&channel))
   {
      // Low Bit Error Injection to Set or Clear:
      if ( value == AR_ON )
         ar_base->arinc_config_xmt[channel] |= XMTR_BIT_CNT_LOW;
      else if ( value == AR_OFF )
         ar_base->arinc_config_xmt[channel] &= ~XMTR_BIT_CNT_LOW;
      else
      {
         status[0] = ARS_INVHARVAL;
         return;
      }
      // Command the i960 to load the values.
      ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1<<channel);
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_HB_INJ,item,&channel))
   {
      // High Bit Error Injection to Set or Clear;
      if ( value == AR_ON )
         ar_base->arinc_config_xmt[channel] |= XMTR_BIT_CNT_HI;
      else if ( value == AR_OFF )
         ar_base->arinc_config_xmt[channel] &= ~XMTR_BIT_CNT_HI;
      else
      {
         status[0] = ARS_INVHARVAL;
         return;
      }
      // Command the i960 to load the values.
      ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1<<channel);
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_GAP_INJ,item,&channel))
   {
      // Gap Error Injection to Set or Clear;
      if ( value == AR_ON )
         ar_base->arinc_config_xmt[channel] |= XMTR_GAP_ERR_EN;
      else if ( value == AR_OFF )
         ar_base->arinc_config_xmt[channel] &= ~XMTR_GAP_ERR_EN;
      else
      {
         status[0] = ARS_INVHARVAL;
         return;
      }
      // Command the i960 to load the values.
      ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1<<channel);
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_SHUT_OFF,item,&channel))
   {
      // Transmitter Shutdown to Set or Clear;
      if ( value == AR_ON )
         ar_base->arinc_config_xmt[channel] |= XMTR_OUT_DISABLE;
      else if ( value == AR_OFF )
         ar_base->arinc_config_xmt[channel] &= ~XMTR_OUT_DISABLE;
      else
      {
         status[0] = ARS_INVHARVAL;
         return;
      }
      // Command the i960 to load the values.
      ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1<<channel);
   }
   else
   {
      status[0] = ARS_INVHARVAL;
      return;
   }

   // If this board does not support Parametrics, return error.
   if ( (ar_base->isParaCEI >> 8) == 0 )
   {
      status[0] = ARS_NO_HW_SUPRT;
      return;
   }
}

/*===========================================================================*
 * ENTRY:               A R _ S E T _ C O N F I G
 *===========================================================================*
 *
 * FUNCTION:    This routine defines configuration information about the ARINC
 *              interface.  This function sets the current configuration of the
 *              transmitter or receiver (see AR_GET_CONFIG to read the current
 *              configuration values from them).
 *
 * PARAMETERS:  short cardnum       -- (input) the board number
 *              short item          -- (input) This specifies the control
 *                                     function about which to set information
 *              unsigned long value -- (input) the value to set the item
 *
 * RETURN VAL:  short        -- ARS_NORMAL     success
 *                           -- ARS_INVHARVAL  invalid value argument for item
 *                           -- ARS_INVHARCMD  invalid item selection
 *                           -- ARS_INVBOARD   invalid board number
 *                           -- ARS_BRDNOTLOAD ar loadslv() not called
 *
 * DESCRIPTION: This routine is used to set various parameters for the ARINC
 *              interface.  It does this by reading and changing the ARINC
 *              Receive or Transmit Channel Command word which is exchanged
 *              with the i960 slave processor.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_set_config(short cardnum, short item,
                                          unsigned long value)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short  status;
   int    i;
   int    channel;
   long   arinc_rcv[MAX_CHAN];
   long   arinc_xmt[MAX_CHAN];
   //char szMsg[200];

   // If board number out of range return error.
   if ( cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // Fetch the values from the Dual Port ARINC status shadow.
   ar_base = ar_set_cpage(cardnum);
   for ( i = 0; i < MAX_CHAN; i++ )
   {
     arinc_rcv[i] = ar_base->arinc_config_rcv[i];
     arinc_xmt[i] = ar_base->arinc_config_xmt[i];
   }
   //sprintf(szMsg,"Entered cardnum = %d item = %d value = %lX", cardnum, item, value);
   //MessageBox(NULL, szMsg, "ar_set_config", MB_OK | MB_TASKMODAL);
   status = ARS_NORMAL;

   // check the item
   if (is_config_item(ARU_ITEM_RX_CHxx_BIT_RATE,item,&channel))
       ar_set_rrate(&arinc_rcv[channel], value, &status);
   else if (is_config_item(ARU_ITEM_TX_CHxx_BIT_RATE,item,&channel))
       ar_set_xrate (&arinc_xmt[channel], value, &status);
   else if (is_config_item(ARU_ITEM_RX_CHxx_PARITY,item,&channel))
       ar_set_rparity (&arinc_rcv[channel], value, &status);
   else if (is_config_item(ARU_ITEM_TX_CHxx_PARITY,item,&channel))
       ar_set_xparity (&arinc_xmt[channel], value, &status);
   else if (is_config_item(ARU_ITEM_RX_CHxx_SDI_FILTER,item,&channel))
       ar_set_filterm(cardnum, value, &status, channel);
   else if (is_config_item(ARU_ITEM_RX_CHxx_SDI_VALUE,item,&channel))
       ar_set_sdival(cardnum, value, &status, channel);
   else if ( (is_config_item(ARU_ITEM_TX_CHxx_SHUT_OFF,item,&channel)) ||
             (is_config_item(ARU_ITEM_TX_CHxx_HB_INJ,item,&channel)) ||
             (is_config_item(ARU_ITEM_TX_CHxx_LB_INJ,item,&channel)) ||
             (is_config_item(ARU_ITEM_TX_CHxx_GAP_INJ,item,&channel))     )
   {   
       ar_set_xmit_error_inj(cardnum, value, &status, item);
       return status;
   }
   else if (is_config_item(ARU_ITEM_DAC_VALUE_xx,item,&channel))
   {
       if ( value > 255 )
          return ARS_BAD_DAC_VAL;
       ar_set_dac_value(cardnum, value, &status, item);
          return status;
   }
   else if (is_config_item(ARU_ITEM_OUTPUT_LEVEL_ADJ_xx,item,&channel))
   {
       if ( value == AR_OFF )
          arinc_xmt[channel] &= ~XMTR_VOLT_ENABLE;
       else if ( value == AR_ON )
          arinc_xmt[channel] |= XMTR_VOLT_ENABLE;
       else
          status |= ARS_INVHARVAL;
   }
   else {
       switch (item)
       {
          case ARU_X1_RATE:
             ar_set_xrate (&arinc_xmt[0], value, &status);
             break;
          case ARU_X2_RATE:
             ar_set_xrate (&arinc_xmt[1], value, &status);
             break;
          case ARU_X3_RATE:
             ar_set_xrate (&arinc_xmt[2], value, &status);
             break;
          case ARU_X4_RATE:
             ar_set_xrate (&arinc_xmt[3], value, &status);
             break;
          case ARU_XMIT_RATE:
             for ( i = 0; i < MAX_CHAN; i++ )
               ar_set_xrate (&arinc_xmt[i], value, &status);
             break;
          case ARU_R12_RATE:
             ar_set_rrate(&arinc_rcv[0], value, &status);
             ar_set_rrate(&arinc_rcv[1], value, &status);
             break;
          case ARU_R34_RATE:
             ar_set_rrate(&arinc_rcv[2], value, &status);
             ar_set_rrate(&arinc_rcv[3], value, &status);
             break;
          case ARU_R56_RATE:
             ar_set_rrate(&arinc_rcv[4], value, &status);
             ar_set_rrate(&arinc_rcv[5], value, &status);
             break;
          case ARU_R78_RATE:
             ar_set_rrate(&arinc_rcv[6], value, &status);
             ar_set_rrate(&arinc_rcv[7], value, &status);
             break;
          case ARU_RECV_RATE:
             for ( i = 0; i < MAX_CHAN; i++ )
                ar_set_rrate(&arinc_rcv[i], value, &status);
             break;
          case ARU_R12X1_PARITY:   // Xmit parity
             ar_set_xparity(&arinc_xmt[0], value, &status);
             ar_set_xparity(&arinc_xmt[1], value, &status);
             break;
          case ARU_R34X2_PARITY:   // Xmit parity
             ar_set_xparity(&arinc_xmt[2], value, &status);
             ar_set_xparity(&arinc_xmt[3], value, &status);
             break;
          case ARU_R56X3_PARITY:   // Xmit parity
             ar_set_xparity(&arinc_xmt[4], value, &status);
             ar_set_xparity(&arinc_xmt[5], value, &status);
             break;
          case ARU_R78X4_PARITY:   // Xmit parity
             ar_set_xparity(&arinc_xmt[6], value, &status);
             ar_set_xparity(&arinc_xmt[7], value, &status);
             break;
          case ARU_PARITY:         // Xmit parity all channels
             for ( i = 0; i < MAX_CHAN; i++ )
                ar_set_xparity (&arinc_xmt[i], value, &status);
             break;
          case ARU_INTERNAL_WRAP:
             if (value == AR_WRAP_OFF)
             {
                for ( i = 0; i < MAX_CHAN; i++ )
                   arinc_rcv[i] &= ~RCVR_WRAP_ENABLE;
             }
             else if (value == AR_WRAP_ON)
             {
                for ( i = 0; i < MAX_CHAN; i++ )
                   arinc_rcv[i] |= RCVR_WRAP_ENABLE;
             }
             else
                status = ARS_INVHARVAL;
             break;
          case ARU_WORD_LENGTH:
             if (value == AR_SHORT)
             {
                for ( i = 0; i < MAX_CHAN; i++ )
                   arinc_xmt[i] |= XMTR_BIT_CNT_LOW;
             }
             else if (value == AR_LONG)
             {
                for ( i = 0; i < MAX_CHAN; i++ )
                   arinc_xmt[i] &= ~XMTR_BIT_CNT_LOW;
             }
             else
                status = ARS_INVHARVAL;
             break;
          case ARU_R1_SDI_FILTER:
          case ARU_R2_SDI_FILTER:
          case ARU_R3_SDI_FILTER:
          case ARU_R4_SDI_FILTER:
          case ARU_R5_SDI_FILTER:
          case ARU_R6_SDI_FILTER:
          case ARU_R7_SDI_FILTER:
          case ARU_R8_SDI_FILTER:
             ar_set_filterm(cardnum, value, &status, item-ARU_R1_SDI_FILTER);
             break;
          case ARU_R1_SDI_VALUE:
          case ARU_R2_SDI_VALUE:
          case ARU_R3_SDI_VALUE:
          case ARU_R4_SDI_VALUE:
          case ARU_R5_SDI_VALUE:
          case ARU_R6_SDI_VALUE:
          case ARU_R7_SDI_VALUE:
          case ARU_R8_SDI_VALUE:
             ar_set_sdival(cardnum, value, &status, item-ARU_R1_SDI_VALUE);
             break;

          //----------------------------------------------------------------------*
          //  CEI-220/420 Set Config Support
          //----------------------------------------------------------------------*
          case ARU_RX1_4_THRESH_VALUE:     /* All DAC values get set here   */
          case ARU_RX5_8_THRESH_VALUE:
          case ARU_RX9_10_THRESH_VALUE:
          case ARU_RX11_12_THRESH_VALUE:
          case ARU_INPUT_THRESH_VALUE:
          case ARU_TRANSMIT_VOLT_VALUE:
             if ( value > 255 )
                return ARS_BAD_DAC_VAL;
             ar_set_dac_value(cardnum, value, &status, item);
             return status;
          case ARU_DISCRETE_VALUES:
          case ARU_DISCRETE_OUTPUTS:
             ar_base->discrete_out = (short)value;
             return status;
          default:
             return ARS_INVHARCMD;
       }
   }
   for ( i = 0; i < MAX_CHAN; i++ )
      ar_write_ARINC(cardnum, arinc_rcv[i],  arinc_xmt[i],  i);
   return status;
}

/*===========================================================================*
 * ENTRY:               A R _ G E T _ C O N F I G
 *===========================================================================*
 *
 * FUNCTION:    This routine returns configuration information about the ARINC
 *              interface.  This function reads the current configuration
 *              of the ARINC receivers and/or transmitters (see the function
 *              AR_SET_CONFIG to program them).
 *
 * PARAMETERS:  short cardnum -- (input) Specifies which of up to 10 boards
 *                              this routine is to access (valid range is 0-9).
 *              short item    -- (input) This specifies the control function
 *                              about which to return information.
 *
 * RETURN VAL:  long -- value of requested item.
 *
 * DESCRIPTION: The current programmed value of the specified ARINC interface
 *              is read and the specified information is extracted for the
 *              caller.
 *
 *===========================================================================*/
EXPORT32 long int DLL_EXPORTED ar_get_config(short cardnum, short item)
{
   int    type;         // Generic 220/420/420A board type.
   int    channel;
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   long arinc_rcv, arinc_xmt;

   // If board number out of range return error.
   if ( cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   // If board is not initialized return error.
   if ( ar_board[cardnum].ar_inited == 0 )
      return ARS_BRDNOTLOAD;

   // Set control page active and read the current receive/transmit config
   //  values directly from dual port memory.
   ar_base = ar_set_cpage(cardnum);
   arinc_rcv = ar_base->arinc_config_rcv[0];
   arinc_xmt = ar_base->arinc_config_xmt[0];

   // check the item
   if (is_config_item(ARU_ITEM_RX_CHxx_BIT_RATE,item,&channel))
       return (ar_get_rrate(ar_base->arinc_config_rcv[channel]));
   else if (is_config_item(ARU_ITEM_TX_CHxx_BIT_RATE,item,&channel))
       return (ar_get_xrate(ar_base->arinc_config_xmt[channel]));
   else if (is_config_item(ARU_ITEM_RX_CHxx_PARITY,item,&channel))
       return (ar_get_rparity(ar_base->arinc_config_rcv[channel]));
   else if (is_config_item(ARU_ITEM_TX_CHxx_PARITY,item,&channel))
       return (ar_get_xparity(ar_base->arinc_config_xmt[channel]));
   else if (is_config_item(ARU_ITEM_RX_CHxx_SDI_FILTER,item,&channel))
       return (ar_get_filterm(cardnum, channel));
   else if (is_config_item(ARU_ITEM_RX_CHxx_SDI_VALUE,item,&channel))
       return (ar_get_sdival(cardnum, channel));
   else if (is_config_item(ARU_ITEM_TX_CHxx_SHUT_OFF,item,&channel))
   {
       if ( ar_base->arinc_config_xmt[channel] & XMTR_OUT_DISABLE )
          return AR_ON;
       else
          return AR_OFF;
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_HB_INJ,item,&channel))
   {
       if ( ar_base->arinc_config_xmt[channel] & XMTR_BIT_CNT_HI )
           return AR_ON;
       else
           return AR_OFF;   
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_LB_INJ,item,&channel))
   {
       if ( ar_base->arinc_config_xmt[channel] & XMTR_BIT_CNT_LOW )
           return AR_ON;
       else
           return AR_OFF;
   }
   else if (is_config_item(ARU_ITEM_TX_CHxx_GAP_INJ,item,&channel))
   {
       if ( ar_base->arinc_config_xmt[channel] & XMTR_GAP_ERR_EN )
           return AR_ON;
       else
           return AR_OFF;
   }
   else if (is_config_item(ARU_ITEM_DAC_VALUE_xx,item,&channel))
   {
       volatile unsigned short temp = ar_base->DAC_values[channel/2];
       volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
       return cptr[channel%2];
/*        return (ar_base->DAC_values[channel]); */
   }
   else if (is_config_item(ARU_ITEM_OUTPUT_LEVEL_ADJ_xx,item,&channel))
   {
       return (ar_base->arinc_config_xmt[channel] & XMTR_VOLT_ENABLE);
   }
   else {
       switch (item)
       {
          case ARU_XMIT_RATE:
             return (ar_get_xrate(arinc_xmt));
          case ARU_X1_RATE:
          case ARU_X2_RATE:
          case ARU_X3_RATE:
          case ARU_X4_RATE:
             arinc_xmt = ar_base->arinc_config_xmt[item-ARU_X1_RATE];
             return (ar_get_xrate(arinc_xmt));

          case ARU_RECV_RATE:
             return (ar_get_rrate (arinc_rcv));

          case ARU_R12_RATE:
             return (ar_get_rrate (arinc_rcv));
          case ARU_R34_RATE:
             return (ar_get_rrate(ar_base->arinc_config_rcv[3]));
          case ARU_R56_RATE:
             return (ar_get_rrate(ar_base->arinc_config_rcv[5]));
          case ARU_R78_RATE:
             return (ar_get_rrate(ar_base->arinc_config_rcv[7]));

          case ARU_R12X1_PARITY:   // Xmitter Parity
             return (ar_get_xparity(arinc_xmt));
          case ARU_R34X2_PARITY:   // Xmitter Parity
             return (ar_get_xparity(ar_base->arinc_config_xmt[1]));
          case ARU_R56X3_PARITY:   // Xmitter Parity
             return (ar_get_xparity(ar_base->arinc_config_xmt[2]));
          case ARU_R78X4_PARITY:   // Xmitter Parity
             return (ar_get_xparity(ar_base->arinc_config_xmt[3]));

          case ARU_PARITY:         // Xmitter Parity
             if ((arinc_xmt & R_T_PARITY_EN) == R_T_PARITY_EN)
                return (AR_ODD);
             else
                return (AR_EVEN);
          case ARU_INTERNAL_WRAP:
             if ((arinc_rcv & RCVR_WRAP_ENABLE) == RCVR_WRAP_ENABLE)
                return (AR_WRAP_ON);
             else
                return (AR_WRAP_OFF);
          case ARU_WORD_LENGTH:
             if ((arinc_xmt & XMTR_BIT_CNT_LOW) == XMTR_BIT_CNT_LOW)
                return (AR_SHORT);
             else
                return (AR_LONG);

          case ARU_R1_SDI_FILTER:
          case ARU_R2_SDI_FILTER:
          case ARU_R3_SDI_FILTER:
          case ARU_R4_SDI_FILTER:
          case ARU_R5_SDI_FILTER:
          case ARU_R6_SDI_FILTER:
          case ARU_R7_SDI_FILTER:
          case ARU_R8_SDI_FILTER:
             return (ar_get_filterm(cardnum, item-ARU_R1_SDI_FILTER));

          case ARU_R1_SDI_VALUE:
          case ARU_R2_SDI_VALUE:
          case ARU_R3_SDI_VALUE:
          case ARU_R4_SDI_VALUE:
          case ARU_R5_SDI_VALUE:
          case ARU_R6_SDI_VALUE:
          case ARU_R7_SDI_VALUE:
          case ARU_R8_SDI_VALUE:
             return (ar_get_sdival(cardnum, item-ARU_R1_SDI_VALUE));

          //----------------------------------------------------------------------*
          //  CEI-220/420 support
          //----------------------------------------------------------------------*
          case ARU_RX1_4_THRESH_VALUE:        /* All DAC values get returned here */
            {                                 /* Control Page has already been set*/
              volatile unsigned short temp = ar_base->DAC_values[0/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[0%2];
            }
/*              return (ar_base->DAC_values[0]); */
          case ARU_RX5_8_THRESH_VALUE:
            {
              volatile unsigned short temp = ar_base->DAC_values[1/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[1%2];
            }
/*              return (ar_base->DAC_values[1]); */
          case ARU_RX9_10_THRESH_VALUE:
            {
              volatile unsigned short temp = ar_base->DAC_values[2/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[2%2];
            }
/*              return (ar_base->DAC_values[2]); */
          case ARU_RX11_12_THRESH_VALUE:
            {
              volatile unsigned short temp = ar_base->DAC_values[3/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[3%2];
            }
/*              return (ar_base->DAC_values[3]); */
          case ARU_INPUT_THRESH_VALUE:
            {
              volatile unsigned short temp = ar_base->DAC_values[4/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[4%2];
            }
/*              return (ar_base->DAC_values[4]); */
          case ARU_TRANSMIT_VOLT_VALUE:
            {
              volatile unsigned short temp = ar_base->DAC_values[5/2];
              volatile unsigned char *cptr = (volatile unsigned char *)(&temp);
              return cptr[5%2];
            }
/*              return (ar_base->DAC_values[5]); */
          case ARU_PARAMETRIC_SUPPORT:
            if ( (ar_base->isParaCEI >> 8) )
                return AR_ON;
             else
                return AR_OFF;
          case ARU_DISCRETE_INPUTS:
          case ARU_DISCRETE_VALUES:
             type = ar_board[cardnum].board_type & API_BOARD_TYPE_MASK;
             if ( type == CEI_220 )
                return ar_base->discrete_in&0x000F;       // 4 discrete inputs
             else if ( type == CEI_420 )
                return ar_base->discrete_in&0x00FF;       // 8 discrete inputs
             else if ( type == CEI_420A )
                return ar_base->discrete_in;              // 16 discrete inputs
             else
                return ar_base->discrete_in;              // 16 discrete inputs
          case ARU_DISCRETE_OUTPUTS:
             return ar_base->discrete_out;
          default:
             return (ARS_INVHARCMD);
       }
   }
}

/*===========================================================================*
 * ENTRY POINT:         A R _ W R I T E _ A R I N C
 *===========================================================================*
 *
 * FUNCTION:    Function to write a value to the ARINC command register.
 * 
 * PARAMETERS:  BT_UINT cardnum   -- (input) board number of interest.
 *              long    arinc_rcv -- (input) arinc receiver control word
 *              long    arinc_xmt -- (input) arinc transmitter control word
 *              int     channel   -- (input) channel to modify
 * 
 * RETURN VAL:  ARS_NORMAL if successfully completed, else error code
 *
 * DESCRIPTION: Determine apropriate channel and poke in the value.  Then
 *              command the i960 to load the value into the ARINC config
 *              register.
 *
 *===========================================================================*/
                                              
static short ar_write_ARINC(BT_UINT cardnum, long arinc_rcv, long arinc_xmt,
                            int channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.

   ar_base = ar_set_cpage(cardnum);                  // Go to control page zero.

   // Load the configuration value back into dual port memory.
   ar_base->arinc_config_rcv[channel] = arinc_rcv;
   ar_base->arinc_config_xmt[channel] = arinc_xmt;

   return ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);
}
 
/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ R P A R I T Y 
 *===========================================================================*
 *
 * FUNCTION:    Determine receiver parity
 * 
 * PARAMETERS:  long arinc_cmd  -- command word to check.
 * 
 * RETURN VAL:  short           -- AR_EVEN => Even parity
 *                                 AR_ODD  => Odd parity
 *
 * DESCRIPTION: N/A
 * 
 *===========================================================================*/
                                     
static short ar_get_rparity(long arinc_cmd)
{
   if ((arinc_cmd & R_T_PARITY_EN) == R_T_PARITY_EN)
      return AR_ODD;
   else
      return AR_OFF;
}


/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ X P A R I T Y
 *===========================================================================*
 *
 * FUNCTION:    Determine transmitter parity
 *
 * PARAMETERS:  long arinc_cmd  -- command word to check.
 *
 * RETURN VAL:  short           -- AR_EVEN => Even parity
 *                                 AR_ODD  => Odd parity
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static short ar_get_xparity(long arinc_cmd)
{
   return (short)(((arinc_cmd & XMTR_PARITY_EVEN) == XMTR_PARITY_EVEN) ? (AR_EVEN) : (AR_ODD));
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ X R A T E
 *===========================================================================*
 *
 * FUNCTION:    Determine transmission rate
 *
 * PARAMETERS:  short -- arinc_cmd
 *
 * RETURN VAL:  short -- AR_LOW
 *                       AR_HIGH
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static short ar_get_xrate(long arinc_cmd)
{
   if ((arinc_cmd & R_T_HI_SPEED) == R_T_HI_SPEED)
      return AR_HIGH;
   else
      return AR_LOW;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ R R A T E
 *===========================================================================*
 *
 * FUNCTION:    Determine receive rate
 *
 * PARAMETERS:  short -- arinc_cmd
 *
 * RETURN VAL:  short -- AR_LOW
 *                       AR_HIGH
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static short ar_get_rrate(long arinc_cmd)
{
   if ((arinc_cmd & R_T_HI_SPEED) == R_T_HI_SPEED)
      return AR_HIGH;
   else
      return AR_LOW;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ F I L T E R M
 *===========================================================================*
 *
 * FUNCTION:    Determine if SDI filtering is on
 *
 * PARAMETERS:  BT_UINT cardnum --  (input) board number of interest.
 *              int     channel -- channel to test
 *
 * RETURN VAL:  short -- AR_OFF
 *                       AR_ON
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static short ar_get_filterm(BT_UINT cardnum, int channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short status;

   // Ask the specified board/channel the values of the SDI mask and value.
   status = ar_channel_cmd(cardnum, CHAN_CMD_SDI_READ, 0, 1<<channel);
   if ( status )
      return status;

   // Parameter 1 contains the filter value
   // Parameter 2 contains the filter mask
   // If the mask is non-zero the filter is ON
   ar_base = ar_set_cpage(cardnum);
   if ( ar_base->parameter2 )
      return AR_ON;
   else
      return AR_OFF;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ G E T _ S D I V A L
 *===========================================================================*
 *
 * FUNCTION:    Determine SDI value
 *
 * PARAMETERS:  BT_UINT cardnum -- (input) board number of interest.
 *              int     channel -- channel to test
 *
 * RETURN VAL:  short -- SDI value
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static short ar_get_sdival(BT_UINT cardnum, int channel)
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   short status;

   // Ask the specified board/channel the values of the SDI mask and value.
   status = ar_channel_cmd(cardnum, CHAN_CMD_SDI_READ, 0, 1<<channel);
   if ( status )
      return status;

   // Parameter 1 contains the SDI filter value
   // Parameter 2 contains the SDI filter enable flag
   // Shift the filter value 8 bits to extract the SDI test value.
   ar_base = ar_set_cpage(cardnum);
   return (short)(ar_base->parameter1 >> 8);
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ R P A R I T Y
 *===========================================================================*
 *
 * FUNCTION:    Set the receiver parity in the command word.
 *
 * PARAMETERS:  long  * arinc_cmd -- (input) ARINC command word.
 *              long    value     -- (input) parity to set(AR_ON/AR_ODD, AR_OFF)
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, inwhich case status is
 *                                   set to ARS_INVHARVAL.
 *
 * RETURN VAL:  void
 *
 *===========================================================================*/

static void ar_set_rparity(long *arinc_cmd, long value, short *status)
{
   if ( value == AR_OFF )
      *arinc_cmd &= ~R_T_PARITY_EN;   // Set receive parity to NONE
   else if ( (value == AR_ODD ) || (value == AR_ON) )
      *arinc_cmd |= R_T_PARITY_EN;    // Set receive parity to ENABLE
   else
      *status = ARS_INVHARVAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ X P A R I T Y
 *===========================================================================*
 *
 * FUNCTION:    Set the transmitter parity in the command word.
 *
 * PARAMETERS:  long  * arinc_cmd -- (input) ARINC command word.
 *              long    value     -- (input) parity to set(AR_ODD, AR_EVEN)
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, in which case status is
 *                                   set to ARS_INVHARVAL.
 *
 * RETURN VAL:  void
 *
 *===========================================================================*/

static void ar_set_xparity(long *arinc_cmd, long value, short *status)
{
   if ( value == AR_EVEN )
   {
      *arinc_cmd |= R_T_PARITY_EN;
      *arinc_cmd |= XMTR_PARITY_EVEN;   // Enable Even parity
   }
   else if ( value == AR_ODD )
   {
      *arinc_cmd |= R_T_PARITY_EN;
      *arinc_cmd &= ~XMTR_PARITY_EVEN;  // Enable Odd parity
   }
   else if ( value == AR_OFF )
   {
      *arinc_cmd &= ~R_T_PARITY_EN;    // Disable parity (enable RAW mode)
   }
   else
      *status = ARS_INVHARVAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ R R A T E
 *===========================================================================*
 *
 * FUNCTION:    Set the receive baud rate High/Low.
 *              For a -429 channel set either 100/12.5 Kbaud,
 *              for a CSDB channel set either 50/12.5 Kbaud,
 *              for a -717 channel set either 12288/6144 baud.
 *
 * PARAMETERS:  long * arinc_cmd  -- pointer to the ARINC command word.
 *              long value        -- (input) receive rate
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, inwhich case status is
 *                                   set to ARS_INVHARVAL.
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static void ar_set_rrate(long *arinc_cmd, long value, short *status)
{
   if ( value == AR_LOW )
      *arinc_cmd &= ~R_T_HI_SPEED;
   else if ( value == AR_HIGH )
      *arinc_cmd |= R_T_HI_SPEED;
   else
      *status = ARS_INVHARVAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ X R A T E
 *===========================================================================*
 *
 * FUNCTION:    Set the transmission baud rate.
 *
 * PARAMETERS:  long * arinc_cmd  -- pointer to the ARINC command word.
 *              long value        -- (input) transmission rate
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, in which case status is
 *                                   dereferenced and set to ARS_INVHARVAL.
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static void ar_set_xrate(long *arinc_cmd, long value, short *status)
{
   if (value == AR_LOW)
      *arinc_cmd &= ~R_T_HI_SPEED;
   else if (value == AR_HIGH)
      *arinc_cmd |= R_T_HI_SPEED;
   else
      *status = ARS_INVHARVAL;
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ F I L T E R M
 *===========================================================================*
 *
 * FUNCTION:    Set the SDI filter mask
 *
 * PARAMETERS:  BT_UINT cardnum   -- (input) board number of interest.
 *              long value        -- (input) AR_ON or AR_OFF
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, in which case status is
 *                                   dereferenced and set to ARS_INVHARVAL.
 *              int channel       -- channel to filter.
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static void ar_set_filterm(BT_UINT cardnum, long value, short *status, int channel)
{
   short lstatus;

   // Ask the specified board/channel to update value of the SDI enable.
   if ( value == AR_ON )
      lstatus = ar_channel_cmd(cardnum, CHAN_CMD_SDI_ENABLE, 1, 1<<channel);
   else if ( value == AR_OFF )
      lstatus = ar_channel_cmd(cardnum, CHAN_CMD_SDI_ENABLE, 0, 1<<channel);
   else
   {
      *status = ARS_INVHARVAL;
      return;
   }
   if ( lstatus )
   {
      *status = lstatus;
      return;
   }
}

/*===========================================================================*
 * ENTRY POINT:         A R _ S E T _ S D I V A L
 *===========================================================================*
 *
 * FUNCTION:    Set the SDI filter value
 *
 * PARAMETERS:  BT_UINT cardnum   -- (input) board number of interest.
 *              long    value     -- (input) SDI value (0-3)
 *              short * status    -- (output) untouched unless invalid value
 *                                   is passed in, in which case status is
 *                                   dereferenced and set to ARS_INVHARVAL.
 *              int     channel   -- channel to filter.
 *
 * RETURN VAL:  void
 *
 * DESCRIPTION: N/A
 *
 *===========================================================================*/

static void ar_set_sdival(BT_UINT cardnum, unsigned long value,
                          short *status, int channel)
{
   short lstatus;

   if ( value > 3 )
   {
      *status = ARS_INVHARVAL;
      return;
   }
   // Ask the specified board/channel to update value of the SDI value.
   lstatus = ar_channel_cmd(cardnum, CHAN_CMD_SDI_VALUE, value, 1<<channel);
   if ( lstatus )
   {
      *status = lstatus;
      return;
   }
}


/*===========================================================================*
 * INTERNAL ROUTINE:      A R _ G E T _ C H A N T Y P E
 *===========================================================================*
 *
 * FUNCTION:    Detemine the channel type flag associated with the given
 *              channel.
 *
 * RETURN VAL:  Return the channel type flag (CHAN_xxx) for the specified
 *              transmitter or receiver.
 *
 *===========================================================================*/
static short ar_get_chantype
(
   short cardnum,            // (i) the board number of interest
   int is_recv,              // (i) non-zero if rx channel, 0 if tx channel
   int channel               // (i) channel number of interest
)
{
   // save the current board type
   int board_type = ar_board[cardnum].board_type;

   // check for non-429 channels
   if ((board_type == (CEI_220 | IS_6WIRE)) && (channel == 4))
      return CHAN_6WIRE;
   else if ((board_type == (CEI_420 | IS_717)) && (channel == 7))
      return CHAN_ARINC717;
   else if ((board_type == (CEI_420_70J)) && (channel == 7))
      return CHAN_ARINC717;
   else if ((board_type == (CEI_420A | IS_717)) && (channel == 7))
      return CHAN_ARINC717;

   // check if it's a valid 429 receiver
   if ((is_recv != 0) && (channel < ar_num_rchans(cardnum)))
      return CHAN_ARINC429;

   // check if it's a valid 429 transmitter 
   if ((is_recv == 0) && (channel < ar_num_xchans(cardnum)))
      return CHAN_ARINC429;

   // channel not implemented
   return CHAN_NOT_IMPLEMENTED;
}


/*===========================================================================*
 * ENTRY POINT:          A R _ C L O S E
 *===========================================================================*
 *
 * FUNCTION:    Shutdown the i960, unmap it's host resources.
 *
 * RETURN VAL:  short -- ARS_NORMAL    Success.
 *
 * DESCRIPTION: This routine stops the i960 and releases the memory mapping
 *              resources allocated by the host.
 *              This must be the last utility subroutine executed.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_close(
   short cardnum)           // (i) Board number to be closed
{
   //------------------------------------------------------------------------
   //  Check validity of board number, and see if board is open.V3.24.ajh
   //------------------------------------------------------------------------
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   if ( ar_board[cardnum].board_mapped == 0 )
      return ARS_NORMAL;

   // Terminate processing by the board.
   ar_reset(cardnum);       // No more interrupts

#if 0 // TODO - use a logical test to see if this board is interrupt driven
#error "the cei420a is not interrupt driven!"
   // Clear the hardware interrut
   ar_reset_int(cardnum);
#endif
   ar_board[cardnum].board_mapped = 0;
   return ARS_NORMAL;
}


/*===========================================================================*
 * ENTRY POINT:          A R _ L O A D S L V _ I N I T _ D I S C R E T E
 *===========================================================================*
 *
 * FUNCTION:    Load and initialize the CEI-x20 dual-port RAM, i960 processor,
 *              and discrete outputs. 
 *
 * RETURN VAL:  short -- ARS_NORMAL    Success.
 *                    -- ARS_INVBOARD  The board segment was out of range.
 *                    -- ARS_BADLOAD   The memory test failed and the board was
 *                                     not loaded.
 *                    -- ARS_BAD_FPGA  Bad number of transmitters or receivers,
 *                                     no FPGA support for this config.
 *
 * DESCRIPTION: This function wraps the standard AR_LOADSLV initialization 
 *              routine, but allows the caller to specify the initial value
 *              of the discrete outputs. See AR_LOADSLV for more details.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_loadslv_init_discrete(
   short cardnum,           // (i) Board number associated with this and all
                            //     future references to the board.  Since up to
                            //     MAX_BOARDS are supported simultaneously in one
                            //     host, each board has a unique number.
                            //     Under WIN32 this is the WinRT device number
                            //     and the base_seg is ignored.
   unsigned long base_seg,  // (i) Ignored in WIN32, else is the Base Address of
                            //     the board memory space.
   int base_port,           // (i) Ignored in WIN32, or if non-zero used to
                            //       enter a special FACTORY TEST mode,
                            //     else is the address of the PCI-9050
                            //       configuration registers.
   unsigned short ram_size, // (i) unused, should be set to zero
   unsigned long disc_init) // (i) Desired initial value of the discrete 
                            //     outputs at startup.

{
   // device driver and loader function status
   short status;                  

   // flag the discrete output override value as valid
   use_init_discrete_override = TRUE;
   init_discrete_override = disc_init;

   // pass off control to ar_loadslv
   status = ar_loadslv(cardnum,base_seg,base_port,ram_size);

   // clear discrete override flag
   use_init_discrete_override = FALSE;

   // return the ar_loadslv result
   return status;
}


/*===========================================================================*
 * ENTRY POINT:          A R _ L O A D S L V
 *===========================================================================*
 *
 * FUNCTION:    Load and initialize the CEI-x20 dual-port RAM and i960 processor.
 *
 * RETURN VAL:  short -- ARS_NORMAL    Success.
 *                    -- ARS_INVBOARD  The board segment was out of range.
 *                    -- ARS_BADLOAD   The memory test failed and the board was
 *                                     not loaded.
 *                    -- ARS_BAD_FPGA  Bad number of transmitters or receivers,
 *                                     no FPGA support for this config.
 *
 * DESCRIPTION: This routine loads the Slave Control Program into dual-port
 *              RAM.  (The i960 runs it's firmware out of dual-port RAM).
 *              This must be the first utility subroutine executed.
 *
 *      The routine resets the slave then performs a memory check on the dual-
 *      port memory.  If the memory test passes, the slave program is loaded
 *      and started.
 *
 *      Upon successful completion of this routine, the following ARINC defaults
 *      are in effect:  Transmit and receive bit rates are 100K; Parity ODD;
 *      SDI and label filters disabled; Timer rate 5 milliseconds.
 *
 *===========================================================================*/
EXPORT32 short DLL_EXPORTED ar_loadslv(
   short cardnum,           // (i) Board number associated with this and all
                            //     future references to the board.  Since up to
                            //     MAX_BOARDS are supported simultaneously in one
                            //     host, each board has a unique number.
                            //     Under WIN32 this is the WinRT device number
                            //     and the base_seg is ignored.
   unsigned long base_seg,  // (i) Ignored in WIN32, else is the Base Address of
                            //     the board memory space.
   int base_port,           // (i) Ignored in WIN32, or if non-zero used to
                            //     enter a special FACTORY TEST mode.
   unsigned short ram_size) // (i) unused, should be set to zero.  If non-zero
                            //     used to enter a special FACTORY TEST mode.
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int    channel;
   int    status = BTD_OK;                 // Device driver and loader function status
   //------------------------------------------------------------------------
   //  Check validity of board number.
   //------------------------------------------------------------------------
   if ( (unsigned)cardnum >= MAX_BOARDS )
      return ARS_INVBOARD;

   //---------------------------------------------------------------------
   // Open CEI-x20 low-level driver to map board into our address space.
   //  Since this is a WIN32 application, we will call the kernel driver
   //  open function here.  Check to see if driver is already opened,
   //  then map the memory region and save the memory region pointer.V3.22
   //---------------------------------------------------------------------
   if ( ar_board[cardnum].board_mapped == 0 )
   {
      // If this is a CEI-520 board, it has two mapping regions
      ar_board[cardnum].pMap.flagMapToHost[0] = 1;  // Map the first
      ar_board[cardnum].pMap.flagMapToHost[1] = 1;  //  two memory regions.

      // map ISA card memory into kernel memory
      ar_board[cardnum].pMap.memHostBase[0] = (char *)base_seg;
      
      // The CEI-420 cards do not have a second memory_region...
      ar_board[cardnum].pMap.flagMapToHost[1] = 0;
      status = BTD_OK;

      // CEI-520/620 is not supported by the standard API, see the Enhanced
      //  API ("API520.C") for support.
      if ( ar_board[cardnum].pMap.flagMapToHost[1] )
      {
         return ARS_NO_HW_SUPRT;   // Only the CEI-520/620 maps two regions
      }
      else
      {
         ar_static_base[cardnum] = (void *)ar_board[cardnum].pMap.memHostBase[0];
      }
      if ( status != BTD_OK )
      {
         sprintf(last_error, "Failed to map the CEI-x20 board, "
                             "error %d", status);
         return (short)status;   // Return LOWLEVEL.C error code.
      }
   }
   // Board has been commanded to not "GO"
   ar_board[cardnum].board_ar_go = 0;

   // Get the board type (either a CEI-220, CEI-420 or a CEI-420A).
   ar_board[cardnum].board_type = 0;  // Clear the board type
   ar_board[cardnum].ar_inited  = 1;  // So we can read board type
   ar_board[cardnum].board_type = ar_get_boardtype(cardnum);

   if ( ar_board[cardnum].board_type == 0 )
      return ARS_HW_DETECT;

   //----------------------------------------------------------------------
   // W A R N I N G !!  Ugly Code Follows:                                +
   //---------------------------------------------------------------------+
   //  Modify the i960 load image...at offset ff90 into dual port.        +
   //  Dual port on the CEI-220/420/420A is 16-bits wide.                 +
   //----------------------------------------------------------------------
#define IBR_BASE  (0xF000/2)
   // Modify the i960 image for CEI-220/420/420A processors.
   i960_data[IBR_BASE+0x0F30/2+4] = 0x0040;
   i960_data[IBR_BASE+0x0F80/2+5] = 0x0040;    // 16-bit wide
   i960_data[IBR_BASE+0x0FB0/2+5] = 0x0040;

   //ar_board[cardnum].ar_inited = 0; // We are not done yet...

   //------------------------------------------------------------------------
   //  Initialize some global info for this board and then load and start it.
   //  i960 comes up in "ar_reset" mode, it does NOT process ARINC data until
   //   "ar_go" is called, but it DOES process the discretes...
   //------------------------------------------------------------------------
   ar_board[cardnum].board_mapped = 1;
   status = loader(cardnum, base_port, ram_size);
   if ( status )
      return (short)status;    // last_error has already been setup...

   //------------------------------------------------------------------------
   //  Initialize i960 receiver and transmitter buffer data structures.     +
   //  The i960 is running at this point, but it is not ar_go()...          +
   //------------------------------------------------------------------------
   ar_board[cardnum].board_mapped = 2;
   ar_board[cardnum].ar_inited = 1;
   ar_base = ar_set_cpage(cardnum);    // Go to control page zero.
   // Clear the timer tick counter.  Firmware will load it on the next ar_go().
   ar_base->TickTimer = 0;
   for ( channel = 0; channel < MAX_CHAN; channel++ )
   {
      ar_base->rcvr[channel].head_ptr = 0;
      ar_base->rcvr[channel].tail_ptr = 0;
      ar_base->rcvr[channel].mask_ptr = ARINC_RX_BUFFER_MASK;
      ar_base->rcvr[channel].num_scheduled = 0;

      ar_base->xmtr[channel].head_ptr = 0;
      ar_base->xmtr[channel].tail_ptr = 0;
      ar_base->xmtr[channel].mask_ptr = ARINC_TX_BUFFER_MASK;
      ar_base->xmtr[channel].num_scheduled = 0;
   }
   return ARS_NORMAL;
}

/****************************************************************************
*
*  PROCEDURE - load_i960()
*
*  FUNCTION
*     This procedure loads the i960 firmware to a CEI-220/420 board, given the
*     address of the CEI-220/420 board to be loaded.
*
*  PARAMETERS
*     BT_UINT  cardnum -  (input) board number of interest.
*
*  RETURNS
*     0 -> success
*     n -> errors detected
*
****************************************************************************/

static int load_i960(BT_UINT cardnum)
{
   unsigned short i;                // Loop index.
   unsigned int   bytes_written;    // Page byte wrap counter.
   unsigned int   current_page;     // Page counter.
   unsigned int   isError;          // Verification error counter.
   unsigned short mem_value;        // Value read back from memory.
   volatile unsigned short *board_ptr;     // Pointer to the base address of the board.
   volatile struct CONTROL_DPRAM *ar_base; // Current board pointer.

   //--------------------------------------------------------------------
   //  Perform a self-test of 64 Kbytes of Dual-Port memory, leaving    +
   //   it set to all zeros when we are complete.  Write first pattern  +
   //   which consists of writing the word offset to each word...       +
   //--------------------------------------------------------------------
   board_ptr = (volatile unsigned short *)ar_static_base[cardnum];
   bytes_written = 0;      // Start writing bytes at the board beginning,
   current_page =  0;      //  which is page zero.
   for ( i = 0; i <= 32767; i++ )
   {
      //  Update the RAM Page Register if needed.
      if ( (bytes_written & 0x07FF) == 0 )
      {
         board_ptr[RPR] = (unsigned short)current_page;
         current_page++;
      }
      board_ptr[i & 0x3FF] = (unsigned short)i;
      bytes_written += 2;        // We have written 2 bytes to the board.
   }
   //--------------------------------------------------------------------
   //  Read back the first pattern, and write the second pattern (0).   +
   //--------------------------------------------------------------------
   bytes_written = 0;      // Start reading bytes at the board beginning,
   current_page =  0;      //  which is page zero.
   isError = 0;
   for ( i = 0; i <= 32767; i++ )
   {
      //  Update the RAM Page Register if needed.
      if ( (bytes_written & 0x07FF) == 0 )
      {
         board_ptr[RPR] = (unsigned short)current_page;
         current_page++;
      }
      mem_value = board_ptr[i & 0x3FF];
      if ( mem_value != i )
      {
         sprintf(last_error,"CEI-220/420 Dual-port memory error1 at %4.4X page %X,"
                 " is = %4.4X should = %4.4X",
                 bytes_written, current_page-1, mem_value, i);
         isError++;
         if ( isError > 255 )
            break;            // Give it up if there is no board there...
      }
      board_ptr[i & 0x3FF] = 0;
      bytes_written += 2;     // We have written 2 bytes to the board.
   }
   if ( isError )
      return ARS_MEMWRERR;   // Error testing Dual-Port memory

   //--------------------------------------------------------------------
   //  Read back the second pattern which should be all zeros.          +
   //--------------------------------------------------------------------
   bytes_written = 0;      // Start reading bytes at the board beginning,
   current_page =  0;      //  which is page zero.
   for ( i = 0; i <= 32767; i++ )
   {
      //  Update the RAM Page Register if needed.
      if ( (bytes_written & 0x07FF) == 0 )
      {
         board_ptr[RPR] = (unsigned short)current_page;
         current_page++;
      }
      if ( (mem_value = board_ptr[i & 0x3FF]) != 0x0000 )
      {
         sprintf(last_error,"CEI-220/420 Dual-port memory error2 at %4.4X page %X,"
                 " is = %4.4X should = %4.4X",
                 bytes_written, current_page-1, mem_value, 0); // 2/14/2000.ajh
         isError++;
         if ( isError > 255 )
            break;            // Give it up if there is no board there...
      }
      bytes_written += 2;     // We have written 2 bytes to the board.
   }
   if ( isError )
      return ARS_MEMWRERR;   // Error testing Dual-Port memory

   //--------------------------------------------------------------------
   //  Load the data from the micro code array into the board,          +
   //   starting at offset 0xF000 past the beginning of the board.      +
   //  CEI-220/420 board...                                             +
   //--------------------------------------------------------------------
   bytes_written = 0;       // Start writing bytes at the code beginning,
   current_page =  0x0000/0x800;      // which is page 0x0000/0x800 = 00.
   for ( i = 0; i < sizeof(i960_data)/2; i++ )
   {
      //  Update the RAM Page Register if needed.
      if ( (bytes_written & 0x07FF) == 0 )
      {
         board_ptr[RPR] = (unsigned short)current_page;
         current_page++;
      }

      //  Output the current word to the board.
      board_ptr[i & 0x3FF] = i960_data[i];
      bytes_written += 2;     // We have written 2 bytes to the board.
   }
   //--------------------------------------------------------------------
   // Now read back the ucode from dual port memory and verify it.      +
   //--------------------------------------------------------------------
   bytes_written = 0;      // Start writing bytes at the code beginning,
   current_page =  0x0000/0x800;      // which is page 0x0000/0x800 = 00.
   for ( i = 0; i < sizeof(i960_data)/2; i++ )
   {
      //  Update the RAM Page Register if needed.
      if ( (bytes_written & 0x07FF) == 0 )
      {
         board_ptr[RPR] = (unsigned short)current_page;
         current_page++;
      }

      //  Read back the current word from the board.
      if ( (mem_value = board_ptr[i & 0x3FF]) != i960_data[i] )
      {
         sprintf(last_error,"Dual-port firmware error at %4.4X page %X,"
                 " is = %4.4X should be = %4.4X",
                 bytes_written, current_page-1, mem_value, i960_data[i]);
         isError++;
      }
      bytes_written += 2;     // We have read 2 bytes from the board.
      if ( isError > 255 )
         break;            // Give it up if there is no board there...
   }
   if ( isError )
      return ARS_MEMWRERR;   // Error testing Dual-Port memory

   //------------------------------------------------------------------------*
   //  Clear the entire control page.
   //------------------------------------------------------------------------*
   ar_base = ar_set_cpage(cardnum);             // Go to control page.
   memset((void *)ar_base, 0x00, 2048);

   //--------------------------------------------------------------------
   // Initialize the remainder of dual port memory.                     +
   //--------------------------------------------------------------------
   ar_init_dual_port((short)cardnum);

   //--------------------------------------------------------------------
   // Return done.                                                      +
   //--------------------------------------------------------------------
   if ( isError )
   {
      return ARS_BADLOAD;        // Could not successfully load firmware.
   }
   return 0;
}

/****************************************************************************
*
*  PROCEDURE - load_fpga()
*
*  FUNCTION
*     This procedure loads the Xilinx bit file to a CEI220/420 board.
*     This is a environment-independent program which takes as arguements the
*     address of the CEI-220/420 board and the name of the file to be loaded.
*     The contents of the specified file are loaded to the Xilinx chip on
*     the CEI-220/420 board.
*
*  PARAMETERS
*     unsigned short *board_ptr  - pointer to the base of the board.
*     unsigned char *fpga_data   - pointer to the FPGA data to be loaded
*     unsigned long  fpga_length - number of bytes of FPGA data to load
*
*  RETURNS
*     0 -> success
*     1 -> error detected
*
****************************************************************************/
static int load_fpga(volatile unsigned short *board_ptr, unsigned char FFAR *fpga_data,
                     unsigned long fpga_length)
{
   unsigned int    i;              /* Loop Index */
   unsigned char   data;           /* FPGA Configuration Data */
   unsigned int    bytecount;      /* Count of bytes we have downloaded */

   if ( !fpga_data[0] ) {
      sprintf(last_error,"Developer commented out the wrong FPGA file.");
      return ARS_BAD_FPGA;
   }
   if ( fpga_length < 5000 ) {
      sprintf(last_error,"Current FPGA configs do not support this board.");
      return ARS_BAD_FPGA;
   }

   // Remember that the .h file contains one extra byte...
   for ( bytecount = 0; bytecount < fpga_length; bytecount++ )
   {
      data = fpga_data[bytecount];
      for ( i = 0; i < 8; i++ )
      {  // Load all eight bits - msb first for bit file
         board_ptr[CONFIG_REG] = data;
         data <<= 1;
      }
   }
   return 0;
}

/*===========================================================================*
 * ENTRY POINT:                  W a i t F o r S t a r t
 *===========================================================================*
 *
 * FUNCTION:    Wait for a CEI-220/420/420A board's i960 to start.
 *
 * RETURN VAL:  0 -> success
 *              n -> errors detected
 *
 * DESCRIPTION: The i960 handshake startup sequence is verified.
 *
 *===========================================================================*/

static unsigned short WaitForStart(
   BT_UINT cardnum)               // (i) The board number of interest
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int    i;

   //--------------------------------------------------------------------
   //  Check the command location in dual-port and see if the i960 has  +
   //   changed it.  If so, it is running...                            +
   //--------------------------------------------------------------------

   ar_base = ar_set_cpage(cardnum);
   if ( ar_base->command == 0xfacebabeL )
   {
      sprintf(last_error,"i960 slave processor failed to start on ");
      strcat(last_error, ar_get_boardname((short)cardnum, NULL));
      return ARS_BRDNOTLOAD;
   }

   ar_base->command = 1;     // Release i960 to continue startup sequence.

   // Use the ISA bus access time as a timeout (polling delay).  The speed of
   //  the ISA/PC104 bus is not likely to change much anytime soon.
   for ( i = 0; i < 32000; i++ )// 100 fails, 150 passes on a Pentium 3 450 MHz
   {
      if ( ar_base->command == 0x0000 )  // Wait for i960 to enter main processing loop
         return 0;                          // Return success
      msleep(1);
   }
   sprintf(last_error,"i960 failed to complete startup self-test on ");
   strcat(last_error, ar_get_boardname((short)cardnum, NULL));
   return ARS_BRDNOTLOAD;
}

/*===========================================================================*
 * ENTRY POINT:                  L O A D E R
 *===========================================================================*
 *
 * FUNCTION:    This procedure loads both the Xilinx bit file and the
 *              i960 firmware to a CEI-220/420/420A board.
 *
 * RETURN VAL:  0 -> success
 *              n -> errors detected
 *
 * DESCRIPTION: First the board is placed into the native CEI-220/420 memory map
 *              mode, then the board is reset, the i960 is loaded and started,
 *              then the FPGA is loaded.
 *
 *===========================================================================*/

static int loader(
   unsigned int  cardnum,         // (i) The board number of interest
   unsigned long EnableTestMode0, // (i) Enable special factory test mode flag
   unsigned long EnableTestMode1) // (i) Enable special factory test mode flag
{
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.
   int            i;                 // Loop counter.
   int            status;            // Status from loader().
   int            nXchan;            // Number of xmtrs
   int            nRchan;            // Number of rcvrs
   volatile unsigned short *board_ptr;

   static unsigned short DAC_220[] = {
   // DAC    0 1     2 3     4 5     6 7
          0x7272, 0x7272, 0x09ff, 0x40c0,
   // DAC    8 9     a b     c d     e f
          0x0000, 0x0000, 0x0000, 0x0000};

/*    // DAC   1     2     3     4     5     6     7     8 */
/*           0x72, 0x72, 0x72, 0x72, 0x09, 0xff, 0x40, 0xc0, */
/*    // DAC   9    10    11    12    13    14    15    16 */
/*           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; */

   board_ptr = (unsigned short *)ar_static_base[cardnum];

   //----------------------------------------------------------------------
   //  Put the CEI220 board into native mode so the special               +
   //   registers may be accessed by this host.  This is the mode         +
   //   in which we will remain for the duration of the program.          +
   //  Use function calls to avoid complier optimization problems.        +
   //----------------------------------------------------------------------
   read_from_board_short(board_ptr, 0x00/2);
   read_from_board_short(board_ptr, 0x0e/2);
   read_from_board_short(board_ptr, 0x02/2);
   read_from_board_short(board_ptr, 0x0c/2);
   read_from_board_short(board_ptr, 0x04/2);
   read_from_board_short(board_ptr, 0x0a/2);
   read_from_board_short(board_ptr, 0x06/2);
   read_from_board_short(board_ptr, 0x08/2);
   read_from_board_short(board_ptr, 0x00/2);

   //------------------------------------------------------------------------
   //  Stop and reset the i960 microcontroller, and clear the Xilinx.       +                     +
   //------------------------------------------------------------------------
   // Clear the microcontroller run bit and reset the FPGA
   board_ptr[RESET_REG] = 0x0000;
   board_ptr[RESET_REG] = 0x0002;      // Xilinx PROGRAM pin high (enable programming).

   //------------------------------------------------------------------------
   //  Test then load dual port memory with the i960 firmware.              +
   //------------------------------------------------------------------------
   status = load_i960(cardnum);
   if ( status )
      return status;  // Error return code from loader().

   //------------------------------------------------------------------------
   // Load the special test mode flags into DP before starting the i960.    +
   //------------------------------------------------------------------------
   ar_base = ar_set_cpage(cardnum);
   ar_base->TestModeFlags[0] = EnableTestMode0;
   ar_base->TestModeFlags[1] = EnableTestMode1;
   ar_base->TestModeFlags[2] = 0;     // Reserved
   ar_base->TestModeFlags[3] = 0;     // Reserved

   //------------------------------------------------------------------------
   // Take the i960 microcontroller out of reset.                           +
   // Set the Xilinx PROGRAM pin high so we can program it.                 +
   //------------------------------------------------------------------------
   ar_base->command  = 0xfacebabeL; // Processor has not started running.
   ar_base->channel     = 0x12345678L;
   board_ptr[RESET_REG] = 0xFF03;      // i960 Run bit, Xilinx PROGRAM pin.

   //------------------------------------------------------------------------
   // Delay for 5 milliseconds to allow the FPGA configuration              +
   //  memory to clear, and the i960 to complete its startup code.          +
   // Use the ISA bus accesses as a timer, since it's speed is not likely   +
   //  to change anytime soon.                                              +
   //------------------------------------------------------------------------
/*    for ( i = 0; i != 32000; i++ )  // 50 fails, 100 passes on a 450 MHz Pentium 3 */
/*    { */
/*       read_from_board_long(&ar_base->command, 0);   // Polling delay/time out */
/*       read_from_board_long(&ar_base->command, 1);   // Polling delay/time out */
/*    } */
   msleep(5);

   ar_board[cardnum].board_type = ar_get_boardtype((unsigned short)cardnum);
   nRchan = ar_num_rchans((unsigned short)cardnum);      // Number of rcvrs
   nXchan = ar_num_xchans((unsigned short)cardnum);      // Number of xmtrs
   if ( (nRchan + nXchan) == 0 )
      return ARS_BAD_FPGA;    // Current FPGA configs do not support this board.

   // Choose the FPGA load this board needs and load it.
   if ( ar_board[cardnum].board_type == CEI_220 )   // CEI-220 429 configurations
   {
      if ( (nRchan <= rec_xmt_config[0][0]) && (nXchan <= rec_xmt_config[0][1]) )
         status = load_fpga(board_ptr, fpga_220_AA, sizeof(fpga_220_AA));
      else if ( (nRchan <= rec_xmt_config[1][0]) && (nXchan <= rec_xmt_config[1][1]) )
         status = load_fpga(board_ptr, fpga_220_8C, sizeof(fpga_220_8C));
      else if ( (nRchan <= rec_xmt_config[2][0]) && (nXchan <= rec_xmt_config[2][1]) )
         status = load_fpga(board_ptr, fpga_220_C6, sizeof(fpga_220_C6));
      else if ( (nRchan <= rec_xmt_config[3][0]) && (nXchan <= rec_xmt_config[3][1]) )
         status = load_fpga(board_ptr, fpga_220_CC, sizeof(fpga_220_CC));
      else
         return ARS_BAD_FPGA; // Current FPGA configs do not support this board.
   }
   else if ( ar_board[cardnum].board_type == (CEI_220 | IS_6WIRE) )
   {
      if ( (nRchan > 5) || (nXchan > 5) )
         return ARS_BAD_FPGA; // Current FPGA configs do not support this board.
      status = load_fpga(board_ptr, fpga_220_6wir, sizeof(fpga_220_6wir));
   }
   else if ( (ar_board[cardnum].board_type == CEI_420) ||     // Standard 420 or
             (ar_board[cardnum].board_type == CEI_420A_12) )  //  12 MHz 420A
   {
      status = load_fpga(board_ptr, fpga_420, sizeof(fpga_420));
   }
   else if ( (ar_board[cardnum].board_type == (CEI_420 | IS_717)) || // CEI-420-70J or -420-xxJ
             (ar_board[cardnum].board_type == CEI_420_70J)         ) // 12 MHz
   {
      status = load_fpga(board_ptr, fpga_420_717, sizeof(fpga_420_717));
   }
   else if ( ar_board[cardnum].board_type == CEI_420A )  //  16 MHz 420A
   {
      status = load_fpga(board_ptr, fpga_420A, sizeof(fpga_420A));
   }
   else if ( ar_board[cardnum].board_type == (CEI_420A | IS_717) ) // CEI-420A-xxJ (16 MHz)
   {
      status = load_fpga(board_ptr, fpga_420A_717, sizeof(fpga_420A_717));
   }
   else
      return ARS_BAD_FPGA;    // Current FPGA configs do not support this board.

   // If there was an error loading the FPGA config, return
   if ( status )
      return status;
      
   //--------------------------------------------------------------------
   //  Load the default DAC values into DP memory for the CEI-220.      +
   //--------------------------------------------------------------------
   for ( i = 0; i < 8; i++ )
      ar_base->DAC_values[i]  = DAC_220[i];

   //--------------------------------------------------------------------
   // Float the discrete outputs
   //--------------------------------------------------------------------
   ar_base->discrete_out = 0xffff;
  
   //--------------------------------------------------------------------
   // Set the initial discrete output value (if requested)
   //--------------------------------------------------------------------
   if (use_init_discrete_override == TRUE)
      ar_base->discrete_out = (unsigned short)init_discrete_override;
      
   //--------------------------------------------------------------------
   // Wait for the i960 to complete self test and startup initialization.
   //--------------------------------------------------------------------
   return WaitForStart(cardnum);
}

/*===========================================================================*
 * ENTRY POINT:          A R _ D U M P _ D P
 *===========================================================================*
 *
 * FUNCTION:    Dump the contents of ARINC dual-port RAM to a specified file.
 *
 * PARAMETERS:  int cardnum -- (input) The number of the board to dump
 *
 *              char * file_name -- (input) Name of the output file to create.
 *
 * RETURN VAL:  short -- ARS_NORMAL    Success.
 *                    -- ARS_INVBOARD  The board number was out of range.
 *                    -- ARS_BADLOAD   The memory test failed and the board was
 *                                     not loaded.
 *                    -- ARS_BAD_FPGA  Bad number of transmitters or receivers,
 *                                     no FPGA support for this config.
 *
 * DESCRIPTION: This routine loads the Slave Control Program into dual-port 
 *              RAM.  (The i960 runs it's firmware out of dual-port RAM).
 *              This must be the first utility subroutine executed.  
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_dump_dp(short cardnum, char * file_name, char * msg)
{
   struct CONTROL_DPRAM volatile * ar_base;
   struct BUFFER_DPRAM volatile * ar_buf;
   int    i, j, k;               // Loop indexes
   int    chan;                  // Channel counter
   char   api_version[100];      // Version of the API being used

   ar_version(api_version);
   KLOG_DEBUG("API Version = %s\n", api_version);

   KLOG_DEBUG("Channel numbers are (1) based!\n");

   // Make sure we were able to initialize the board.
   ar_base = ar_get_base(cardnum, 2);    // Pointer to control page of Dual Port
   if ( ar_base == NULL )
   {
      KLOG_DEBUG("The board was not opened successfully, dump aborted\n");
      return ARS_BRDNOTLOAD;
   }

   vbtAcquireFrame(cardnum);
   ar_base = ar_get_base(cardnum, 2);    // Pointer to control page of Dual Port
   // Dump the control page values to the file.
   KLOG_DEBUG("Board Type = %4.4X\n", ar_board[cardnum].board_type);
   KLOG_DEBUG("%s\n", ar_get_boardname(cardnum, NULL));  // V3.13.ajh
   KLOG_DEBUG("Message=\'%s\'\nLast Error = \'%s\'\nDAC values  = ",
           msg, last_error);
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%2.2X ", ar_base->DAC_values[i]);
   KLOG_DEBUG("\nConfig Regs = ");
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%2.2X ", ar_base->Config_Regs[i]);

   KLOG_DEBUG("\n\n Transmitters = %d, Receivers = %d, Parametrics = %d",
           ar_base->numTxRx>>8, ar_base->numTxRx&0xff, ar_base->isParaCEI>>8);
   KLOG_DEBUG("\n Receiver Implemented (1-8):    ");
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%X ", ar_base->RxImplemented[i]);
   KLOG_DEBUG(  "\n Transmitter Implemented (1-8): ");
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%X ", ar_base->TxImplemented[i]);

   KLOG_DEBUG("\n\nARINC Receiver Configuration Registers (1-16):\n   ");
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%8.8X ", ar_base->arinc_config_rcv[i]);
   KLOG_DEBUG("\n   ");
   for ( i = 8; i < 16; i++ )
      KLOG_DEBUG("%8.8X ", ar_base->arinc_config_rcv[i]);

   KLOG_DEBUG("\n\nARINC Transmitter Configuration Registers (1-16):\n   ");
   for ( i = 0; i < 8; i++ )
      KLOG_DEBUG("%8.8X ", ar_base->arinc_config_xmt[i]);
   KLOG_DEBUG("\n   ");
   for ( i = 8; i < 16; i++ )
      KLOG_DEBUG("%8.8X ", ar_base->arinc_config_xmt[i]);

   KLOG_DEBUG("\n\n Receiver mode definitions (1-16):   ");
   for ( i = 0; i < 16; i++ )
      KLOG_DEBUG("%X ", ar_base->rcvr_mode_shadow[i]);

   KLOG_DEBUG(  "\n Transmitter mode (API only) (1-16): ");
   for ( i = 0; i < 16; i++ )
      KLOG_DEBUG("%X ", ar_base->xmtr_mode_shadow[i]);

   for ( i = 0; i < 16; i++ )
      KLOG_DEBUG("\nCh %02d: Rcv-M/H/T/#=%4.4X/%4.4X/%4.4X/%4.4lX, "
                        "Xmt-M/H/T/#=%4.4X/%4.4X/%4.4X/%4.4lX, nSch=%4.4X",
              i+1, ar_base->rcvr[i].mask_ptr, ar_base->rcvr[i].head_ptr,
                   ar_base->rcvr[i].tail_ptr, ar_base->rcvr_rx_count[i],
                   ar_base->xmtr[i].mask_ptr, ar_base->xmtr[i].head_ptr,
                   ar_base->xmtr[i].tail_ptr, ar_base->xmtr_tx_count[i],
                   ar_base->xmtr[i].num_scheduled);
   KLOG_DEBUG("\nDiscrete Inputs = %X, Outputs = %X\n",
           ar_base->discrete_in, ar_base->discrete_out);
   KLOG_DEBUG("Tick Timer = %lX IsCEI_520 Flag = %d\n",
          ar_base->TickTimer, ar_base->isParaCEI&0xff);

   // Now communicate with the i960 and see if it is alive. Send invalid cmd
   //  0x001 with parameter1 = 0 to channel 0.
   i = ar_channel_cmd(cardnum, 0x01, 0, 1);
   if ( i == ARS_NORMAL )
      KLOG_DEBUG("i960 seems to be running...\n");
   else
      KLOG_DEBUG("I960 cmd returned code %d; i960 appears dead\n", i);

   // Now dump the transmit data areas of the board to the output file.
   for ( chan = 0; chan < MAX_XMTRS; chan++ )
   {
      ar_buf = ar_set_xpage(cardnum, chan, 0); // Pointer to transmitter data page
      for ( i = 0; i < 512; i += 8 )
      {
         for ( j = 0; j < 8; j++ )
         {
            if ( ar_buf->buf[i+j] )
            {
               KLOG_DEBUG("\nXmt %2d %3.3X:", chan+1, i);
               for ( k = 0; k < 8; k++ )
                  KLOG_DEBUG(" %8.8lX",ar_buf->buf[i+k]);
               break;
            }
         }
      }
   }

   // Now dump the receive data areas of the board to the output file.
   for ( chan = 0; chan < 12; chan++ )
   {
      ar_buf = ar_set_rpage(cardnum, chan, 0); // Pointer to receiver data page
      for ( i = 0; i < 512; i += 8 )
      {
         for ( j = 0; j < 8; j++ )
         {
            if ( ar_buf->buf[i+j] )
            {
               KLOG_DEBUG("\nRcv %2d %3.3X:", chan+1, i);
               for ( k = 0; k < 8; k++ )
                   KLOG_DEBUG(" %8.8lX", ar_buf->buf[i+k]);
               break;
            }
         }
      }
   }
   vbtReleaseFrame(cardnum);
   return ARS_NORMAL;
}

/*===========================================================================*
 * ENTRY POINT:        R E A D _ F R O M _ B O A R D _ S H O R T
 *===========================================================================*
 *
 * FUNCTION:    This procedure reads a short integer from the baord.  It's
 *              used prevents the compiler from optimizing "unused" code away.
 *
 * PARAMETERS:  unsigned short *board_ptr - Base address.
 *              int             offset    - Word Offset to load.
 *
 * RETURN VAL:  Value read from board (often ignored, but not always)
 *
 *===========================================================================*/

static unsigned short read_from_board_short(unsigned short volatile *board_ptr,
                                            int offset)
{
   return board_ptr[offset];
}

/*===========================================================================*
 * ENTRY POINT:        R E A D _ F R O M _ B O A R D _ L O N G
 *===========================================================================*
 *
 * FUNCTION:    This procedure reads a long integer from the board.  It's use
 *              prevents the compiler from optimizing "unused" code away.
 *
 * PARAMETERS:  unsigned short *board_ptr - Base address.
 *              int             offset    - DWord Offset to load.
 *
 * RETURN VAL:  Value read from board (ususally ignored)
 *
 *===========================================================================*/

static unsigned long read_from_board_long(unsigned long volatile *board_ptr,
                                          int offset)
{
   return board_ptr[offset];
}

/*===========================================================================*
 * ENTRY POINT:              A R _ S E T C H P A R M S
 *===========================================================================*
 *
 * FUNCTION:    Define the operating parameters and modes for a 573/717-type
 *              receiver and transmitter.  This is the preferred method for
 *              initializing the 573/717 interface, ar_set_control() is the
 *              old method which will be phased out.
 *
 * RETURN VAL:  -- ARS_INVBOARD      Board number out of range
 *                 ARS_BRDNOTLOAD    ar loadslv() has not been called
 *                 ARS_INVARG        channel number out of range
 *                 ARS_NO_HW_SUPRT   channel is not a 573/717 channel
 *                 ARS_CHAN_TIMEOUT  timeout waiting for response from i960
 *                 ARS_NORMAL        command completed without error
 *
 * DESCRIPTION: This function is used to setup the ARINC-573/717 transmitter or
 *              receiver on a CEI-x20 board.
 *
 *===========================================================================*/
EXPORT32 int DLL_EXPORTED ar_setchparms(
   unsigned int cardnum,    // (i) The board number of interest
   unsigned int channel,    // (i) The channel to which to set the data (0-based)
   int          TransRcv,   // (i) Set parameters for ARU_TRANSMITTER or ARU_RECEIVER
   pAR_CHANNEL_PARMS def)   // (i) Pointer to channel parameter structure
{
#define A717_RECV_SYNC_1 0x110 /* Set the first CEI-420 receive sync word  */
#define A717_RECV_SYNC_2 0x114 /* Set the second CEI-420 receive sync word */
#define A717_RECV_SYNC_3 0x118 /* Set the third CEI-420 receive sync word  */
#define A717_RECV_SYNC_4 0x11C /* Set the fourth CEI-420 receive sync word */
   struct CONTROL_DPRAM volatile *ar_base; // Current board pointer.


   int          BaudRateIndex;        // Index into the baud rate table
   unsigned long ConfigRegValue;      // Value we build for the fpga config reg

   // validate the board number and channel arguments
   short status = check_dev_and_chan_args(cardnum,channel);
   if (status != ARS_NORMAL)
      return status;

   // This configuration does not support interrupts
   if ( def->IntCount )
      return ARS_NO_HW_SUPRT;

   //------------------------------------------------------------------------
   //  Determine the channel type and dispatch to the correct code.         +
   //------------------------------------------------------------------------
   if ( TransRcv == ARU_TRANSMITTER )
   {
      if ( def->ChannelType == CHAN_ARINC717 )
         goto Setup717Channel;
      if ( def->ChannelType == CHAN_ARINC429 )
         goto Setup429Transmitter;
      if ( def->ChannelType == CHAN_CSDB )
         goto SetupCSDBTransmitter;
   }
   else
   {
      if ( def->ChannelType == CHAN_ARINC717 )
         goto Setup717Channel;
      if ( def->ChannelType == CHAN_ARINC429 )
         goto Setup429Receiver;
      if ( def->ChannelType == CHAN_CSDB )
         goto SetupCSDBReceiver;
   }
   return ARS_NO_HW_SUPRT;

   //------------------------------------------------------------------------
   //  Determine the baud rate and init the FPGA Configuration Register     +
   //  for a 573/717 channel.                                               +
   //------------------------------------------------------------------------
Setup717Channel:
   for ( BaudRateIndex = 0; BaudRateIndex < 8; BaudRateIndex++ )
   {
      if ( def->BaudRate == baud_cfg_bits_717[BaudRateIndex] )
         break;
   }
   if ( BaudRateIndex >= 8 )
      return ARS_NO_HW_SUPRT;

   // We have the baud rate/subframe size configuration register value.
   ConfigRegValue = baud_cfg_bits_717[BaudRateIndex];

   // Dispatch to setup either the transmitter or the receiver,
   //  but not both in one call.
   if ( TransRcv )
      goto Setup717Transmitter;

   //------------------------------------------------------------------------
   //  Setup the ARINC-573/717 receiver                                     +
   //------------------------------------------------------------------------
   // Save sync word one.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);              // Go to control page zero.
   ar_base->parameter2 = A717_RECV_SYNC_1/4;  // Index for storing sync word.
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CREG, def->Sync1, 1);

   // Save sync word two.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);              // Go to control page zero.
   ar_base->parameter2 = A717_RECV_SYNC_2/4;  // Index for storing sync word.
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CREG, def->Sync2, 1);

   // Save sync word three.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);              // Go to control page zero.
   ar_base->parameter2 = A717_RECV_SYNC_3/4;  // Index for storing sync word.
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CREG, def->Sync3, 1);

   // Save sync word four.
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);              // Go to control page zero.
   ar_base->parameter2 = A717_RECV_SYNC_4/4;  // Index for storing sync word.
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CREG, def->Sync4, 1);

   //------------------------------------------------------------------------
   // Verify and setup the -717 receiver wrap mode setting:
   //------------------------------------------------------------------------
   if ( def->InternalWrap == AR_WRAP_OFF )
   {
   }
   else if ( def->InternalWrap == AR_WRAP_ON )
      ConfigRegValue |= RCVR_WRAP_ENABLE;
   else
      return ARS_INVARG;
      
   //------------------------------------------------------------------------
   // Verify and setup the receiver sync mode, the hardware encoding method
   //------------------------------------------------------------------------
   if ( def->AutoSync == ARU_717_AUTOSYNC )
      ConfigRegValue |= A717_AUTOSYNC;
   else if ( def->AutoSync == A717_RAW )
      ConfigRegValue |= A717_RAW;
   else
      return ARS_INVARG;

   if ( def->HWEncoding == ARU_717_H_BI_PHASE )
      ConfigRegValue |= A717_BI_PHASE;
   else if ( def->HWEncoding == ARU_717_BIPOLAR )
      ConfigRegValue |= A717_BIPOLAR;
   else
      return ARS_NO_HW_SUPRT;

   //------------------------------------------------------------------------
   // Write the value out to the fpga receiver configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_rcv[channel] = ConfigRegValue;  // New rcv control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   //------------------------------------------------------------------------
   //  We do not support FRAME mode.
   //------------------------------------------------------------------------
   def->NumSubFrames = 0;

   //------------------------------------------------------------------------
   //  The receiver mode must be SEQ_BUFFERED or SEQ_MERGED
   //------------------------------------------------------------------------
   if ( def->OperateMode == ARU_BUFFERED )
   {  // Setting BUFFERED mode disables time tags
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
      if ( def->TimeTagMode == ARU_ENABLE_TIMETAG )
         ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_ENABLE_TIMETAG, 1 << channel);
   }
   else  if ( def->OperateMode == ARU_MERGED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else
      return ARS_NO_HW_SUPRT;

   return ARS_NORMAL;

   //------------------------------------------------------------------------
   //  Setup the ARINC-573/717 transmitter                                  +
   //------------------------------------------------------------------------
Setup717Transmitter:
   // Setup the hardware encoding method and Parametric enable
   if ( def->HWEncoding == ARU_717_H_BI_PHASE )
      ConfigRegValue |= A717_BI_PHASE_XMT | 0x0080;
   else if ( def->HWEncoding == ARU_717_BIPOLAR )
      ConfigRegValue |= A717_BIPOLAR_XMT | 0x0080;
   else if ( def->HWEncoding == (ARU_717_H_BI_PHASE | ARU_717_BIPOLAR) ) //V3.26.ajh
      ConfigRegValue |= (A717_BI_PHASE_XMT | A717_BIPOLAR_XMT | 0x0080);
   else if ( def->HWEncoding == 0 )
   {
   }
   else if ( def->HWEncoding == AR_OFF )
   {
   }
   else
      return ARS_NO_HW_SUPRT;

   //------------------------------------------------------------------------
   // Write the value out to the fpga transmitter configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_xmt[channel] = ConfigRegValue;  // New xmt control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   //------------------------------------------------------------------------
   //  Frame mode is not supported.
   //------------------------------------------------------------------------
   def->NumSubFrames = 0;

   //------------------------------------------------------------------------
   //  Determine the transmit storage mode: SEQ_BUFFERED or SEQ_FRAME.
   //  If SEQ_FRAME, there must be at least 1 sub frame of storage available.
   //------------------------------------------------------------------------
   if ( def->OperateMode != ARU_BUFFERED )
      return ARS_NO_HW_SUPRT;
   return ARS_NORMAL;

   //------------------------------------------------------------------------
   //  Initialize the FPGA Configuration Register for a ARINC-429 Receiver. +
   //------------------------------------------------------------------------
Setup429Receiver:
   if ( def->BaudRate == AR_HIGH )
      ConfigRegValue = R_T_HI_SPEED;
   else
      ConfigRegValue = 0;

   if ( (def->Parity != AR_RAW) && (def->Parity != AR_OFF) )
      ConfigRegValue |= R_T_PARITY_EN;

   if ( def->InternalWrap == AR_WRAP_ON )
      ConfigRegValue |= RCVR_WRAP_ENABLE;

   //------------------------------------------------------------------------
   // Write the value out to the fpga receiver configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_rcv[channel] = ConfigRegValue;  // New rcv control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   // Now setup the receiver mode
   if ( def->OperateMode == ARU_BUFFERED )
   {  // Setting BUFFERED mode disables time tags
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
      if ( def->TimeTagMode == ARU_ENABLE_TIMETAG )
         ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_ENABLE_TIMETAG, 1 << channel);
   }
   else  if ( def->OperateMode == ARU_MERGED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else  if ( def->OperateMode == ARU_DEDICATED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else
      return ARS_NO_HW_SUPRT;
   return ARS_NORMAL;

   //------------------------------------------------------------------------
   //  Initialize the FPGA Configuration Register for a ARINC-429 Transmitter+
   //------------------------------------------------------------------------
Setup429Transmitter:
   if ( def->BaudRate == AR_HIGH )
      ConfigRegValue = R_T_HI_SPEED | 0x80;
   else
      ConfigRegValue = 0x80;

   if ( (def->Parity != AR_RAW) && (def->Parity != AR_OFF) )
   {
      ConfigRegValue |= R_T_PARITY_EN;
      if ( def->Parity == AR_EVEN )
         ConfigRegValue |= XMTR_PARITY_EVEN;
   }

   if ( (def->HWEncoding == AR_OFF) || (def->HWEncoding == 0) )
      ConfigRegValue |= XMTR_OUT_DISABLE;

   //------------------------------------------------------------------------
   // Write the value out to the fpga transmitter configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_xmt[channel] = ConfigRegValue;  // New xmt control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   // Now setup the transmitter mode
   if ( def->OperateMode == ARU_BUFFERED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else  if ( def->OperateMode == ARU_SCHEDULED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else
      return ARS_NO_HW_SUPRT;
   return ARS_NORMAL;

   //------------------------------------------------------------------------
   //  Initialize the FPGA Configuration Register for a CSDB Receiver.      +
   //------------------------------------------------------------------------
SetupCSDBReceiver:
   if ( def->BaudRate == AR_HIGH )
      ConfigRegValue = ARU_CSDB_SPEED_50000;
   else if ( def->BaudRate == AR_LOW )
      ConfigRegValue = ARU_CSDB_SPEED_12500;
   else
      ConfigRegValue = def->BaudRate;

   if ( (def->Parity != AR_RAW) && (def->Parity != AR_OFF) )
   {
      ConfigRegValue |= R_T_PARITY_EN;
      if ( def->Parity == AR_EVEN )
         ConfigRegValue |= CSDB_R_EVEN_PARITY;
   }

   if ( def->InternalWrap == AR_WRAP_ON )
      ConfigRegValue |= RCVR_WRAP_ENABLE;

   //------------------------------------------------------------------------
   // Write the value out to the fpga receiver configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_rcv[channel] = ConfigRegValue;  // New rcv control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   // Now setup the receiver mode
   if ( def->OperateMode == ARU_BUFFERED )
   {  // Setting BUFFERED mode disables time tags
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
      if ( def->TimeTagMode == ARU_ENABLE_TIMETAG )
         ar_channel_cmd(cardnum, CHAN_CMD_TTAG_ENABLE, ARU_ENABLE_TIMETAG, 1 << channel);
   }
   else  if ( def->OperateMode == ARU_MERGED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else
      return ARS_NO_HW_SUPRT;
   return ARS_NORMAL;

   //------------------------------------------------------------------------
   //  Initialize the FPGA Configuration Register for a CSDB Transmitter.   +
   //------------------------------------------------------------------------
SetupCSDBTransmitter:
   if ( def->BaudRate == AR_HIGH )
      ConfigRegValue = ARU_CSDB_SPEED_50000 | 0x80;  // Parametrics enabled
   else if ( def->BaudRate == AR_LOW )
      ConfigRegValue = ARU_CSDB_SPEED_12500 | 0x80;
   else
      ConfigRegValue = def->BaudRate | 0x80;

   if ( (def->HWEncoding == AR_OFF) || (def->HWEncoding == 0) )
      ConfigRegValue |= 0x40;       // Disable the transmitter.

   //------------------------------------------------------------------------
   // Write the value out to the fpga transmitter configuration register.
   //------------------------------------------------------------------------
   vbtAcquireFrame(cardnum);
   ar_base = ar_set_cpage(cardnum);             // Go to control page zero.
   ar_base->arinc_config_xmt[channel] = ConfigRegValue;  // New xmt control value
   vbtReleaseFrame(cardnum);
   ar_channel_cmd(cardnum, CHAN_CMD_LOAD_CONFG, 0, 1 << channel);

   // Now setup the transmitter mode
   if ( def->OperateMode == ARU_BUFFERED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else  if ( def->OperateMode == ARU_SCHEDULED )
      ar_channel_cmd(cardnum, CHAN_CMD_R_MODE, def->OperateMode, 1 << channel);
   else
      return ARS_NO_HW_SUPRT;
   return ARS_NORMAL;
}
