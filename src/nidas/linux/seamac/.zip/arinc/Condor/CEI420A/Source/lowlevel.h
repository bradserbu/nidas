/*===========================================================================*
 * FILE:                      L O W L E V E L . H
 *===========================================================================*
 *
 * COPYRIGHT (C) 1998 - 2003 BY
 *      CONDOR ENGINEERING, INC., SANTA BARBARA, CALIFORNIA
 *      ALL RIGHTS RESERVED.
 *
 *      THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY BE USED AND
 *      COPIED ONLY IN ACCORDANCE WITH THE TERMS OF SUCH LICENSE AND WITH
 *      THE INCLUSION OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY
 *      OTHER COPIES THEREOF MAY NOT BE PROVIDED OR OTHERWISE MADE
 *      AVAILABLE TO ANY OTHER PERSON.  NO TITLE TO AND OWNERSHIP OF THE
 *      SOFTWARE IS HEREBY TRANSFERRED.
 *
 *      THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT
 *      NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY CONDOR
 *      ENGINEERING.
 *
 *===========================================================================*
 *
 * FUNCTION:
 *  
 *      Header file for low-level device driver access.
 *
 * DESCRIPTION: 
 *
 *      This file contains platform-independent constants and function 
 *      prototypes that abstract out the low-level software interface.   
 *
 * HISTORY:
 *
 *   Date     By   Vers                        Comments
 * --------  ----  ----  -----------------------------------------------------
 * 12/23/97  ajh   1.00  Created file from busapi.h to support CEI-220 program 
 *                       loader.
 * 01/05/98  ajh   1.01  Added function prototypes to make this a reusable 
 *                       component.
 * 12/30/99  ajh   3.30  Added vbtGetPCIRevision() function.
 * 01/18/00  ajh   4.00  Added support for the ISA-1553.
 * 09/15/00  ajh   4.16  Modified to merge with UNIX/Linux version.
 * 08/23/01  skb   4.20  Added prototypes for vbtGetPCIConfigRegister() and 
 *                       vbtGetPCIDeviceID() to support CEI-820. Added 
 *                       CEI-520/620/820 PCI device id constants.
 * 10/03/01  rhc   4.43  Modify for improved initialization. 
 * 01/07/02  rhc   4.46  Added support for Quad-PMC and Dual Channel IP.
 * 01/14/02  skb   4.50  Modified to merge with 1553 version.
 *
 *===========================================================================*/
#ifndef LOWLEVEL_H
#define LOWLEVEL_H


#ifdef __TURBOC__
#pragma warn -pck       // disable structure pack change warnings
#pragma pack(1)         // align structure elements on 1-byte boundary 
#endif   

#if defined(_LINUX_X86_) || defined(VXW_VME_PPC) || defined(VXW_PCI_PPC) || defined(VXW_PCI_X86) 
#error "These defines belong in target_defines.h and will be removed in the next version"
#ifndef _UNIX_
#define _UNIX_
#define HANDLE int
#endif 
#endif

//---------------------------------------------------------------------------*
// Error return codes from low-level routines
//---------------------------------------------------------------------------*
#define BTD_OK                0      // success
#define BTD_ERR_NOWINRT       50     // low-level driver not loaded/started
#define BTD_ERR_BADREGISTER   51     // low-level parameter mismatch
#define BTD_ERR_BADOPEN       52     // low-level device open failed
#define BTD_UNKNOWN_BUS       53     // bus is not PCI, ISA or VME
#define BTD_BAD_LL_VERSION    54     // invalid low-level driver installed
#define BTD_BAD_INT_EVENT     55     // unable to create interrupt event
#define BTD_ISR_SETUP_ERROR   56     // error setting up the ISR driver
#define BTD_CREATE_ISR_THREAD 57     // error creating the ISR thread

//---------------------------------------------------------------------------*
// CEI-520/620/820 PCI device identifiers
//---------------------------------------------------------------------------*
#define PCI_DEVICE_ID_520     0x520  // CEI-520 PCI device id
#define PCI_DEVICE_ID_620     0x620  // CEI-620 PCI device id
#define PCI_DEVICE_ID_820     0x820  // CEI-820 PCI device id
#define PCI_DEVICE_ID_820TX   0x821  // CEI-820TX PCI device id

//---------------------------------------------------------------------------*
// Low-level mapping constants
//---------------------------------------------------------------------------*
#define MAX_MEMORY            6      // number of supported memory regions 
#define MAX_PORTS             2      // number of supported i/o regions     
typedef enum _BUS_TYPE               // supported bus types
{
    BUS_INTERNAL,                    
    BUS_ISA,                         
    BUS_PCI,                         
    BUS_VME,
    BUS_PCMCIA,
    BUS_OTHER
} BUS_TYPE;          

//---------------------------------------------------------------------------*
// Low-level address mapping structure
//---------------------------------------------------------------------------*
typedef struct _DEVMAP_T {
   int            busType;                    // one of BUS_TYPE
   int            interruptNumber;            // interrupt number
   int            memSections;                // number of memory regions
   int            flagMapToHost[MAX_MEMORY];  // set to map region into host space
   char *         memHostBase[MAX_MEMORY];    // base address of region in host space
   unsigned long  memStartPhy[MAX_MEMORY];    // physical base address of region
   unsigned long  memLengthBytes[MAX_MEMORY]; // length of region in bytes
   int            portSections;               // number of I/O port regions
   unsigned long  portStart[MAX_PORTS];       // i/o address of first byte
   unsigned long  portLength[MAX_PORTS];      // number of bytes in region
   int            llDriverVersion;            // low-level driver version
   int            KernelDriverVersion;        // kernel driver version
   HANDLE         hKernelDriver;              // handle to the kernel driver
   unsigned int   VendorID;                   // vendor ID if PCI card
   unsigned int   DeviceID;                   // device ID if PCI card
} DEVMAP_T, *PDEVMAP_T;

//---------------------------------------------------------------------------*
// VxWorks memory-mapping and IRQ management variables
//---------------------------------------------------------------------------*
#ifdef VXWORKS
   unsigned char irqvalue;
   unsigned int_count[4];
   char *base_addr;
#endif   

//---------------------------------------------------------------------------*
// Functions defined in the source file lowlevel.c 
//---------------------------------------------------------------------------*
int vbtMapBoardAddresses(UINT      device,    // (i) device to open (0 - 9)
                         PDEVMAP_T pMap);     // (o) ptr to rgn mapping struct

void vbtFreeBoardAddresses(PDEVMAP_T pMap);   // (i) ptr to rgn mapping struct

int vbtGetPCIDeviceID(UINT cardnum,           // (i) device to read (0 - 9)
                      DWORD *deviceID);       // (o) receives PCI device id

int vbtMapBoardAddress(DWORD    cardnum,      // (i) BusTools card number
                       DWORD    device,       // (i) WinRT device to open 
                       char     **addr,       // (o) computed host address
                       void    *MemorySize,   // (o) byte size of rgn mapped
                       int      addr_mode);   // (i) for VME boards only.

void vbtFreeBoardAddress(UINT cardnum);       // (i) BusTools card number

int vbtGetPCIConfigRegister(UINT device,      // (i) device to read (0 - 9)
                            UINT offset,      // (i) offset of PCI config reg
                            UINT length,      // (i) bytes to read (1/2/4)
                            UINT *value);     // (o) receives value of the reg

#if defined(__WIN32__)
int vbtHookInterrupt(UINT    cardnum,         // (i) BusTools card number
                     void (_stdcall *fn)(int),// (i) address of user function
                     int iPriority,           // (i) thread priority
                     HANDLE  *phThread,       // (o) receives handle to thread
                     HANDLE  *hIntEvent,      // (o) receives handle to int event
                     UINT  CurrentCardType,   // (i) board type for int setup
                     UINT  CurrentCardSlot,   // (i) carrier slot or board channel being setup
                     UINT  CurrentCarrier);   // (i) type of IP carrier for interrupt setup

#endif   

int vbtGetInterrupt(UINT cardnum);            // (i) BusTools card number
 
void vbtCloseInterrupt(UINT cardnum);         // (i) BusTools card number

//---------------------------------------------------------------------------*
// I/O management functions defined in the source file lowlevel.c
//---------------------------------------------------------------------------*
int   vbtMapIoAddress(DWORD base_address, char **addr);  
void  vbtOutpb_32    (UINT cardnum, long address, char frame);
void  vbtOutpw_32    (UINT cardnum, long address,  WORD frame);
void  vbtOutpd_32    (UINT cardnum, long address, DWORD frame);
DWORD vbtInpd_32     (UINT cardnum, long address);
WORD  vbtInpw_32     (UINT cardnum, long address);
char  vbtInpb_32     (UINT cardnum, long address);
WORD  vbtInpwOutpw_32(UINT cardnum, long address, WORD frame);


#endif   // end ifndef LOWLEVEL_H

