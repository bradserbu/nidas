/*===========================================================================*
 * FILE:                    A P I 2 2 0 . H
 *===========================================================================*
 *
 * COPYRIGHT (C) 1998 - 2003 BY
 *          CONDOR ENGINEERING, INC., SANTA BARBARA, CALIFORNIA
 *          ALL RIGHTS RESERVED.
 *
 *          THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY BE USED AND
 *          COPIED ONLY IN ACCORDANCE WITH THE TERMS OF SUCH LICENSE AND WITH
 *          THE INCLUSION OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY
 *          OTHER COPIES THEREOF MAY NOT BE PROVIDED OR OTHERWISE MADE
 *          AVAILABLE TO ANY OTHER PERSON.  NO TITLE TO AND OWNERSHIP OF THE
 *          SOFTWARE IS HEREBY TRANSFERRED.
 *
 *          THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT
 *          NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY CONDOR
 *          ENGINEERING.
 *
 *===========================================================================*
 *              
 * FUNCTION:     Equates and dual port memory definitions used by CEI-220/420
 *               firmware and ARINC utilities.
 *                
 * DESCRIPTION:  The shared dual-port memory interface structures are declared
 *               herein.  These structures are shared by the host API and the
 *               on-board i960 microprocessor.
 *               Function prototypes appear in utildefs.h.
 * 
 *===========================================================================*/

/* $Revision: 3648 $
   Date        Revision
  ----------   ---------------------------------------------------------------
  01/04/1998   Initial version for the CEI-220 ARINC board.V0.90.ajh
  03/20/1998   Release version.V1.00.ajh
  04/14/1998   Final changes for Version 1.10 Release.ajh
  05/09/1998   Fixed CHAN_CMD_LOAD_CONFG problem which cleared xmit config
               if board was a "no parametrics" board.V1.20 Release.ajh
  08/13/1998   Added support for the CEI-420 board.V1.30.ajh
  09/08/1998   Final release of CEI-220/420 firmware and API.V1.40.ajh
  01/04/1999   Added Config_Regs[4] to dual port RAM to verify that the
               firmware and the host software read the same values.V1.41.ajh
  04/26/1999   Added support for the CEI-420-717 option.V2.34.ajh
  05/19/1999   Fixed problem returning discretes for board variants.  Added
               critial sections around page/frame register.V2.40.ajh
  07/23/1999   Increased the number of MAX_PERIODIC_MSGS.V2.52.ajh
  11/02/1999   Save the Tick Timer interval in Dual Port RAM as TickResolution.
               Use TickTimer to timeout the API waiting for a label.V2.65.ajh
  12/01/1999   Added support for the CEI-620.V3.00.ajh
  04/13/2000   Added support for the CEI-420A.V3.02.ajh
  05/05/2000   Changed board reporting and added support for CEI-620J.V3.03.ajh
  09/28/2000   Removed support for the CEI-520/620, completed support for the
               CEI-420A 16 MHz.V3.13.ajh
  06/08/2002   Updated to support 32 transmitters and 32 receivers.V3.60.skb
*/

/**********************************************************************
* Version ID definition
**********************************************************************/
#define API_VER "3.90"      /* Release version for the resource file */
#define API_RC_VER 3,9,0,0  /* Release version for the resource file */
#define API_TYPE "Release (05/07/2004)"  /* Release type is BETA or RELEASE       */
#define API_MISC "CEI-220/420/420A/420-70J Version of the API"
#define API_PRODUCTS "CEI-220/420/420A/420-70J (Standard API)"
#define API_FIRMWARE "3.90"

/**********************************************************************
*  Note: When compiling for DOS the label _DOS must be defined.
*        When compiling for 16-bit Windows the label _Windows
*             must be defined.
*        When compiling for 32-bit Windows both _Windows and __WIN32__
*             must be defined.
*        When compiling for a 32-bit environment define the label
*             _IS_32BITS_.
*        When compiling for the i960, the label "i960" must be defined
*             to prevent the PC stuff from being included in the ucode.
**********************************************************************/

#ifndef i960   /* Don't include Windows stuff when building CEI-220 firmware. */

#ifndef CEIX20_BUILD_VXWORKS

#ifndef _UNIX_
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _WINDOWS         /* MSVC defines this label for WINDOWS PM */
#ifndef _Windows
#define _Windows        /* and does NOT define this label.... */
#endif
#endif

// Set common definition for Windows 32 bit environment
// Microsoft uses _WIN32, Borland uses __WIN32__
#ifdef _WIN32       /* MSVC defines this label for 32-bit WINDOWS PM    */
#ifndef __WIN32__
#define __WIN32__   /* and does NOT define this label, but Borland does */
#endif
#endif

#ifdef WIN32        /* MSVC defines this label for 32-bit WINDOWS PM    */
#ifndef __WIN32__
#define __WIN32__   /* and does NOT define this label, but Borland does */
#endif
#endif

#ifdef __WIN32__
#define _IS_32BITS_   /* Environment supports 32-bit addressing */
#endif

/**********************************************************************
*  Create the standard 16-bit WINDOWS typedef's if compiling for DOS.
**********************************************************************/

#if defined(_DOS) || defined(__DOS__)   /* If DOS, generate equivalent Windows-type definitions */

typedef unsigned short  WORD;
typedef unsigned long   DWORD;
typedef unsigned int    UINT;

#define CALLBACK        _far _pascal
#define VOID            void
#define FFAR            _far

typedef char  FAR*      LPSTR;
typedef int   FAR*      LPINT;
typedef WORD  FAR*      LPWORD;
typedef long  FAR*      LPLONG;
typedef DWORD FAR*      LPDWORD;
typedef void  FAR*      LPVOID;

#define FALSE           0
#define TRUE            1

#elif defined(_UNIX_)
#define _IS_32BITS_
#define FFAR
#else
#include <windows.h>
#endif

#ifdef __WIN32__        /* If 32-bit Windows, get rid of 16-bit wreckage  */
#define FFAR

#elif defined _Windows  /* If 16-bit Windows, generate WIN-specific parms */

#define FFAR  _far
#endif

#else   // else ifndef CEIX20_BUILD_VXWORKS

#define FFAR
#define TRUE      1
#define FALSE     0
#define _IS_32BITS_   /* Environment supports 32-bit addressing */

#endif  // end ifndef CEIX20_BUILD_VXWORKS

#endif  // end ifndef i960

/*----------------------------------------------------------------------------*
 *  Dual Port Memory Structure Definition.
 *----------------------------------------------------------------------------*/
// Transmitter and receiver buffer control structure variables.
struct BASE {
   unsigned short mask_ptr;         /* Mask value used to wrap pointers      */
   unsigned short head_ptr;         /* Circular buffer dword head pointer    */
   unsigned short tail_ptr;         /* Circular buffer dword tail pointer    */
   unsigned short num_scheduled;    /* Number of labels for scheduled mode   */
   };

//#define MAX_PERIODIC_MSGS  120    /* Changed to support more msgs 7/23/1999  */

#define MAX_CHAN           12               /* Channels defined for software */
#define MAX_XMTRS    12
#define MAX_RCVRS    12

// One Channel Wide Command Structure for the entire board, followed by
//  buffer control structures and ARINC data buffers.
struct CONTROL_DPRAM {
   // This data is contained in page 2  ...
   unsigned long  command;           /* Channel Wide Command Word             */
   unsigned long  channel;           /* Channel Wide Channel Number           */
   unsigned long  parameter1;        /* Channel Wide Parameter 1              */
   unsigned long  parameter2;        /* Channel Wide Parameter 2              */
   unsigned long  TickTimer;         /* Timer Tick Counter                    */
   unsigned long  TickResolution;    /* Timer Tick Resolution                 */
   unsigned short discrete_in;       /* Current value of the input discretes  */
   unsigned short discrete_out;      /* Current value for the output discretes*/
   unsigned short DAC_values[8];     /* Current values for the DAC outputs    */
   unsigned short Config_Regs[8];    /* Copy of the Config Regs @ 0xC0000000  */
   unsigned short numTxRx;           /* Actual number of supported receivers  */
   unsigned short isParaCEI;         /* Flag set if parametrics supported     */
   struct BASE   rcvr[16];           /* Receiver buffer pointers     0x040 */
   struct BASE   xmtr[16];           /* Transmitter buffer pointers  0x0C0 */
   unsigned long rcvr_rx_count[16];        /* Num labels received    0x140 */
   unsigned long xmtr_tx_count[16];        /* Num labels transmitted 0x180 */
   long  arinc_config_rcv[16];       /* ARINC receive config shadow  0x1C0 */
   long  arinc_config_xmt[16];       /* ARINC transmt config shadow  0x200 */
   short rcvr_mode_shadow[16];       /* Receiver mode shadow by chan 0x240 */
   short xmtr_mode_shadow[16];       /* Transmitter mode shadow      0x280 */

   unsigned short ConfigRegs[8];     /* Copy of the Config Regs @ 0xC0000000  */
   unsigned short RxImplemented[8];  /* Zero if RX chan not implemented   */
   unsigned short TxImplemented[8];  /* Zero if TC chan not implemented   */
                                         /* CHAN_NOT_IMPLEMENTED =            */
                                         /* Channel is not physically present */
                                         /* CHAN_ARINC429 = ARINC 429 channel */
                                         /* CHAN_ARINC717 = AEINC 717 channel */
                                         /* CHAN_CSDB     = CSDB channel.     */
                                     
   unsigned long  TestModeFlags[4];  /* Factory Test mode flags & parameters, */
                                     /*  must be zero for normal operation!   */
   long  alignment[512-11*16-2];     /* Align label storage arrays on 2k bound*/
   long  scratch;                    /* Scratch register used for timing      */

#ifdef ORIGINAL_VENDOR_CODE
   unsigned short align_regs;
   unsigned short regs_m1[1];        /* Word just before the Cntrl Registers  */
   // The transmitter data [MAX_XMTRS] ...
   unsigned long xmtr_data[MAX_XMTRS][512]; /* Transmitter label storage array */
#else
   /* modern gcc issues -Warray-bounds warnings then one tries to access the above
    * regs_m1[] array with an index of the defined values for *_REG below, which
    * are all >= 1.  So we'll create a union here with m1 and xmtr_data, with m1
    * defined large enough to avoid the warnings.
    */
   union {
       struct regs {
           unsigned short align_regs;
           unsigned short m1[9];
       } regs;
       struct xmtr_data {
           unsigned int stuff;
           // The transmitter data [MAX_XMTRS] ...
           unsigned int xmtr_data[MAX_XMTRS][512]; /* Transmitter label storage array */
       } data;
   };
#endif

   // The receiver data [MAX_RCVRS] [12] is just a placeholder...
   // [12] is also the most that will fit in 64K like on the 220/420 boards!
   unsigned int rcvr_data[12][512];  /* Receiver label storage array  */
   };

#if defined(__BORLANDC__) && 1
#if sizeof(struct CONTROL_DPRAM) != 25*512*4
   int i = sizeof(struct CONTROL_DPRAM)
   #error Structure size of dual port RAM is incorrect
#endif
#endif

/* For use when DPRAM is addressed as a receiver or transmitter buffer */
struct BUFFER_DPRAM {
   unsigned long buf[512];
};

/*----------------------------------------------------------------------------*
 *  Control Register Equates.
 *    These are WORD offsets into the regs_m1[] array, and can only be used
 *    when the board is mapped as a CEI-220/420/420A board, and not as a DART2 board.
 *----------------------------------------------------------------------------*/
#define RAM_PAGE_REG 1  /* Offset to the RAM Page Register (R/W)             */
#define INT_CTRL_REG 2  /* Offset to the Interrupt Control Register (WO)     */
#define RST_CTRL_REG 3  /* Offset to the Reset Control Register (R/W)        */
#define FPGA_CFG_REG 4  /* Offset to the FPGA Configuration Register (WO)    */
#define NUM_CHAN_REG 5  /* Offset to the num chans register (Rcv,Xmt) (RO)   */
#define OPTIONS_REG  6  /* Offset to the options (parametrics) register (RO) */
#define CFG_REG_3    7  /* Offset to the Configuration Register #3 (RO)      */
#define CFG_REG_4    8  /* Offset to the Configuration Register #4 (RO)      */


/*----------------------------------------------------------------------------*
 *  CEI-220/420/420A/520 ARINC configuration equates.
 *----------------------------------------------------------------------------*/

#define ARINC_TX_BUFFER_MASK    0x01FF
#define ARINC_RX_BUFFER_MASK    0x01FF
//#define MAX_BOARDS              16       /* V3.05 */

/*---------------------------------------------------------------------------* 
 *      C E I - 2 2 0 / 4 2 0 / 5 2 0 -  C H A N N E L   C O M M A N D S
 *---------------------------------------------------------------------------*/
 
#define CHAN_LOAD_DACS        0x70 /* Load DACS from Dual Port Memory        */
                                   /*  Values 0x071-0x07F reserved....       */
#define CHAN_CMD_GO           0x81 /* Set/clear GO flag                      */
#define CHAN_CMD_INT_ENABLE   0x82 /* Receiver Host Interrupt Enable/Disable */
#define CHAN_CMD_CLR_INT      0x83 /* Host Interrupt Reset                   */

#define CHAN_CMD_TIMER_RATE   0x84 /* Timer Interrupt Rate                   */
#define CHAN_CMD_TTAG_ENABLE  0x85 /* Time-Tag Enable/Disable                */
#define CHAN_CMD_LOAD_CONFG   0x86 /* Load Xmt and Rcv configuration from DP */
#define CHAN_CMD_LOAD_CREG    0x87 /* Load FPGA configuration register       */

#define CHAN_CMD_SDI_READ     0x88 /* SDI Filter Value+Enable, Read by Host  */
#define CHAN_CMD_SDI_VALUE    0x89 /* SDI Filter Value setup                 */
#define CHAN_CMD_SDI_ENABLE   0x8A /* SDI Filter Enable setup                */
#define CHAN_CMD_XMIT_CLR     0x8B /* Return ARINC transmitter empty status  */

#define CHAN_CMD_FLT_ON       0x8C /* Filter Command; Filter On              */
#define CHAN_CMD_FLT_OFF      0x8D /* Filter Command; Filter Off             */
#define CHAN_CMD_FLT_ALL_ON   0x8E /* Filter Command; Filter On ALL labels   */
#define CHAN_CMD_FLT_ALL_OFF  0x8F /* Filter Command; Filter OFF ALL labels  */
#define CHAN_CMD_FLT_GET      0x90 /* Return Filter value for specified label*/

#define CHAN_CMD_R_MODE       0x91 /* Receive Mode Select                    */
#define CHAN_CMD_X_MODE       0x92 /* Transmit Mode Select                   */
#define CHAN_CND_INT_NUM      0x93 /* Receiver interrupts host on this IRQ   */
