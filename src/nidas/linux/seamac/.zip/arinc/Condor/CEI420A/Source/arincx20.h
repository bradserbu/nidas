/*===========================================================================*
 * FILE:                      A R I N C x 2 0 . H
 *===========================================================================*
 *
 * COPYRIGHT (C) 1998 - 2003 BY
 *      CONDOR ENGINEERING, INC., SANTA BARBARA, CALIFORNIA
 *      ALL RIGHTS RESERVED.
 *
 *      THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY BE USED AND
 *      COPIED ONLY IN ACCORDANCE WITH THE TERMS OF SUCH LICENSE AND WITH
 *      THE INCLUSION OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY
 *      OTHER COPIES THEREOF MAY NOT BE PROVIDED OR OTHERWISE MADE
 *      AVAILABLE TO ANY OTHER PERSON.  NO TITLE TO AND OWNERSHIP OF THE
 *      SOFTWARE IS HEREBY TRANSFERRED.
 *
 *      THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT
 *      NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY CONDOR
 *      ENGINEERING.
 *
 *===========================================================================*
 *
 * FUNCTION:
 *
 *      This file contains common hardware and software interface constants  
 *      and structure definitions used to build the CEI-220/420/520/620/820 
 *      and DART2 APIs and firmware. 
 *
 * DESCRIPTION: 
 *  
 *      This file contains constant and structure definitions common across 
 *      both the standard and enhanced CEI-x20 host-side APIs. This file also 
 *      contains the software definitions of the registers and other hardware 
 *      components of the CEI-220/420/520/620/820 boards. These definitions 
 *      include the addresses of the hardware/software interface components 
 *      (supplied as comments). As a general rule, host-side definitions are
 *      listed in the first half of the file and hardware/software interface 
 *      definitions are listed in the second-half of the file. 
 *
 * HISTORY:
 *
 *   Date     By   Vers                        Comments
 * --------  ----  ----  -----------------------------------------------------
 * 11/10/97  ajh   1.00  Initial version for Greenhills i960 C compiler.
 * 04/14/98  ajh   1.10  Final changes for CEI-220 API/firmware.
 * 08/13/98  ajh   1.30  Added support for the CEI-420 board.
 * 09/08/98  ajh   1.40  Final release of CEI-220/420 firmware and API.
 * 02/23/99  ajh   2.22  Added definitions for the CEI-520.
 * 11/26/99  ajh   2.65  Added definitions and changes for the CEI-620.
 * 12/01/99  ajh   3.03  Changed discrete IO regs to be a full 32-bits long.
 * 05/05/00  ajh   3.03  Moved OPTIONS_REG definitions here from utildefs.h.
 * 05/30/00  ajh   3.04  Changed name to ARINCx20.h to reflect the shared 
 *                       nature of this file and the definitions contained 
 *                       herein.
 * 09/28/00  skb   3.40  Added definitions for the CEI-820.
 *
 *===========================================================================*/
#ifndef ARINC_X20_H 
#define ARINC_X20_H

 
//---------------------------------------------------------------------------*
// Configuration item classification codes
//---------------------------------------------------------------------------*
#define ARU_ITEM_RX_CHxx_BIT_RATE      0    // receiver bit rate
#define ARU_ITEM_TX_CHxx_BIT_RATE      1    // transmitter bit rate
#define ARU_ITEM_RX_CHxx_PARITY        2    // receiver parity
#define ARU_ITEM_TX_CHxx_PARITY        3    // transmitter parity
#define ARU_ITEM_RX_CHxx_SDI_FILTER    4    // receiver SDI filter
#define ARU_ITEM_RX_CHxx_SDI_VALUE     5    // receiver SDI value
#define ARU_ITEM_TX_CHxx_SHUT_OFF      6    // transmitter shut off
#define ARU_ITEM_CHxx_SCHEDULED_MODE   7    // scheduled transmit mode
#define ARU_ITEM_CHxx_BURST_MODE       8    // burst transmit mode
#define ARU_ITEM_CHxx_ENABLE_TIMETAG   9    // enable receiver timetag
#define ARU_ITEM_CHxx_DISABLE_TIMETAG  10   // disable receiver timetag
#define ARU_ITEM_CHxx_BUFFERED         11   // buffered receive mode
#define ARU_ITEM_CHxx_DEDICATED        12   // dedicated receive mode
#define ARU_ITEM_CHxx_MERGED           13   // merged receive mode
#define ARU_ITEM_TX_CHxx_HB_INJ        14   // high-bit transmit error inj
#define ARU_ITEM_TX_CHxx_LB_INJ        15   // low-bit transmit error inj
#define ARU_ITEM_TX_CHxx_GAP_INJ       16   // gap transmit error inj
#define ARU_ITEM_DAC_VALUE_xx          17   // hardware DAC volvage
#define ARU_ITEM_OUTPUT_LEVEL_ADJ_xx   18   // output level


//---------------------------------------------------------------------------*
// Miscellaneous CEI-x20 API constants
//---------------------------------------------------------------------------*
#define EXTRACT_LABEL      0x000000FF  // extracts label of ARINC word
#define MAX_BOARDS         16          // maximum boards per system
#define MAX_PERIODIC_MSGS  120         // maximum scheduled messages per chan



//---------------------------------------------------------------------------*
// CEI-x20 hardware OPTIONS_REG bit definitions (these constants define the
//  configuration register 1 contents of all CEI-x20 boards)
//---------------------------------------------------------------------------*
#define PARAMETRICS_OK     0x01        // board supports parametrics if set
#define HW_BOARD_MASK      0xF0        // mask extracts HW board + options
                                       //  if the board type is BOARD_TYPE_EX,
                                       //  then the board type is specified in
                                       //  configuration register 2
#define BOARD_IS_220        0x00       // CEI-220
#define BOARD_IS_420        0x10       // CEI-420
#define BOARD_IS_220_6WIR   0x20       // CEI-220 with ch 5=561 6-wire
#define BOARD_IS_420_717    0x30       // CEI-420-70J with -717 reduced
#define BOARD_IS_420_XXJ    0x40       // CEI-420 with HBP xmit/Holt
#define BOARD_IS_420A_12    0x50       // CEI-420A 12 MHz, 16 in disc
#define BOARD_IS_420A       0x60       // CEI-420A with 16 MHz clock
#define BOARD_IS_420AxxJ    0x70       // CEI-420A xxJ 16 MHz clock
#define BOARD_IS_520        0x80       // CEI-520
#define BOARD_IS_520_717    0x90       // CEI-520 with ARINC-717
#define BOARD_IS_620        0xA0       // CEI-620
#define BOARD_IS_620_717    0xB0       // CEI-620 with ARINC-717
#define BOARD_IS_520_CSDB   0xC0       // CEI-520 with 4 CSDB channels
#define BOARD_IS_820        0xD0       // CEI-820
#define BOARD_IS_820_717    0xE0       // CEI-820 with ARINC-717
#define BOARD_TYPE_EX       0xF0       // board type is in config reg 2
#define BOARD_IS_820_561    0x01       // CEI-820 with 561 (reg 2)
#define BOARD_IS_820TX_32   0x02       // CEI-820TX-32 (reg 2)
#define BOARD_IS_820TX_16   0x03       // CEI-820TX-16 (reg 2)
#define BOARD_IS_520A       0x04       // CEI-520A (reg 2)
#define BOARD_IS_520A_717   0x05       // CEI-520A with ARINC-717 (reg 2)
#define BOARD_IS_520A_CSDB  0x06       // CEI-520A with 4 CSDB channels (reg 2)



//---------------------------------------------------------------------------*
// PLX general purpose i/o registers
//---------------------------------------------------------------------------*
#define PLX_9050_GPIO_REG   20         // gen purp i/o reg for 520/620
#define PLX_9030_GPIO_REG   21         // gen purp i/o reg for 520A/820/820TX


//---------------------------------------------------------------------------*
// ARINC-429 and common FPGA control bits
//---------------------------------------------------------------------------*
#define R_T_HI_SPEED       0x00000001  // enable 429 R/T 100 Kbaud speed
#define R_T_PARITY_EN      0x00000002  // enable 429/CSDB R/T parity

#define XMTR_PARITY_EVEN   0x00000004  // enable xmiter parity, even
#define XMTR_BIT_CNT_LOW   0x00000008  // enable xmiter low bit count error
#define XMTR_BIT_CNT_HI    0x00000010  // enable xmiter hi bit count error
#define XMTR_GAP_ERR_EN    0x00000020  // enable xmiter gap error
#define XMTR_OUT_DISABLE   0x00000040  // disable xmiter output driver
#define XMTR_VOLT_ENABLE   0x00000080  // enable xmiter variable voltage

#define RCVR_WRAP_ENABLE   0x00000004  // enable rcvr-xmtr internal wrap

#define R_T_820_FREQ_MASK  0x0FFF0000  // CEI-820 parametric freq mask
#define R_T_820_HI_SPEED   0x009E0000  // CEI-820 hi speed parametric freq
#define R_T_820_LO_SPEED   0x04FE0000  // CEI-820 lo speed parametric freq
#define R_T_820_561_SPEED  0x05AD0000  // CEI-820 561 parametric freq


//---------------------------------------------------------------------------*
// ARINC 573/717 receiver and transmitter control bits for CEI-x20
//---------------------------------------------------------------------------*
#define A717_SPEED_384       0x000     // rcvr/xmtr subframe = 32 words
#define A717_SPEED_768       0x100     // rcvr/xmtr subframe = 64 words
#define A717_SPEED_1536      0x200     // rcvr/xmtr subframe = 128 words
#define A717_SPEED_3072      0x300     // rcvr/xmtr subframe = 256 words
#define A717_SPEED_6144      0x400     // rcvr/xmtr subframe = 512 words
#define A717_SPEED_12288     0x500     // rcvr/xmtr subframe = 1024 words
#define A717_SPEED_24576     0x600     // rcvr/xmtr subframe = 2048 words
#define A717_SPEED_49152     0x700     // rcvr/xmtr subframe = 4096 words

#define A717_AUTOSYNC        0x0000    // rcvr autosync mode
#define A717_RAW             0x2000    // rcvr RAW mode

#define A717_BI_PHASE        0x0000    // rcvr Harvard Bi-Phase encoding
#define A717_BIPOLAR         0x1000    // rcvr Bipolar Return-to-zero encoding

#define A717_BI_PHASE_XMT    0x2000    // xmtr Harvard Bi-Phase encoding
#define A717_BIPOLAR_XMT     0x1000    // xmtr Bipolar R-T-Z encoding


//---------------------------------------------------------------------------*
// CSDB control bits
//---------------------------------------------------------------------------*
#define CSDB_HI_SPEED      0x00001300  // set 50Kbaud speed CSDB channel
#define CSDB_LO_SPEED      0x00004F00  // set 12.5Kbaud speed CSDB channel
#define CSDB_BAUD_MASK     0x000000FF  // mask for changing CSDB baud rate
#define CSDB_R_EVEN_PARITY 0x00000001  // select even CSDB receiver parity


//---------------------------------------------------------------------------*
// On-board i960 clock speed declarations
//---------------------------------------------------------------------------*
#define PROCESSOR_BUS_SPEED 12000000   // speed is 12MHz (CEI-220/420)
#define PROCESSOR_420_SPEED 16000000   // speed is 16MHz (CEI-420A)
#define PROCESSOR_520_SPEED 33000000   // speed is 33Mhz (CEI-520/620/820)


//---------------------------------------------------------------------------*
// The following section is only used by the i960 processor
//---------------------------------------------------------------------------*
#ifdef i960


//---------------------------------------------------------------------------*
// Define the i960J on-board RAM (this RAM is fast but small)
//---------------------------------------------------------------------------*
#pragma ghs section data=".chipram"


//---------------------------------------------------------------------------*
// Define the static RAM  
//  There is 512 Kbytes of this RAM. Note that the CEI-420 does not support 
//  this static RAM. The dual-port memory is triple-mapped over this region,
//  so CEI-220 firmware can run on a CEI-420 board.
//---------------------------------------------------------------------------*
#pragma ghs section data=".static"


//---------------------------------------------------------------------------*
// Define dual-port RAM (initialize to locate at 0x20000000)
//---------------------------------------------------------------------------*
#pragma ghs section data=".dp"           


//---------------------------------------------------------------------------*
// Define the ARINC FPGA registers
//   These registers control the ARINC receivers and transmitters, the 
//   discrete I/O, and the DAC's for the CEI-520/620/820 board.
//---------------------------------------------------------------------------*
#pragma ghs section data=".fpga"

#ifdef CEIX20_TX32_RX32

struct FPGA_REGISTERS {
   unsigned long arinc_config_rcv[32];      // offset 0x0000
   unsigned long arinc_config_xmt[32];      // offset 0x0080
   unsigned long ARINC_tr_buffer[32];       // offset 0x0100
   unsigned long arinc_rx_int_status_reg;   // offset 0x0180
   unsigned long arinc_tx_int_status_reg;   // offset 0x0184
   unsigned long discrete_io_reg;           // offset 0x0188
   unsigned long dac_control_reg1;          // offset 0x018C
   unsigned long local_bus_bit_reg1;        // offset 0x0190
   unsigned long enable_i960_reg;           // offset 0x0194
   unsigned long cei820_test_reg;           // offset 0x0198
   unsigned long local_bus_bit_reg2;        // offset 0x019C
   unsigned long dac_control_reg2;          // offset 0x01A0
   };

#else

struct FPGA_REGISTERS {
   unsigned long arinc_config_rcv[16];      // offset 0x0000
   unsigned long arinc_config_xmt[16];      // offset 0x0040
   unsigned long ARINC_tr_buffer[16];       // offset 0x0080
   unsigned long spare[16];                 // offset 0x00C0
   unsigned long arinc_int_status_reg;      // offset 0x0100
   unsigned long discrete_io_reg;           // offset 0x0104
   unsigned long dac_control_reg1;          // offset 0x0108
   unsigned long local_bus_bit_reg1;        // offset 0x010C
   unsigned long Sync717[4];                // offset 0x0110
   unsigned long arinc_int_status_reg2;     // offset 0x0120
   unsigned long discrete_io_reg2;          // offset 0x0124
   unsigned long dac_control_reg2;          // offset 0x0128
   unsigned long local_bus_bit_reg2;        // offset 0x012C
   unsigned long filler[21];                // offset 0x0130
   unsigned long cei820_test_reg;           // offset 0x0184
   };

#endif

//---------------------------------------------------------------------------*
// Initialize the FPGA registers to locate them at 0x60000000
//---------------------------------------------------------------------------*
volatile struct FPGA_REGISTERS fpga INIT_V;    


//---------------------------------------------------------------------------*
// Define the CEI-220 DAC output registers
//  Note that the CEI-420 does not have any adjustable thresholds or output 
//  voltages; so no DAC's. The CEI-520/620/820 DAC registers are in the 
//  FPGA_REGISTERS structure.
//---------------------------------------------------------------------------*
#pragma ghs section data=".dacregs"

struct  DAC_REGS {
   int DAC;                       // actual register, uses lower 8 bits only
   int fill[31];                  // filler to locate successive registers    
   };

//---------------------------------------------------------------------------*
// Initialize the DAC output registers to locate them at 0x60000400
//---------------------------------------------------------------------------*
volatile struct DAC_REGS dac_regs[8] INIT_V;   


//---------------------------------------------------------------------------*
// Define the CEI-x20 Interrupt control register.
//---------------------------------------------------------------------------*
#pragma ghs section data=".intreg"

//---------------------------------------------------------------------------*
// Initialize the interrupt control register to locate it at 0x80000000
//---------------------------------------------------------------------------*
volatile int fpga_interrupt_reg INIT_V;        


//---------------------------------------------------------------------------*
// Define the CEI-x20 configuration control registers
//---------------------------------------------------------------------------*
#pragma ghs section data=".config"

struct CONFIG_REGS {
   unsigned char config;
   unsigned char filler[3];
   int fill[3];
   };

//---------------------------------------------------------------------------*
// Initialize the configuration registers to locate them at 0xC0000000
//---------------------------------------------------------------------------*
volatile struct CONFIG_REGS config_regs[16] INIT_V;


//---------------------------------------------------------------------------*
// Define the i960J memory-mapped processor control registers
//---------------------------------------------------------------------------*
#pragma ghs section data=".mmregs"

//---------------------------------------------------------------------------*
// Initialize the processor control registers to locate them at 0xFF000000
//---------------------------------------------------------------------------*
volatile unsigned int i960_mmregs[16384] INIT_V;  


//---------------------------------------------------------------------------*
// User space family registers and tables
//---------------------------------------------------------------------------*
#define TRR0     (0x300/4)        // timer reload register 0
#define TCR0     (0x304/4)        // timer count register 0
#define TMR0     (0x308/4)        // timer mode register 0
#define TRR1     (0x310/4)        // timer reload register 1
#define TCR1     (0x314/4)        // timer count register 1
#define TMR1     (0x318/4)        // timer mode register 1


//---------------------------------------------------------------------------*
// Supervisor space family registers and tables
//---------------------------------------------------------------------------*
#define DLMCON   (0x8100/4)       // default logical memory config reg
#define LMADR0   (0x8108/4)       // logical memory address register 0
#define LMMR0    (0x810C/4)       // logical memory mask register 0
#define LMADR1   (0x8110/4)       // logical memory address register 1
#define LMMR1    (0x8114/4)       // logical memory mask register 1


//---------------------------------------------------------------------------*
// Restore data storage mapping to the default (.data) section
//---------------------------------------------------------------------------*
#pragma ghs section data=default


#endif   // end ifdef i960

#endif   // end ifndef ARINC_X20_H 

