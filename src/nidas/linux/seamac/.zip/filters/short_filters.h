/* -*- mode: C; indent-tabs-mode: nil; c-basic-offset: 8; tab-width: 8; -*- */
/* vim: set shiftwidth=8 softtabstop=8 expandtab: */
/*
 ********************************************************************
 ** NIDAS: NCAR In-situ Data Acquistion Software
 **
 ** 2007, Copyright University Corporation for Atmospheric Research
 **
 ** This program is free software; you can redistribute it and/or modify
 ** it under the terms of the GNU General Public License as published by
 ** the Free Software Foundation; either version 2 of the License, or
 ** (at your option) any later version.
 **
 ** This program is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 ** GNU General Public License for more details.
 **
 ** The LICENSE.txt file accompanying this software contains
 ** a copy of the GNU General Public License. If it is not found,
 ** write to the Free Software Foundation, Inc.,
 ** 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **
 ********************************************************************
*/
/*
									      
  Filters for use in digital sampling.

*/

#ifndef NIDAS_SHORT_FILTERS_H
#define NIDAS_SHORT_FILTERS_H

#include <nidas/linux/types.h>

/**
 * Enumeration of supported filter types.
 */
enum nidas_short_filter {
    NIDAS_FILTER_UNKNOWN,
    NIDAS_FILTER_PICKOFF,
    NIDAS_FILTER_BOXCAR,
};

#ifdef __KERNEL__
/**
 * Form of data sample that the short filters operate on.
 */
typedef struct short_sample
{
    /**
     * timetag of sample. Signed tenths of milliseconds since 00:00 UTC.
     */
    dsm_sample_time_t timetag;

    /**
     * length of sample, in bytes.
     */
    dsm_sample_length_t length;

    short id;

    short data[0];
} short_sample_t;


/**
 * init method, kmallocs and returns a pointer to the filter object,
 * or 0 if ENOMEM.
 */
typedef void* (*shortfilt_init_method)(void);

/**
 * config method.
 * @param id  Numberic id which is written to first word of output
 *      samples - so that downstream code can differentiate between
 *      samples from different filters.
 * @param obj Filter object which was kmalloc'd in init method.
 * @param cfg Pointer to a configuration structure for the filter.
 * @param decimate The decimation factor.
 * @param nvars Number of variables in each sample to be filtered.
 * @param vindices Integer indices of variables in sample to be filtered.
 * @cfg Pointer to configuration struct for the given filter.
 */
typedef int (*shortfilt_config_method)(void* obj, short id, int nvars,
    const int* vindices, int decimate,const void* cfg,int nbcfg);

/**
 * Actual filter method.
 * @param obj Filter object which was kmalloc'd in init method.
 * @param in Input sample.
 * @param out Output sample.
 * @return 1: Output sample is valid. 0: no output.
 */
typedef int (*shortfilt_filter_method)(void* obj,
    dsm_sample_time_t tt, const short* in, int skip_factor, short_sample_t* out);

/**
 * Destructor. kfree's the passed pointer to the filter object.
 */
typedef void (*shortfilt_cleanup_method)(void* obj);

struct short_filter_methods {
        shortfilt_init_method init;
        shortfilt_config_method config;
        shortfilt_filter_method filter;
        shortfilt_cleanup_method cleanup;
};

/**
 * Exposed module function which returns a structure of filter methods
 * for a supported type.
 */
extern struct short_filter_methods get_short_filter_methods(enum nidas_short_filter type);

/**
 * Configuration data needed for boxcar filter. Not much.
 */
struct boxcar_filter_config
{
      int npts;       // number of points to average.
};

#endif

#endif
    
